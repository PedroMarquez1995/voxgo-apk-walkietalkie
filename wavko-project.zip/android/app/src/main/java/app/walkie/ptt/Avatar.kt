package app.walkie.ptt

import android.content.Context

/**
 * El personaje completo viaja en un solo número (el mismo "skin" que ya guardaba y compartía la app):
 * bit 24 = personaje nuevo; después, 4+3+3+4+3+4+2 bits para skin, sombrero, antena, rostro, ropa,
 * accesorio y calzado. Los números antiguos (0..15) se muestran como el personaje base de esa skin.
 */
object Avatar {
    const val FLAG = 1 shl 24
    const val SKIN = 0
    const val HAT = 1
    const val ANT = 2
    const val FACE = 3
    const val CLOTH = 4
    const val ACC = 5
    const val SHOE = 6
    const val PARTS = 7

    private val SHIFT = intArrayOf(0, 4, 7, 10, 14, 17, 21)
    private val MASK = intArrayOf(15, 7, 7, 15, 7, 15, 3)
    val COUNTS = intArrayOf(14, 8, 8, 10, 8, 12, 4)

    fun pack(v: IntArray): Int {
        var a = FLAG
        for (p in 0 until PARTS) {
            val x = if (p < v.size) v[p].coerceIn(0, COUNTS[p] - 1) else 0
            a = a or (x shl SHIFT[p])
        }
        return a
    }

    /** Convierte un número antiguo (skin 0..15) o nuevo en un personaje nuevo válido. */
    fun normalize(a: Int): Int {
        if (a and FLAG != 0) return pack(IntArray(PARTS) { get(a, it) })
        return pack(intArrayOf(if (a in 0..15) a % 10 else 0, 0, 0, 0, 0, 0, 0))
    }

    fun get(a: Int, part: Int): Int {
        if (a and FLAG == 0) return if (part == SKIN) (if (a in 0..15) a % 10 else 0) else 0
        return ((a shr SHIFT[part]) and MASK[part]).coerceIn(0, COUNTS[part] - 1)
    }

    fun set(a: Int, part: Int, value: Int): Int {
        val base = normalize(a)
        val clear = base and (MASK[part] shl SHIFT[part]).inv()
        return clear or (value.coerceIn(0, COUNTS[part] - 1) shl SHIFT[part])
    }

    val DEFAULT: Int = pack(intArrayOf(0, 0, 0, 0, 0, 0, 0))
}

/** Un personaje guardado: de la colección (fijo) o creado por la persona. */
data class Hero(val id: String, val name: String, val avatar: Int, val preset: Boolean)

/** "Mis personajes": colección + creados por la persona, y cuál se usa. Se guarda en el teléfono. */
object Characters {
    const val MAX_CUSTOM = 12

    private fun prefs(ctx: Context) = Store.prefs(ctx)

    fun presets(): List<Hero> =
        AvatarCatalog.PRESETS.mapIndexed { i, p -> Hero("p${i + 1}", p.first, Avatar.pack(p.second), true) }

    fun custom(ctx: Context): MutableList<Hero> {
        val out = mutableListOf<Hero>()
        try {
            val arr = org.json.JSONArray(prefs(ctx).getString("chars", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += Hero(o.getString("id"), o.optString("name", "Wavko"), Avatar.normalize(o.optInt("a", 0)), false)
            }
        } catch (e: Exception) {
            // lista dañada: se ignora
        }
        return out
    }

    private fun saveCustom(ctx: Context, list: List<Hero>) {
        val arr = org.json.JSONArray()
        for (h in list) arr.put(org.json.JSONObject().put("id", h.id).put("name", h.name).put("a", h.avatar))
        prefs(ctx).edit().putString("chars", arr.toString()).apply()
    }

    fun all(ctx: Context): List<Hero> = presets() + custom(ctx)

    fun selectedId(ctx: Context): String = prefs(ctx).getString("charSel", "") ?: ""

    /** El personaje en uso; si nunca se eligió ninguno, se parte de la skin que ya tenía la persona. */
    fun selected(ctx: Context): Hero {
        val list = all(ctx)
        val id = selectedId(ctx)
        list.firstOrNull { it.id == id }?.let { return it }
        return Hero("", "Wavko", Avatar.normalize(Store.skin(ctx)), false)
    }

    /** Pone un personaje en uso: es el que ven los amigos y el canal. */
    fun select(ctx: Context, h: Hero) {
        prefs(ctx).edit().putString("charSel", h.id).putInt("skin", h.avatar).apply()
    }

    fun add(ctx: Context, name: String, avatar: Int): Hero? {
        val list = custom(ctx)
        if (list.size >= MAX_CUSTOM) return null
        val h = Hero("c" + java.util.UUID.randomUUID().toString().take(8), name.trim().take(20).ifEmpty { "Wavko" }, Avatar.normalize(avatar), false)
        list += h
        saveCustom(ctx, list)
        return h
    }

    fun update(ctx: Context, id: String, avatar: Int): Hero? {
        val list = custom(ctx)
        val i = list.indexOfFirst { it.id == id }
        if (i < 0) return null
        list[i] = list[i].copy(avatar = Avatar.normalize(avatar))
        saveCustom(ctx, list)
        return list[i]
    }

    fun rename(ctx: Context, id: String, name: String) {
        val list = custom(ctx)
        val i = list.indexOfFirst { it.id == id }
        if (i < 0) return
        list[i] = list[i].copy(name = name.trim().take(20).ifEmpty { list[i].name })
        saveCustom(ctx, list)
    }

    /** Elimina un personaje propio; si estaba en uso, se pasa al primero de la colección. */
    fun delete(ctx: Context, id: String) {
        val list = custom(ctx)
        if (list.none { it.id == id }) return
        saveCustom(ctx, list.filter { it.id != id })
        if (selectedId(ctx) == id) select(ctx, presets().first())
    }

    fun wipe(ctx: Context) {
        prefs(ctx).edit().remove("chars").remove("charSel").apply()
    }
}

/**
 * Desbloqueos: gratis, por logros, premium y ediciones limitadas. Por ahora todo está abierto
 * (ENFORCE = false); cuando haya logros o pagos basta con activar ENFORCE y llamar a [grant].
 */
object Unlocks {
    const val ENFORCE = false

    fun tier(part: Int, index: Int): Int = AvatarCatalog.TIERS[part].getOrElse(index) { 0 }

    fun isUnlocked(ctx: Context, part: Int, index: Int): Boolean {
        if (!ENFORCE || tier(part, index) == 0) return true
        return Store.prefs(ctx).getStringSet("unlocked", emptySet())?.contains("$part:$index") == true
    }

    fun grant(ctx: Context, part: Int, index: Int) {
        val s = (Store.prefs(ctx).getStringSet("unlocked", emptySet()) ?: emptySet()).toMutableSet()
        s.add("$part:$index")
        Store.prefs(ctx).edit().putStringSet("unlocked", s).apply()
    }
}
