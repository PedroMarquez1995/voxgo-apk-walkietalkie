package app.walkie.ptt

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Recibe el toque del widget o del botón de la notificación y alterna hablar / terminar. */
class PttActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == PttWidgetProvider.ACTION_TOGGLE) {
            PttService.instance?.toggleTalking()
        }
    }
}
