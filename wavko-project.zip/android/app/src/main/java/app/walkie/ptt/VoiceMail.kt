package app.walkie.ptt

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import java.io.ByteArrayOutputStream

/** Graba y reproduce mensajes de voz cortos (µ-law 16 kHz, máx. 20 s). */
object VoiceMail {
    const val RATE = 16000
    const val MAX_MS = 20_000L

    class Recorder(private val onDone: (ByteArray, Long) -> Unit) {
        @Volatile private var running = false
        private var thread: Thread? = null

        fun start(): Boolean {
            if (running) return false
            val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) return false
            val rec = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096) * 2
                )
            } catch (e: Exception) {
                return false
            }
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                return false
            }
            running = true
            thread = Thread {
                val out = ByteArrayOutputStream()
                val pcm = ShortArray(640)
                val enc = ByteArray(640)
                val t0 = System.currentTimeMillis()
                try {
                    rec.startRecording()
                    while (running && System.currentTimeMillis() - t0 < MAX_MS) {
                        val n = rec.read(pcm, 0, pcm.size)
                        if (n <= 0) break
                        Gain.boost(pcm, n, Gain.CAPTURE)
                        Ulaw.encode(pcm, enc, n)
                        out.write(enc, 0, n)
                    }
                } catch (e: Exception) {
                    // se entrega lo grabado hasta aquí
                } finally {
                    try { rec.stop() } catch (e: Exception) { }
                    rec.release()
                    running = false
                }
                onDone(out.toByteArray(), System.currentTimeMillis() - t0)
            }.also { it.start() }
            return true
        }

        /** Termina la grabación; el resultado llega por onDone (en otro hilo). */
        fun stop() {
            running = false
        }

        val active: Boolean get() = running
    }

    class Player {
        @Volatile private var track: AudioTrack? = null
        @Volatile private var playing = false

        fun play(data: ByteArray, onEnd: () -> Unit) {
            stop()
            val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = try {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder().setSampleRate(RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()
                    )
                    .setBufferSizeInBytes(maxOf(min, 4096) * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } catch (e: Exception) {
                onEnd()
                return
            }
            track = t
            playing = true
            Thread {
                try {
                    t.play()
                    val boost = Gain.enhance(t)
                    val pcm = ShortArray(640)
                    var off = 0
                    while (playing && off < data.size) {
                        val n = minOf(640, data.size - off)
                        Ulaw.decode(data.copyOfRange(off, off + n), pcm, n)
                        Gain.boost(pcm, n, Gain.PLAYBACK)
                        t.write(pcm, 0, n)
                        off += n
                    }
                    if (playing) t.stop()
                } catch (e: Exception) {
                    // se corta
                } finally {
                    try { t.release() } catch (e: Exception) { }
                    playing = false
                    if (track === t) track = null
                    onEnd()
                }
            }.start()
        }

        fun stop() {
            playing = false
        }
    }
}
