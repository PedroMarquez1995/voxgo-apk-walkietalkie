package app.walkie.ptt

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom

/** Datos guardados en el teléfono: perfil, ajustes y lista de amigos. */
object Store {
    private const val FILE = "wavko"

    data class Friend(val code: String, var name: String, var skin: Int)

    fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** Acepta direcciones sin esquema (se asume ws://). */
    fun normalizeUrl(raw: String): String {
        val url = raw.trim()
        if (url.isEmpty()) return ""
        return if (Regex("^(ws|wss|http|https)://", RegexOption.IGNORE_CASE).containsMatchIn(url)) url else "ws://$url"
    }

    fun name(ctx: Context): String =
        prefs(ctx).getString("name", null)?.trim()?.takeIf { it.isNotEmpty() } ?: Build.MODEL

    fun skin(ctx: Context): Int = prefs(ctx).getInt("skin", 0)

    // ---------------------------------------------------------- Código de amigo

    /** Código propio de 6 caracteres; se crea la primera vez y se conserva. */
    fun friendCode(ctx: Context): String {
        val p = prefs(ctx)
        val saved = p.getString("friendCode", "") ?: ""
        if (saved.length == 6) return saved
        val alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
        val rnd = SecureRandom()
        val code = buildString { repeat(6) { append(alphabet[rnd.nextInt(alphabet.length)]) } }
        p.edit().putString("friendCode", code).apply()
        return code
    }

    fun cleanCode(raw: String): String =
        raw.uppercase().filter { it in 'A'..'Z' || it in '0'..'9' }

    fun prettyCode(code: String): String = code.chunked(3).joinToString("-")

    // ------------------------------------------------------------------ Amigos

    fun loadFriends(ctx: Context): MutableList<Friend> {
        val out = mutableListOf<Friend>()
        try {
            val arr = JSONArray(prefs(ctx).getString("friends", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += Friend(o.getString("code"), o.optString("name", ""), o.optInt("skin", 0))
            }
        } catch (e: Exception) {
            // datos dañados: empezamos con la lista vacía
        }
        return out
    }

    fun saveFriends(ctx: Context, list: List<Friend>) {
        val arr = JSONArray()
        for (f in list) {
            arr.put(JSONObject().put("code", f.code).put("name", f.name).put("skin", f.skin))
        }
        prefs(ctx).edit().putString("friends", arr.toString()).apply()
    }

    // ------------------------------------------------- Canales recientes / favoritos

    data class Chan(val name: String, var fav: Boolean)

    /** Favoritos primero y luego los recientes (el más nuevo arriba). */
    fun loadChannels(ctx: Context): MutableList<Chan> {
        val out = mutableListOf<Chan>()
        try {
            val arr = JSONArray(prefs(ctx).getString("channels", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += Chan(o.getString("name"), o.optBoolean("fav", false))
            }
        } catch (e: Exception) {
            // datos dañados: lista vacía
        }
        return out
    }

    private fun saveChannels(ctx: Context, list: List<Chan>) {
        val arr = JSONArray()
        for (c in list) arr.put(JSONObject().put("name", c.name).put("fav", c.fav))
        prefs(ctx).edit().putString("channels", arr.toString()).apply()
    }

    /** Guarda el canal como el más reciente; se conservan 8 recientes (los favoritos no cuentan). */
    fun touchChannel(ctx: Context, name: String) {
        val list = loadChannels(ctx)
        val old = list.firstOrNull { it.name.equals(name, ignoreCase = true) }
        if (old != null) list.remove(old)
        list.add(0, Chan(name, old?.fav ?: false))
        var recents = 0
        val it = list.iterator()
        while (it.hasNext()) {
            val c = it.next()
            if (!c.fav && ++recents > 8) it.remove()
        }
        saveChannels(ctx, list)
    }

    fun toggleFavorite(ctx: Context, name: String) {
        val list = loadChannels(ctx)
        list.firstOrNull { it.name == name }?.let { it.fav = !it.fav }
        saveChannels(ctx, list)
    }

    fun removeChannel(ctx: Context, name: String) {
        saveChannels(ctx, loadChannels(ctx).filter { it.name != name })
    }

    // ------------------------------------------------------------------- Tema

    /** 0 = sistema, 1 = claro, 2 = oscuro */
    fun themeMode(ctx: Context): Int = prefs(ctx).getInt("theme", 0)

    fun nightMode(ctx: Context): Int = when (themeMode(ctx)) {
        1 -> androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO
        2 -> androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES
        else -> androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
    }
}
