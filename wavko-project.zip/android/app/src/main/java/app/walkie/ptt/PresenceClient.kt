package app.walkie.ptt

import android.os.Handler
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject

/**
 * Conexión de "presencia": le dice al servidor que estás en línea y pregunta por tus amigos.
 * Todos los callbacks llegan en el hilo principal. Reintenta sola si se cae.
 */
class PresenceClient(private val client: OkHttpClient, private val main: Handler) {

    data class FriendStatus(
        val code: String,
        val online: Boolean,
        val name: String?,
        val skin: Int,
        val inChannel: Boolean
    )

    interface Listener {
        fun onStatus(list: List<FriendStatus>)
        fun onConnection(connected: Boolean)
        fun onInvite(fromCode: String, fromName: String, skin: Int, channel: String, pass: String) {}
        fun onInviteResult(toCode: String, delivered: Boolean) {}
    }

    var listener: Listener? = null

    @Volatile private var ws: WebSocket? = null
    private var gen = 0
    private var wanted = false

    private var baseUrl = ""
    private var key = ""
    private var code = ""
    private var name = ""
    private var skin = 0
    private var inChannel = false
    private var watch: List<String> = emptyList()

    private val retry = Runnable { if (wanted) open() }

    fun start(
        url: String, key: String, code: String, name: String,
        skin: Int, inChannel: Boolean, watch: List<String>
    ) {
        this.baseUrl = url.trimEnd('/')
        this.key = key
        this.code = code
        this.name = name
        this.skin = skin
        this.inChannel = inChannel
        this.watch = watch
        wanted = true
        open()
    }

    /** Invita a un amigo a un canal; el servidor solo lo entrega si el amigo también te tiene. */
    fun sendInvite(toCode: String, channel: String, pass: String): Boolean {
        val socket = ws ?: return false
        return socket.send(
            JSONObject().put("type", "invite").put("to", toCode)
                .put("channel", channel).put("pass", pass).toString()
        )
    }

    /** Cambia nombre, skin o amigos vigilados sin reconectar. */
    fun update(name: String, skin: Int, watch: List<String>) {
        this.name = name
        this.skin = skin
        this.watch = watch
        ws?.let { sendHello(it) }
    }

    fun stop() {
        wanted = false
        gen++
        main.removeCallbacks(retry)
        ws?.close(1000, null)
        ws = null
    }

    private fun sendHello(socket: WebSocket) {
        val j = JSONObject()
            .put("type", "hello")
            .put("code", code)
            .put("name", name)
            .put("skin", skin)
            .put("inChannel", inChannel)
            .put("key", key)
            .put("watch", JSONArray(watch))
        socket.send(j.toString())
    }

    private fun open() {
        gen++
        val my = gen
        ws?.cancel()
        val request = try {
            Request.Builder().url("$baseUrl/presence").build()
        } catch (e: IllegalArgumentException) {
            return
        }
        ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (my != gen) return
                sendHello(webSocket)
                main.post { if (my == gen) listener?.onConnection(true) }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (my != gen) return
                val j = try {
                    JSONObject(text)
                } catch (e: Exception) {
                    return
                }
                when (j.optString("type")) {
                    "status" -> {
                        val arr = j.optJSONArray("friends") ?: return
                        val list = List(arr.length()) { i ->
                            val o = arr.getJSONObject(i)
                            FriendStatus(
                                o.optString("code"),
                                o.optBoolean("online", false),
                                if (o.has("name")) o.optString("name") else null,
                                o.optInt("skin", 0),
                                o.optBoolean("inChannel", false)
                            )
                        }
                        main.post { if (my == gen) listener?.onStatus(list) }
                    }
                    "invite" -> {
                        val from = j.optString("from")
                        val nm = j.optString("name")
                        val sk = j.optInt("skin", 0)
                        val ch = j.optString("channel")
                        val pw = j.optString("pass")
                        if (ch.isNotEmpty()) {
                            main.post { if (my == gen) listener?.onInvite(from, nm, sk, ch, pw) }
                        }
                    }
                    "invite_result" -> {
                        val to = j.optString("to")
                        val ok = j.optInt("delivered", 0) > 0
                        main.post { if (my == gen) listener?.onInviteResult(to, ok) }
                    }
                    "error" -> main.post {
                        if (my == gen) {
                            wanted = false // clave del servidor incorrecta: no insistimos
                            listener?.onConnection(false)
                        }
                    }
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                main.post { if (my == gen) dropped() }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                main.post { if (my == gen) dropped() }
            }
        })
    }

    private fun dropped() {
        ws = null
        listener?.onConnection(false)
        if (wanted) {
            main.removeCallbacks(retry)
            main.postDelayed(retry, 5000)
        }
    }
}
