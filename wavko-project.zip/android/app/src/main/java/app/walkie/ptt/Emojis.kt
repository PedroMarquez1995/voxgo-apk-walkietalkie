package app.walkie.ptt

import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ScrollView
import android.widget.TextView

/** Panel de emojis para los chats (usa los emojis del sistema del teléfono). */
object Emojis {
    private const val ALL =
        "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 😐 😑 😶 😏 😒 🙄 😬 😮 🥱 😴 🤤 😪 😵 🤯 🤠 🥳 😎 🤓 🧐 😕 😟 🙁 😮 😲 😳 🥺 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 😤 😡 😠 🤬 😈 👿 💀 💩 🤡 👻 👽 🤖 " +
        "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 🖖 👋 🤝 🙏 💪 👏 🙌 👐 🤲 ✍️ " +
        "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 " +
        "🔥 ✨ 🎉 🎊 🎁 🎂 🍕 🍔 🍟 🌮 🍺 🍻 ☕ ⚽ 🏀 🎮 🎧 🎤 🎵 🎶 📞 📱 💻 🚗 ✈️ 🏠 ⭐ 🌟 💯 ✅ ❌ ❓ ❗ 💤 🌈 ☀️ 🌙 🐶 🐱 🐻 🦁 🐸 🐵"

    /** Prepara el botón y el panel: al tocar el botón se muestra u oculta el panel; cada emoji se escribe en el campo. */
    fun setup(ctx: Context, button: View, panel: ViewGroup, input: EditText) {
        val d = ctx.resources.displayMetrics.density
        val grid = GridLayout(ctx).apply { columnCount = 8 }
        val cell = (44 * d).toInt()
        for (e in ALL.split(" ").filter { it.isNotBlank() }) {
            grid.addView(TextView(ctx).apply {
                text = e
                textSize = 24f
                gravity = Gravity.CENTER
                layoutParams = GridLayout.LayoutParams().apply { width = cell; height = cell }
                setOnClickListener {
                    val s = input.selectionStart.coerceAtLeast(0)
                    val en = input.selectionEnd.coerceAtLeast(s)
                    input.text.replace(s, en, e)
                }
            })
        }
        val sv = ScrollView(ctx).apply {
            isFillViewport = false
            addView(grid, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        panel.addView(sv, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        button.setOnClickListener {
            if (panel.visibility == View.VISIBLE) {
                panel.visibility = View.GONE
                input.requestFocus()
                imm.showSoftInput(input, 0)
            } else {
                imm.hideSoftInputFromWindow(input.windowToken, 0)
                panel.visibility = View.VISIBLE
            }
        }
        // Al escribir con el teclado, el panel se cierra
        input.setOnClickListener { panel.visibility = View.GONE }
    }
}
