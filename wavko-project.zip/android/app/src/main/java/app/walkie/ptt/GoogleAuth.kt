package app.walkie.ptt

import android.app.Activity
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

/** Acceso con Google (opcional: solo si la app se compiló con GOOGLE_CLIENT_ID). */
object GoogleAuth {
    fun enabled() = BuildConfig.GOOGLE_CLIENT_ID.isNotEmpty()

    /** cb(idToken, error): idToken null si se canceló (error null) o falló (error con el motivo). */
    fun idToken(activity: Activity, cb: (String?, String?) -> Unit) {
        if (!enabled()) {
            cb(null, "off")
            return
        }
        try {
            val option = GetSignInWithGoogleOption.Builder(BuildConfig.GOOGLE_CLIENT_ID).build()
            val req = GetCredentialRequest.Builder().addCredentialOption(option).build()
            CredentialManager.create(activity).getCredentialAsync(
                activity, req, null, ContextCompat.getMainExecutor(activity),
                object : CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                    override fun onResult(result: GetCredentialResponse) {
                        val c = result.credential
                        if (c is CustomCredential &&
                            c.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                        ) {
                            try {
                                cb(GoogleIdTokenCredential.createFrom(c.data).idToken, null)
                            } catch (e: Exception) {
                                cb(null, e.message ?: "error")
                            }
                        } else {
                            cb(null, "tipo")
                        }
                    }

                    override fun onError(e: GetCredentialException) {
                        cb(null, if (e is GetCredentialCancellationException) null else (e.message ?: "error"))
                    }
                }
            )
        } catch (e: Exception) {
            cb(null, e.message ?: "error")
        }
    }
}
