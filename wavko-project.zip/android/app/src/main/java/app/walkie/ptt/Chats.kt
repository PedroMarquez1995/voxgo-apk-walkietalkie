package app.walkie.ptt

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList

/** Historial de conversaciones con cada amigo (texto y audios), guardado solo en este teléfono. */
object Chats {
    data class Msg(val id: String, val mine: Boolean, val kind: String, val text: String, val dur: Long, val ts: Long)

    private const val MAX_PER_CHAT = 300

    private fun dir(ctx: Context) = File(ctx.filesDir, "chats").apply { mkdirs() }
    private fun file(ctx: Context, code: String) = File(dir(ctx), "$code.json")

    fun audioFile(ctx: Context, id: String) =
        File(File(dir(ctx), "audio").apply { mkdirs() }, "${id.filter { it.isLetterOrDigit() || it == '-' }}.ulaw")

    @Synchronized
    fun load(ctx: Context, code: String): List<Msg> {
        val out = mutableListOf<Msg>()
        try {
            val f = file(ctx, code)
            if (!f.exists()) return out
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += Msg(
                    o.getString("id"), o.optBoolean("mine"), o.optString("kind", "text"),
                    o.optString("text"), o.optLong("dur"), o.optLong("ts")
                )
            }
        } catch (e: Exception) {
            // historial dañado: se empieza de nuevo
        }
        return out
    }

    @Synchronized
    fun append(ctx: Context, code: String, m: Msg) {
        val list = load(ctx, code).toMutableList()
        if (list.any { it.id == m.id }) return
        list.add(m)
        list.sortBy { it.ts }
        while (list.size > MAX_PER_CHAT) {
            val old = list.removeAt(0)
            if (old.kind == "voice") audioFile(ctx, old.id).delete()
        }
        val arr = JSONArray()
        for (x in list) {
            arr.put(
                JSONObject().put("id", x.id).put("mine", x.mine).put("kind", x.kind)
                    .put("text", x.text).put("dur", x.dur).put("ts", x.ts)
            )
        }
        file(ctx, code).writeText(arr.toString())
    }

    @Synchronized
    fun clearAll(ctx: Context) {
        dir(ctx).deleteRecursively()
        val p = Store.prefs(ctx)
        val e = p.edit()
        for (k in p.all.keys) if (k.startsWith("unread_")) e.remove(k)
        e.apply()
    }

    fun unread(ctx: Context, code: String): Int = Store.prefs(ctx).getInt("unread_$code", 0)

    fun addUnread(ctx: Context, code: String) {
        Store.prefs(ctx).edit().putInt("unread_$code", unread(ctx, code) + 1).apply()
    }

    fun clearUnread(ctx: Context, code: String) {
        if (unread(ctx, code) != 0) Store.prefs(ctx).edit().remove("unread_$code").apply()
    }
}

/** Recoge del servidor los mensajes (texto y voz) que los amigos te enviaron y los guarda en el historial. */
object Inbox {
    @Volatile private var running = false
    val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun sync(ctx0: Context, api: AccountApi) {
        val ctx = ctx0.applicationContext
        if (!Store.hasAccount(ctx) || running) return
        running = true
        api.call(ctx, "GET", "/api/voice") { r ->
            val arr = r.json?.optJSONArray("messages")
            if (!r.ok || arr == null || arr.length() == 0) {
                running = false
                return@call
            }
            val items = List(arr.length()) { arr.getJSONObject(it) }
            var got = false
            fun finish() {
                running = false
                if (got) listeners.forEach { it() }
            }
            fun step(i: Int) {
                if (i >= items.size) {
                    finish()
                    return
                }
                val o = items[i]
                val id = o.optString("id")
                val from = o.optString("from")
                val ts = o.optLong("ts", System.currentTimeMillis())
                fun done() {
                    api.call(ctx, "DELETE", "/api/voice/$id") { step(i + 1) }
                }
                if (o.optString("kind") == "text") {
                    Chats.append(ctx, from, Chats.Msg(id, false, "text", o.optString("text"), 0, ts))
                    Chats.addUnread(ctx, from)
                    got = true
                    done()
                } else {
                    api.bytes(ctx, "GET", "/api/voice/$id") { status, data ->
                        if (status == 200 && data != null && data.isNotEmpty()) {
                            try {
                                Chats.audioFile(ctx, id).writeBytes(data)
                                Chats.append(ctx, from, Chats.Msg(id, false, "voice", "", o.optLong("dur"), ts))
                                Chats.addUnread(ctx, from)
                                got = true
                                done()
                            } catch (e: Exception) {
                                step(i + 1)
                            }
                        } else {
                            step(i + 1) // se reintentará en la próxima sincronización
                        }
                    }
                }
            }
            step(0)
        }
    }
}
