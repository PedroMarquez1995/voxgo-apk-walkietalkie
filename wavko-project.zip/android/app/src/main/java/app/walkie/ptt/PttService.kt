package app.walkie.ptt

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Mantiene la conexión WebSocket, captura el micrófono mientras se pulsa PTT
 * y reproduce el audio de los demás. Corre como servicio en primer plano para
 * seguir funcionando con la pantalla apagada.
 *
 * Toda la lógica de estado corre en el hilo principal; los hilos de audio
 * solo leen/escriben buffers.
 */
class PttService : Service() {

    interface Listener {
        fun onChanged()
        /** Llegó (o enviaste) un mensaje del chat del canal. */
        fun onChat() {}
    }

    data class ChatMsg(val name: String, val text: String, val mine: Boolean, val ts: Long, val id: String = java.util.UUID.randomUUID().toString())

    /** Chat de texto del canal (solo en memoria; se borra al salir). */
    val chat = mutableListOf<ChatMsg>()

    /** Borra un mensaje del chat del canal: solo para mí, o para todos si es mío. */
    fun deleteChat(id: String, forAll: Boolean) {
        if (forAll) ws?.send(JSONObject().put("type", "chatdel").put("id", id).toString())
        chat.removeAll { it.id == id }
        listener?.onChat()
    }
    var chatUnread = 0

    companion object {
        const val DISCONNECTED = 0
        const val CONNECTING = 1
        const val CONNECTED = 2

        const val RATE = 16000
        const val CHUNK = 640 // 40 ms a 16 kHz

        private const val CHANNEL_ID = "wavko"
        private const val NOTIF_ID = 1
        private const val INVITE_CHANNEL_ID = "wavko_invites"

        /** Servicio en ejecución (lo usan el widget y el botón de la notificación). */
        @Volatile var instance: PttService? = null
            private set
    }

    inner class LocalBinder : Binder() {
        val service: PttService get() = this@PttService
    }

    private val binder = LocalBinder()
    private val main = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    // Estado visible para la UI
    var listener: Listener? = null
    var state = DISCONNECTED
        private set
    var statusText = ""
        private set
    var users: List<String> = emptyList()
        private set
    var talker: String? = null
        private set
    var transmitting = false
        private set

    /** Nombre del canal y mi nombre dentro de él, tal como los confirmó el servidor. */
    var channelName = ""
        private set
    var myName = ""
        private set

    /** Dueño del canal (puede expulsar) y código de cada participante con cuenta verificada. */
    var owner = ""
        private set
    var codes: Map<String, String> = emptyMap()
        private set

    /** Skin de cada participante, por nombre. */
    var skins: Map<String, Int> = emptyMap()
        private set

    private var skin = 0

    /** Clave con la que entré al canal (para poder invitar a amigos). */
    val channelPass: String get() = chanPass
    private var presence: PresenceClient? = null

    private var url = ""
    private var channel = ""
    private var name = ""
    private var key = ""
    private var mode = "join" // "create" | "join"; tras entrar pasa a "resume" para reconectar
    private var chanPass = ""
    private var chanProof = "" // prueba derivada de la clave: es lo único que ve el servidor
    @Volatile private var chanKey: javax.crypto.SecretKey? = null
    private var connectGen = 0
    @Volatile private var muted = false // el que habla está bloqueado por mí

    @Volatile private var ws: WebSocket? = null
    @Volatile private var gen = 0
    private var wantConnected = false
    private var wantTalk = false

    private var recorder: Recorder? = null
    private var player: Player? = null
    private var tone: ToneGenerator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    private val retry = Runnable { if (wantConnected) openSocket() }

    // ------------------------------------------------------------------ Service

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startFg(statusText)
        } catch (e: Exception) {
            disconnect(getString(R.string.service_start_failed, e.message ?: ""))
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        teardown()
        if (instance === this) instance = null
        PttWidgetProvider.refresh(applicationContext)
        super.onDestroy()
    }

    // --------------------------------------------------------------- API pública

    fun connect(url: String, channel: String, name: String, key: String, mode: String, pass: String, skin: Int) {
        this.url = url
        this.channel = channel
        this.name = name
        this.key = key
        this.mode = mode
        this.chanPass = pass
        this.skin = skin
        skins = emptyMap()
        codes = emptyMap()
        owner = ""
        muted = false
        channelName = ""
        myName = ""
        wantConnected = true
        acquireLocks()
        player?.shutdown()
        player = Player().also { it.start() }
        if (tone == null) {
            tone = try {
                ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            } catch (e: Exception) {
                null
            }
        }
        val myConnect = ++connectGen
        if (pass.isEmpty()) {
            chanProof = ""
            chanKey = null
            openSocket()
            startPresence()
        } else {
            // Derivar las claves (PBKDF2) tarda un poco: se hace fuera del hilo principal
            setState(CONNECTING, getString(R.string.connecting))
            val ch = Store.cleanChannel(channel)
            Thread {
                try {
                    val proof = ChannelCrypto.proof(pass, ch)
                    val k = ChannelCrypto.key(pass, ch)
                    main.post {
                        if (wantConnected && myConnect == connectGen) {
                            chanProof = proof
                            chanKey = k
                            openSocket()
                            startPresence()
                        }
                    }
                } catch (e: Exception) {
                    main.post {
                        if (wantConnected && myConnect == connectGen) disconnect(getString(R.string.crypto_failed))
                    }
                }
            }.start()
        }
    }

    /** Mientras estoy en un canal, mis amigos me ven "en un canal" aunque la app esté cerrada. */
    private fun startPresence() {
        presence?.stop()
        val base = Store.normalizeUrl(url)
        if (base.isEmpty() || !Store.hasAccount(this)) return
        presence = PresenceClient(client, main).also {
            it.listener = object : PresenceClient.Listener {
                override fun onStatus(list: List<PresenceClient.FriendStatus>) {}
                override fun onConnection(connected: Boolean) {}
                override fun onVoice(fromName: String) {
                    if (listener == null) Push.notifyVoice(this@PttService, fromName)
                }
                override fun onInvite(fromCode: String, fromName: String, skin: Int, channel: String, pass: String) {
                    // Con la app abierta la invitación se muestra en pantalla; si no, como notificación
                    if (listener == null) notifyInvite(fromName, channel, pass)
                }
            }
            it.start(base, key, Store.friendCode(this), Store.token(this), name, skin, true)
        }
    }

    /** Toca para hablar / toca para terminar (widget, notificación). */
    fun toggleTalking() {
        if (state != CONNECTED) return
        if (wantTalk || transmitting) stopTalking() else startTalking()
    }

    fun disconnect(reason: String? = null) {
        val text = reason ?: getString(R.string.disconnected)
        teardown()
        talker = null
        users = emptyList()
        transmitting = false
        channelName = ""
        myName = ""
        skins = emptyMap()
        codes = emptyMap()
        owner = ""
        muted = false
        chanKey = null
        chanProof = ""
        chat.clear()
        chatUnread = 0
        connectGen++
        setState(DISCONNECTED, text)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** El usuario pulsó el botón: pedimos el turno al servidor. */
    fun startTalking() {
        if (state != CONNECTED || wantTalk) return
        wantTalk = true
        ws?.send("""{"type":"ptt","on":true}""")
    }

    /** El usuario soltó el botón. */
    fun stopTalking() {
        if (!wantTalk && recorder == null) return
        wantTalk = false
        recorder?.running = false
        recorder = null
        ws?.send("""{"type":"ptt","on":false}""")
        if (transmitting) {
            transmitting = false
            vibrateEnd()
            beep(ToneGenerator.TONE_PROP_ACK)
            txChanged()
        }
    }

    // ---------------------------------------------------------------- Conexión

    private fun openSocket() {
        gen++
        ws?.cancel()
        setState(CONNECTING, getString(R.string.connecting))
        // El canal va también en la URL: así Cloudflare enruta la conexión al canal correcto.
        // El servidor Node.js ignora este parámetro.
        val sep = if (url.contains("?")) "&" else "?"
        val fullUrl = url + sep + "channel=" + Uri.encode(channel)
        val request = try {
            Request.Builder().url(fullUrl).build()
        } catch (e: IllegalArgumentException) {
            disconnect(getString(R.string.bad_server_url))
            return
        }
        ws = client.newWebSocket(request, makeListener(gen))
    }

    private fun makeListener(myGen: Int) = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            if (myGen != gen) return
            val j = JSONObject()
                .put("type", "join")
                .put("channel", channel)
                .put("name", name)
                .put("key", key)
                .put("mode", mode)
                .put("pass", chanProof)
                .put("skin", skin)
            if (Store.hasAccount(this@PttService)) {
                j.put("code", Store.friendCode(this@PttService)).put("token", Store.token(this@PttService))
            }
            webSocket.send(j.toString())
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            if (myGen != gen) return
            main.post { if (myGen == gen) handleText(text) }
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            if (myGen != gen) return
            val raw = bytes.toByteArray()
            val k = chanKey
            // En un canal con clave solo se acepta audio cifrado y autenticado
            val data = if (k == null) raw else ChannelCrypto.open(k, raw)
            if (data != null && !muted) player?.enqueue(data)
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(1000, null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            main.post { if (myGen == gen) handleDrop(getString(R.string.conn_closed)) }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            main.post { if (myGen == gen) handleDrop(getString(R.string.no_connection)) }
        }
    }

    private fun handleText(text: String) {
        val j = try {
            JSONObject(text)
        } catch (e: Exception) {
            return
        }
        when (j.optString("type")) {
            "joined" -> {
                users = parseUsers(j)
                skins = parseSkins(j)
                readRoster(j)
                channelName = j.optString("channel", channel)
                myName = j.optString("you", name)
                mode = "resume" // si se cae la red, volvemos a entrar con la misma clave
                val fmt = if (j.optBoolean("created", false)) R.string.status_created else R.string.status_connected
                setState(CONNECTED, getString(fmt, channelName))
            }
            "users" -> {
                users = parseUsers(j)
                skins = parseSkins(j)
                readRoster(j)
                listener?.onChanged()
            }
            "talking" -> {
                talker = if (j.isNull("name")) null else j.optString("name")
                updateMuted()
                listener?.onChanged()
            }
            "granted" -> beginRecording()
            "busy" -> {
                wantTalk = false
                try {
                    tone?.startTone(ToneGenerator.TONE_PROP_NACK, 150)
                } catch (e: Exception) {
                }
                listener?.onChanged()
            }
            "chat" -> receiveChat(j)
            "chatdel" -> {
                val id = j.optString("id")
                val nm = j.optString("name")
                if (id.isNotEmpty() && chat.removeAll { it.id == id && !it.mine && it.name == nm }) listener?.onChat()
            }
            "released" -> stopTalking() // el servidor cortó el turno por tiempo máximo
            "kicked" -> disconnect(getString(R.string.kicked))
            "error" -> disconnect(errorText(j))
        }
    }

    private fun readRoster(j: JSONObject) {
        owner = j.optString("owner", "")
        val o = j.optJSONObject("codes")
        val m = HashMap<String, String>()
        if (o != null) for (k in o.keys()) m[k] = o.optString(k)
        codes = m
        updateMuted()
    }

    /** Si quien habla está en mi lista de bloqueados, no reproduzco su audio. */
    fun updateMuted() {
        val t = talker
        val c = if (t == null) null else codes[t]
        muted = c != null && Store.loadBlocked(this).contains(c)
    }

    /** Solo el dueño del canal: expulsa a un participante (queda vetado hasta que el canal se vacíe). */
    fun kick(name: String) {
        ws?.send(JSONObject().put("type", "kick").put("name", name).toString())
    }

    private fun addChat(m: ChatMsg) {
        chat.add(m)
        while (chat.size > 100) chat.removeAt(0)
        listener?.onChat()
    }

    private fun receiveChat(j: JSONObject) {
        val code = j.optString("code")
        if (code.isNotEmpty() && Store.loadBlocked(this).contains(code)) return // bloqueado: no se muestra
        var text = j.optString("text")
        val k = chanKey
        if (k != null) {
            val raw = try {
                android.util.Base64.decode(text, android.util.Base64.NO_WRAP)
            } catch (e: IllegalArgumentException) {
                return
            }
            text = String(ChannelCrypto.open(k, raw) ?: return, Charsets.UTF_8)
        }
        if (text.isBlank()) return
        chatUnread++
        addChat(ChatMsg(j.optString("name"), text.take(500), false, System.currentTimeMillis(), j.optString("id").ifEmpty { java.util.UUID.randomUUID().toString() }))
    }

    /** Envía un mensaje de texto al canal (cifrado si el canal tiene clave). */
    fun sendChat(text: String) {
        val t = text.trim().take(500)
        if (t.isEmpty() || state != CONNECTED) return
        val k = chanKey
        val payload = if (k == null) t else {
            val sealed = ChannelCrypto.seal(k, t.toByteArray(Charsets.UTF_8)) ?: return
            android.util.Base64.encodeToString(sealed, android.util.Base64.NO_WRAP)
        }
        val id = java.util.UUID.randomUUID().toString()
        ws?.send(JSONObject().put("type", "chat").put("id", id).put("text", payload).toString())
        addChat(ChatMsg(myName, t, true, System.currentTimeMillis(), id))
    }

    /** Envía audio; si el canal tiene clave, cifrado. */
    private fun sendAudio(data: ByteArray) {
        val k = chanKey
        val payload = if (k == null) data else (ChannelCrypto.seal(k, data) ?: return)
        ws?.send(payload.toByteString())
    }

    private fun handleDrop(msg: String) {
        if (!wantConnected) return
        stopTalking()
        talker = null
        users = emptyList()
        ws = null
        setState(CONNECTING, getString(R.string.retrying, msg))
        main.removeCallbacks(retry)
        main.postDelayed(retry, 3000)
    }

    private fun errorText(j: JSONObject): String = when (j.optString("code")) {
        "bad_key" -> getString(R.string.err_bad_key)
        "not_found" -> getString(R.string.err_not_found)
        "exists" -> getString(R.string.err_exists)
        "bad_pass" -> getString(R.string.err_bad_pass)
        "banned" -> getString(R.string.err_banned)
        "locked" -> getString(R.string.err_locked)
        else -> j.optString("message", getString(R.string.err_server))
    }

    private fun parseUsers(j: JSONObject): List<String> {
        val a = j.optJSONArray("users") ?: return emptyList()
        return List(a.length()) { a.optString(it) }
    }

    private fun parseSkins(j: JSONObject): Map<String, Int> {
        val o = j.optJSONObject("skins") ?: return emptyMap()
        val m = HashMap<String, Int>()
        for (k in o.keys()) m[k] = o.optInt(k, 0)
        return m
    }

    private fun setState(s: Int, text: String) {
        state = s
        statusText = text
        if (s != DISCONNECTED) updateNotif(text)
        PttWidgetProvider.refresh(applicationContext)
        listener?.onChanged()
    }

    private fun txChanged() {
        updateNotif(statusText)
        PttWidgetProvider.refresh(applicationContext)
        listener?.onChanged()
    }

    private fun teardown() {
        wantConnected = false
        wantTalk = false
        presence?.stop()
        presence = null
        main.removeCallbacksAndMessages(null)
        recorder?.running = false
        recorder = null
        gen++
        ws?.close(1000, "bye")
        ws = null
        player?.shutdown()
        player = null
        tone?.release()
        tone = null
        releaseLocks()
    }

    // ------------------------------------------------------------------- Audio

    private fun beginRecording() {
        if (!wantTalk || recorder != null) return
        val hasMic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (!hasMic) {
            stopTalking()
            return
        }
        vibrate()
        transmitting = true
        txChanged()
        if (beepOn()) {
            // Bip de "adelante" y, un instante después, abrimos el micrófono para que el bip no se transmita
            beep(ToneGenerator.TONE_PROP_BEEP)
            main.postDelayed({
                if (wantTalk && recorder == null && transmitting) recorder = Recorder().also { it.start() }
            }, 150)
        } else {
            recorder = Recorder().also { it.start() }
        }
    }

    private fun beepOn(): Boolean = Store.prefs(this).getBoolean("beep", true)

    /** Bip corto estilo walkie-talkie (se puede desactivar en Ajustes). */
    private fun beep(kind: Int) {
        if (!beepOn()) return
        try {
            tone?.startTone(kind, 120)
        } catch (e: Exception) {
        }
    }

    /** Una vibración corta al empezar a transmitir. */
    private fun vibrate() {
        try {
            val v = getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
        }
    }

    /** Dos vibraciones cortas al terminar de transmitir. */
    private fun vibrateEnd() {
        try {
            val v = getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 30, 70, 30), -1))
        } catch (e: Exception) {
        }
    }

    private inner class Recorder : Thread("ptt-rec") {
        @Volatile var running = true

        @SuppressLint("MissingPermission")
        override fun run() {
            val minBuf = AudioRecord.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, CHUNK * 2 * 4)
                )
            } catch (e: Exception) {
                null
            }
            if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
                rec?.release()
                main.post { stopTalking() }
                return
            }
            val pcm = ShortArray(CHUNK)
            val out = ByteArray(CHUNK)
            // Audio HD (Opus): opcional; si falla algo se vuelve a µ-law sin avisar
            var enc: OpusCodec.Encoder? = null
            if (Store.prefs(this@PttService).getBoolean("hd", false)) {
                enc = OpusCodec.Encoder().takeIf { it.ok }
            }
            try {
                rec.startRecording()
                while (running) {
                    var off = 0
                    while (running && off < CHUNK) {
                        val n = rec.read(pcm, off, CHUNK - off)
                        if (n <= 0) {
                            running = false
                            break
                        }
                        off += n
                    }
                    if (off == CHUNK) {
                        Gain.boost(pcm, CHUNK, Gain.CAPTURE)
                        val e = enc
                        if (e != null) {
                            e.encode(pcm, 0) { sendAudio(it) }
                            e.encode(pcm, OpusCodec.FRAME) { sendAudio(it) }
                            if (!e.ok) enc = null
                        } else {
                            Ulaw.encode(pcm, out, CHUNK)
                            sendAudio(out.copyOf())
                        }
                    }
                }
            } finally {
                enc?.release()
                try {
                    rec.stop()
                } catch (e: Exception) {
                }
                rec.release()
            }
        }
    }

    private inner class Player : Thread("ptt-play") {
        private val queue = LinkedBlockingQueue<ByteArray>()

        @Volatile private var running = true

        fun enqueue(b: ByteArray) {
            if (queue.size > 150) queue.clear() // ~6 s acumulados: descartamos para no ir con retraso
            queue.offer(b)
        }

        fun shutdown() {
            running = false
            interrupt()
        }

        override fun run() {
            val minBuf = AudioTrack.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, RATE)) // ~0,5 s
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            val boost = Gain.enhance(track)
            var pcm = ShortArray(CHUNK)
            var dec: OpusCodec.Decoder? = null
            var started = false
            var pre = 0
            try {
                while (running) {
                    val chunk = try {
                        queue.poll(250, TimeUnit.MILLISECONDS)
                    } catch (e: InterruptedException) {
                        break
                    }
                    if (chunk == null) {
                        // Silencio: dejamos que termine de sonar lo que quedó en el buffer
                        if (pre > 0 || started) {
                            if (!started) track.play()
                            track.stop()
                            started = false
                            pre = 0
                        }
                        continue
                    }
                    if (chunk.size == CHUNK) {
                        // µ-law (formato clásico, 640 bytes)
                        val n = chunk.size
                        if (pcm.size < n) pcm = ShortArray(n)
                        Ulaw.decode(chunk, pcm, n)
                        Gain.boost(pcm, n, Gain.PLAYBACK)
                        track.write(pcm, 0, n)
                    } else if (chunk.size > 1 && chunk[0] == OpusCodec.TAG) {
                        if (dec == null) dec = OpusCodec.Decoder()
                        val d = dec ?: continue
                        val samples = d.decode(chunk, 1, chunk.size - 1)
                        if (samples.isEmpty()) continue
                        Gain.boost(samples, samples.size, Gain.PLAYBACK)
                        track.write(samples, 0, samples.size)
                    } else {
                        continue
                    }
                    pre++
                    // Pequeño prebúfer (3 chunks = 120 ms) para absorber jitter de red
                    if (!started && pre >= 3) {
                        track.play()
                        started = true
                    }
                }
            } finally {
                try {
                    boost?.release()
                } catch (e: Exception) {
                }
                dec?.release()
                try {
                    track.stop()
                } catch (e: Exception) {
                }
                track.release()
            }
        }
    }

    // ------------------------------------------------------- Notificación/locks

    private fun buildNotif(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Wavko")
            .setContentText(if (transmitting) getString(R.string.transmitting_dots) else text)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        if (state == CONNECTED) {
            b.addAction(
                0,
                if (transmitting || wantTalk) getString(R.string.action_stop) else getString(R.string.action_talk),
                PttWidgetProvider.togglePendingIntent(this, 3)
            )
        }
        return b.build()
    }

    private fun notifyInvite(fromName: String, channel: String, pass: String) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(INVITE_CHANNEL_ID, getString(R.string.notif_invites), NotificationManager.IMPORTANCE_HIGH)
            )
            val who = fromName.ifBlank { getString(R.string.a_friend) }
            val pi = PendingIntent.getActivity(
                this, 10,
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra(MainActivity.EXTRA_INVITE_CHANNEL, channel)
                    .putExtra(MainActivity.EXTRA_INVITE_PASS, pass)
                    .putExtra(MainActivity.EXTRA_INVITE_FROM, who),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(this, INVITE_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(getString(R.string.invite_title, who))
                .setContentText(getString(R.string.invite_text, channel))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(NOTIF_ID + 1, n)
        } catch (e: Exception) {
            // sin permiso de notificaciones: se ignora
        }
    }

    private fun startFg(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Wavko", NotificationManager.IMPORTANCE_LOW)
        )
        val n = buildNotif(text)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun updateNotif(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotif(text))
        } catch (e: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        try {
            if (wakeLock == null) {
                val pm = getSystemService(PowerManager::class.java)
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wavko:ptt").apply {
                    setReferenceCounted(false)
                }
            }
            if (wakeLock?.isHeld != true) wakeLock?.acquire()

            if (wifiLock == null) {
                val wm = applicationContext.getSystemService(WifiManager::class.java)
                val mode = if (Build.VERSION.SDK_INT >= 29) {
                    WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                } else {
                    WifiManager.WIFI_MODE_FULL_HIGH_PERF
                }
                wifiLock = wm?.createWifiLock(mode, "wavko:wifi")?.apply {
                    setReferenceCounted(false)
                }
            }
            if (wifiLock?.isHeld != true) wifiLock?.acquire()
        } catch (e: Exception) {
        }
    }

    private fun releaseLocks() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (e: Exception) {
        }
    }
}
