package app.walkie.ptt

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.LinearGradient
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin

/**
 * Dibujo por capas del personaje Wavko (2D con apariencia 3D). Cada parte (cuerpo, antena, rostro,
 * sombrero, ropa, accesorios, calzado) es una función independiente, así que se combinan sin imágenes.
 * Espacio de diseño: 200 x 350. Este archivo se genera a partir de la fuente común del dibujo.
 */
object AvatarArt {
    const val W = 200f
    const val H = 350f

    private lateinit var cv: Canvas
    private val P = Paint(Paint.ANTI_ALIAS_FLAG)
    private val R = RectF()
    private val PA = Path()

    private var T = 0.0
    private var CS = 1.0
    private var YS = 0.0
    private var BACK = false
    private var FULL = true
    private var SK = 0
    private var HT = 0
    private var AN = 0
    private var FC = 0
    private var CL = 0
    private var AC = 0
    private var SH = 0

    /**
     * Dibuja el personaje [packed] (ver [Avatar]) en el espacio de diseño; la escala la pone quien llama.
     * [yaw] es el giro sobre el eje vertical en radianes: cada capa se coloca a su profundidad,
     * así que al girar se ve el grosor del cuerpo y la parte de atrás.
     */
    fun render(c: Canvas, packed: Int, t: Double, yaw: Double, full: Boolean) {
        cv = c
        T = t
        FULL = full
        var k = kotlin.math.cos(yaw)
        if (kotlin.math.abs(k) < 0.07) k = if (k < 0) -0.07 else 0.07
        CS = k
        YS = kotlin.math.sin(yaw)
        BACK = k < 0
        if ((packed and (1 shl 24)) == 0) {
            SK = packed % 10; HT = 0; AN = 0; FC = 0; CL = 0; AC = 0; SH = 0
        } else {
            SK = packed and 15
            HT = (packed shr 4) and 7
            AN = (packed shr 7) and 7
            FC = (packed shr 10) and 15
            CL = (packed shr 14) and 7
            AC = (packed shr 17) and 15
            SH = (packed shr 21) and 3
        }
        cv.save()
        cv.translate(0f, 30f)
        drawAvatar()
        cv.restore()
    }

    // ---- utilidades de dibujo (mismas funciones que en la vista previa de pruebas)

    private fun sn(x: Double): Double = sin(x)
    private fun fl(x: Double): Int = floor(x).toInt()

    private fun colA(s: String, m: Double): Int {
        val i = s.indexOf('@')
        var a = 1.0
        var b = s
        if (i >= 0) {
            a = s.substring(i + 1).toDouble()
            b = s.substring(0, i)
        }
        val c = Color.parseColor(b)
        return Color.argb(min(255.0, a * m * 255.0).toInt(), Color.red(c), Color.green(c), Color.blue(c))
    }

    private fun col(s: String): Int = colA(s, 1.0)

    private fun fillP(c: String) {
        P.reset()
        P.isAntiAlias = true
        P.style = Paint.Style.FILL
        P.color = col(c)
    }

    private fun strokeP(w: Double, c: String) {
        P.reset()
        P.isAntiAlias = true
        P.style = Paint.Style.STROKE
        P.strokeWidth = w.toFloat()
        P.strokeCap = Paint.Cap.ROUND
        P.strokeJoin = Paint.Join.ROUND
        P.color = col(c)
    }

    private fun gradP(t: Double, b: Double, c1: String, c2: String) {
        P.reset()
        P.isAntiAlias = true
        P.style = Paint.Style.FILL
        P.shader = LinearGradient(0f, t.toFloat(), 0f, b.toFloat(), col(c1), col(c2), Shader.TileMode.CLAMP)
    }

    private fun setRR(l: Double, t: Double, r: Double, b: Double) {
        R.set(l.toFloat(), t.toFloat(), r.toFloat(), b.toFloat())
    }

    private fun rad(l: Double, t: Double, r: Double, b: Double, k: Double): Float =
        min(k, min((r - l) / 2.0, (b - t) / 2.0)).toFloat()

    private fun push() { cv.save() }
    private fun pop() { cv.restore() }
    private fun mv(x: Double, y: Double) { cv.translate(x.toFloat(), y.toFloat()) }

    private fun scl(sx: Double, sy: Double, px: Double, py: Double) {
        cv.translate(px.toFloat(), py.toFloat())
        cv.scale(sx.toFloat(), sy.toFloat())
        cv.translate(-px.toFloat(), -py.toFloat())
    }

    private fun clipRR(l: Double, t: Double, r: Double, b: Double, k: Double) {
        setRR(l, t, r, b)
        PA.reset()
        val q = rad(l, t, r, b, k)
        PA.addRoundRect(R, q, q, Path.Direction.CW)
        cv.clipPath(PA)
    }

    private fun rr(l: Double, t: Double, r: Double, b: Double, k: Double, c: String) {
        setRR(l, t, r, b)
        fillP(c)
        val q = rad(l, t, r, b, k)
        cv.drawRoundRect(R, q, q, P)
    }

    private fun rrg(l: Double, t: Double, r: Double, b: Double, k: Double, c1: String, c2: String) {
        setRR(l, t, r, b)
        gradP(t, b, c1, c2)
        val q = rad(l, t, r, b, k)
        cv.drawRoundRect(R, q, q, P)
    }

    private fun rrh(l: Double, t: Double, r: Double, b: Double, k: Double, c1: String, c2: String) {
        setRR(l, t, r, b)
        P.reset()
        P.isAntiAlias = true
        P.style = Paint.Style.FILL
        P.shader = LinearGradient(l.toFloat(), 0f, r.toFloat(), 0f, col(c1), col(c2), Shader.TileMode.CLAMP)
        val q = rad(l, t, r, b, k)
        cv.drawRoundRect(R, q, q, P)
    }

    private fun rrs(l: Double, t: Double, r: Double, b: Double, k: Double, w: Double, c: String) {
        setRR(l, t, r, b)
        strokeP(w, c)
        val q = rad(l, t, r, b, k)
        cv.drawRoundRect(R, q, q, P)
    }

    private fun circ(x: Double, y: Double, r: Double, c: String) {
        fillP(c)
        cv.drawCircle(x.toFloat(), y.toFloat(), r.toFloat(), P)
    }

    private fun circg(x: Double, y: Double, r: Double, c1: String, c2: String) {
        P.reset()
        P.isAntiAlias = true
        P.style = Paint.Style.FILL
        P.shader = RadialGradient(
            (x - r * 0.3).toFloat(), (y - r * 0.35).toFloat(), (r * 1.1).toFloat(),
            col(c1), col(c2), Shader.TileMode.CLAMP
        )
        cv.drawCircle(x.toFloat(), y.toFloat(), r.toFloat(), P)
    }

    private fun circs(x: Double, y: Double, r: Double, w: Double, c: String) {
        strokeP(w, c)
        cv.drawCircle(x.toFloat(), y.toFloat(), r.toFloat(), P)
    }

    private fun oval(l: Double, t: Double, r: Double, b: Double, c: String) {
        setRR(l, t, r, b)
        fillP(c)
        cv.drawOval(R, P)
    }

    private fun ovalg(l: Double, t: Double, r: Double, b: Double, c1: String, c2: String) {
        setRR(l, t, r, b)
        gradP(t, b, c1, c2)
        cv.drawOval(R, P)
    }

    private fun ovals(l: Double, t: Double, r: Double, b: Double, w: Double, c: String) {
        setRR(l, t, r, b)
        strokeP(w, c)
        cv.drawOval(R, P)
    }

    private fun line(x1: Double, y1: Double, x2: Double, y2: Double, w: Double, c: String) {
        strokeP(w, c)
        cv.drawLine(x1.toFloat(), y1.toFloat(), x2.toFloat(), y2.toFloat(), P)
    }

    private fun arc(x: Double, y: Double, r: Double, st: Double, sw: Double, w: Double, c: String) {
        setRR(x - r, y - r, x + r, y + r)
        strokeP(w, c)
        cv.drawArc(R, st.toFloat(), sw.toFloat(), false, P)
    }

    private fun pie(x: Double, y: Double, r: Double, st: Double, sw: Double, c: String) {
        setRR(x - r, y - r, x + r, y + r)
        fillP(c)
        cv.drawArc(R, st.toFloat(), sw.toFloat(), true, P)
    }

    private fun poly(c: String, vararg p: Double) {
        PA.reset()
        PA.moveTo(p[0].toFloat(), p[1].toFloat())
        var i = 2
        while (i + 1 < p.size) {
            PA.lineTo(p[i].toFloat(), p[i + 1].toFloat())
            i += 2
        }
        PA.close()
        fillP(c)
        cv.drawPath(PA, P)
    }

    private fun polys(w: Double, c: String, vararg p: Double) {
        PA.reset()
        PA.moveTo(p[0].toFloat(), p[1].toFloat())
        var i = 2
        while (i + 1 < p.size) {
            PA.lineTo(p[i].toFloat(), p[i + 1].toFloat())
            i += 2
        }
        strokeP(w, c)
        cv.drawPath(PA, P)
    }

    private fun glow(x: Double, y: Double, r: Double, c: String) {
        P.reset()
        P.isAntiAlias = true
        P.style = Paint.Style.FILL
        P.shader = RadialGradient(x.toFloat(), y.toFloat(), r.toFloat(), colA(c, 1.0), colA(c, 0.0), Shader.TileMode.CLAMP)
        cv.drawCircle(x.toFloat(), y.toFloat(), r.toFloat(), P)
    }

    // ---- partes del personaje (fuente común)

    // ===== Paleta por skin =====
    private fun hi(): String {
      if (SK == 0) { return "#9B6BFF" }
      if (SK == 1) { return "#454B59" }
      if (SK == 2) { return "#FDE68A" }
      if (SK == 3) { return "#27227A" }
      if (SK == 4) { return "#F05252" }
      if (SK == 5) { return "#9BE0FF" }
      if (SK == 6) { return "#A3E635" }
      if (SK == 7) { return "#F0F9FF" }
      if (SK == 8) { return "#7C8F45" }
      if (SK == 10) { return "#F43F5E" }
      if (SK == 11) { return "#4ADE80" }
      if (SK == 12) { return "#FFFFFF" }
      if (SK == 13) { return "#EF4444" }
      return "#34343B"
    }
    private fun lo(): String {
      if (SK == 0) { return "#4A1FA8" }
      if (SK == 1) { return "#101319" }
      if (SK == 2) { return "#B45309" }
      if (SK == 3) { return "#0B0724" }
      if (SK == 4) { return "#7A1414" }
      if (SK == 5) { return "#0B6FB3" }
      if (SK == 6) { return "#3F6212" }
      if (SK == 7) { return "#93C5FD" }
      if (SK == 8) { return "#3D4A1F" }
      if (SK == 10) { return "#9F1239" }
      if (SK == 11) { return "#166534" }
      if (SK == 12) { return "#BAE6FD" }
      if (SK == 13) { return "#991B1B" }
      return "#0A0A0D"
    }
    private fun ac(): String {
      if (SK == 0) { return "#C4B5FD" }
      if (SK == 1) { return "#A5B4FC" }
      if (SK == 2) { return "#FFF7CC" }
      if (SK == 3) { return "#22E5FF" }
      if (SK == 4) { return "#FFB4B4" }
      if (SK == 5) { return "#E0F7FF" }
      if (SK == 6) { return "#D9F99D" }
      if (SK == 7) { return "#FFFFFF" }
      if (SK == 8) { return "#D9F99D" }
      if (SK == 10) { return "#FFFFFF" }
      if (SK == 11) { return "#FDE047" }
      if (SK == 12) { return "#38BDF8" }
      if (SK == 13) { return "#FDE047" }
      return "#38BDF8"
    }
    private fun dk(): String {
      if (SK == 2) { return "#5B3A06" }
      if (SK == 7) { return "#3B5A8A" }
      if (SK == 5) { return "#0B4A80" }
      if (SK == 12) { return "#1E3A5F" }
      return "#140F26"
    }
    private fun blink(): Double {
      if (fl(T * 10.0) % 40 == 0) { return 0.12 }
      return 1.0
    }

    // ===== Antena =====
    private fun antenna() {
      val sw = sn(T * 2.2) * 2.5
      push()
      mv(0.0, 0.0)
      rr(112.0, 66.0, 126.0, 80.0, 4.0, "#15151C")
      if (AN == 0) {
        rrg(114.0, 22.0 + 0.0, 124.0, 74.0, 5.0, "#3A3A46", "#0E0E14")
        rr(114.0, 40.0, 124.0, 46.0, 1.0, ac())
        rr(116.0, 26.0, 118.5, 64.0, 1.5, "#FFFFFF@0.22")
      } else if (AN == 1) {
        rrg(114.0, 46.0, 124.0, 74.0, 5.0, "#3A3A46", "#0E0E14")
        rr(114.0, 56.0, 124.0, 60.0, 1.0, ac())
        rr(116.0, 49.0, 118.5, 68.0, 1.5, "#FFFFFF@0.22")
      } else if (AN == 2) {
        rrg(116.0, -24.0, 122.0, 74.0, 3.0, "#4A4A57", "#101018")
        circg(119.0 + sw * 0.8, -24.0, 6.0, "#FFFFFF", ac())
        rr(116.0, 20.0, 122.0, 25.0, 1.0, ac())
      } else if (AN == 3) {
        polys(5.0, "#1A1A22", 119.0, 74.0, 114.0 + sw * 0.3, 60.0, 124.0 + sw * 0.6, 46.0, 114.0 + sw, 32.0, 124.0 + sw * 1.4, 18.0, 119.0 + sw * 1.8, 6.0)
        polys(1.6, ac(), 119.0, 74.0, 114.0 + sw * 0.3, 60.0, 124.0 + sw * 0.6, 46.0, 114.0 + sw, 32.0, 124.0 + sw * 1.4, 18.0, 119.0 + sw * 1.8, 6.0)
        circg(119.0 + sw * 1.8, 5.0, 5.0, "#FFFFFF", ac())
      } else if (AN == 4) {
        glow(119.0, 40.0, 34.0, "#22D3EE@0.55")
        rrg(114.0, 20.0, 124.0, 74.0, 5.0, "#A5F3FC", "#0891B2")
        rr(116.0, 24.0, 119.0, 70.0, 1.5, "#FFFFFF@0.7")
        rr(113.0, 36.0, 125.0, 39.0, 1.0, "#0E7490")
        rr(113.0, 52.0, 125.0, 55.0, 1.0, "#0E7490")
      } else if (AN == 5) {
        rrg(114.0, 14.0, 124.0, 74.0, 5.0, "#33333F", "#0E0E14")
        rr(114.0, 18.0, 124.0, 32.0, 3.0, cyc(0))
        rr(114.0, 34.0, 124.0, 48.0, 1.0, cyc(1))
        rr(114.0, 50.0, 124.0, 64.0, 1.0, cyc(2))
        glow(119.0, 20.0, 22.0, cyc(0) + "@0.5")
      } else if (AN == 6) {
        rrg(116.0, 24.0, 122.0, 74.0, 3.0, "#3A3A46", "#0E0E14")
        glow(119.0, 14.0, 26.0, "#FACC15@0.6")
        poly("#FDE047", 119.0, -4.0, 123.5, 8.0, 136.0, 9.0, 126.0, 17.0, 130.0, 30.0, 119.0, 22.0, 108.0, 30.0, 112.0, 17.0, 102.0, 9.0, 114.5, 8.0)
        poly("#FFFFFF@0.5", 119.0, -1.0, 122.0, 8.0, 119.0, 12.0, 116.0, 8.0)
      } else {
        rrg(116.0, 26.0, 122.0, 74.0, 3.0, "#3A3A46", "#0E0E14")
        rr(114.0, 28.0, 124.0, 34.0, 2.0, "#FACC15")
        if (fl(T * 6.0) % 3 != 0) {
          glow(119.0, 10.0, 30.0, "#FDE047@0.55")
          polys(2.5, "#FEF08A", 100.0, 4.0, 108.0, 12.0, 103.0, 16.0, 112.0, 26.0)
          polys(2.5, "#FEF08A", 138.0, 4.0, 130.0, 12.0, 135.0, 16.0, 126.0, 26.0)
        }
        poly("#FDE047", 122.0, -8.0, 114.0, 12.0, 119.0, 12.0, 116.0, 28.0, 126.0, 6.0, 121.0, 6.0)
      }
      pop()
    }
    private fun cyc(i: Int): String {
      val k = (i + fl(T * 3.0)) % 3
      if (k == 0) { return "#F43F5E" }
      if (k == 1) { return "#22D3EE" }
      return "#A3E635"
    }

    // ===== Cuerpo =====
    private fun bodyShape() {
      // sombra de contacto del cuerpo
      rrg(54.0, 74.0, 146.0, 222.0, 26.0, hi(), lo())
      push()
      clipRR(54.0, 74.0, 146.0, 222.0, 26.0)
      skinFx()
      // brillo lateral y borde inferior oscuro
      rr(58.0, 80.0, 65.0, 205.0, 3.5, "#FFFFFF@0.22")
      rr(54.0, 206.0, 146.0, 222.0, 0.0, "#000000@0.18")
      rr(136.0, 80.0, 146.0, 222.0, 0.0, "#000000@0.14")
      // luz desde arriba a la izquierda: el lado derecho queda en penumbra y se marca un brillo suave arriba
      rrh(54.0, 74.0, 146.0, 222.0, 0.0, "#FFFFFF@0.14", "#000000@0.30")
      oval(60.0, 76.0, 128.0, 116.0, "#FFFFFF@0.09")
      rrg(54.0, 74.0, 146.0, 92.0, 0.0, "#000000@0.22", "#000000@0.0")
      rr(143.0, 92.0, 146.0, 206.0, 1.5, "#FFFFFF@0.16")
      pop()
      if (SK == 3) {
        rrs(54.0, 74.0, 146.0, 222.0, 26.0, 7.0, "#22E5FF@0.25")
        rrs(54.0, 74.0, 146.0, 222.0, 26.0, 2.5, "#22E5FF")
        rrs(58.0, 78.0, 142.0, 218.0, 22.0, 1.5, "#F0ABFC@0.9")
      } else {
        rrs(54.0, 74.0, 146.0, 222.0, 26.0, 2.0, "#FFFFFF@0.25")
      }
    }
    private fun skinFx() {
      if (SK == 8) {
        oval(40.0, 90.0, 80.0, 120.0, "#3D4A1F")
        oval(100.0, 70.0, 150.0, 104.0, "#2B3315")
        oval(60.0, 140.0, 110.0, 170.0, "#556B2F")
        oval(108.0, 150.0, 154.0, 186.0, "#2B3315")
        oval(44.0, 188.0, 92.0, 226.0, "#3D4A1F")
        oval(100.0, 196.0, 150.0, 230.0, "#5C6E32")
        oval(78.0, 108.0, 100.0, 134.0, "#8A9A52@0.6")
      } else if (SK == 9) {
        line(40.0, 80.0, 160.0, 200.0, 1.2, "#5A5A66@0.55")
        line(40.0, 100.0, 160.0, 220.0, 1.2, "#5A5A66@0.55")
        line(40.0, 60.0, 160.0, 180.0, 1.2, "#5A5A66@0.55")
        line(40.0, 120.0, 160.0, 240.0, 1.2, "#5A5A66@0.55")
        line(160.0, 80.0, 40.0, 200.0, 1.2, "#000000@0.45")
        line(160.0, 100.0, 40.0, 220.0, 1.2, "#000000@0.45")
        line(160.0, 60.0, 40.0, 180.0, 1.2, "#000000@0.45")
        line(160.0, 120.0, 40.0, 240.0, 1.2, "#000000@0.45")
      } else if (SK == 7) {
        poly("#FFFFFF@0.55", 54.0, 74.0, 100.0, 74.0, 76.0, 150.0)
        poly("#FFFFFF@0.35", 100.0, 74.0, 146.0, 74.0, 146.0, 140.0, 118.0, 120.0)
        poly("#BFDBFE@0.6", 76.0, 150.0, 100.0, 74.0, 118.0, 120.0)
        poly("#FFFFFF@0.4", 54.0, 222.0, 54.0, 150.0, 90.0, 222.0)
        poly("#93C5FD@0.5", 146.0, 222.0, 146.0, 170.0, 110.0, 222.0)
        star(70.0, 100.0, 7.0, "#FFFFFF")
        star(132.0, 196.0, 5.0, "#FFFFFF")
      } else if (SK == 2) {
        rr(54.0, 150.0, 146.0, 158.0, 0.0, "#FFFFFF@0.25")
        poly("#FFFFFF@0.28", 54.0, 74.0, 90.0, 74.0, 54.0, 118.0)
      } else if (SK == 10) {
        rrg(50.0, 196.0, 150.0, 226.0, 0.0, "#FFFFFF", "#E2E8F0")
        circ(60.0, 197.0, 6.0, "#FFFFFF")
        circ(76.0, 199.0, 7.0, "#FFFFFF")
        circ(94.0, 198.0, 6.0, "#FFFFFF")
        circ(112.0, 199.0, 7.0, "#FFFFFF")
        circ(130.0, 197.0, 6.0, "#FFFFFF")
        rrg(50.0, 74.0, 150.0, 82.0, 0.0, "#FFFFFF", "#E2E8F0")
        snow()
      } else if (SK == 11) {
        polys(3.0, "#FDE047", 54.0, 96.0, 80.0, 108.0, 54.0, 122.0, 100.0, 134.0, 54.0, 150.0)
        polys(3.0, "#FDE047", 146.0, 108.0, 120.0, 122.0, 146.0, 138.0, 112.0, 150.0, 146.0, 170.0)
        circg(62.0, 112.0, 5.0, "#FCA5A5", "#DC2626")
        circg(132.0, 128.0, 5.0, "#93C5FD", "#2563EB")
        circg(70.0, 152.0, 5.0, "#FDE68A", "#D97706")
        circg(130.0, 166.0, 5.0, "#F0ABFC", "#C026D3")
        circg(66.0, 190.0, 5.0, "#FCA5A5", "#DC2626")
        circg(136.0, 196.0, 5.0, "#93C5FD", "#2563EB")
        circg(100.0, 212.0, 5.0, "#FDE68A", "#D97706")
      } else if (SK == 12) {
        snow()
        rr(54.0, 206.0, 146.0, 222.0, 0.0, "#FFFFFF@0.7")
        circ(100.0, 168.0, 2.6, "#1F2937")
        circ(100.0, 178.0, 2.6, "#1F2937")
        circ(100.0, 188.0, 2.6, "#1F2937")
      } else if (SK == 13) {
        rr(54.0, 150.0, 146.0, 164.0, 0.0, "#FDE047")
        rr(94.0, 74.0, 106.0, 222.0, 0.0, "#FDE047")
        rr(54.0, 151.0, 146.0, 153.0, 0.0, "#FFFFFF@0.5")
        rr(95.0, 74.0, 98.0, 222.0, 0.0, "#FFFFFF@0.5")
      } else if (SK == 0 || SK == 1) {
        rr(54.0, 150.0, 146.0, 152.0, 0.0, "#FFFFFF@0.12")
      }
    }
    private fun snow() {
      circ(66.0, 100.0, 2.2, "#FFFFFF@0.9")
      circ(134.0, 112.0, 1.8, "#FFFFFF@0.8")
      circ(60.0, 154.0, 2.0, "#FFFFFF@0.8")
      circ(140.0, 160.0, 2.4, "#FFFFFF@0.9")
      circ(74.0, 212.0, 1.8, "#FFFFFF@0.8")
      circ(126.0, 206.0, 2.0, "#FFFFFF@0.9")
      star(138.0, 92.0, 4.0, "#FFFFFF")
      star(62.0, 176.0, 4.0, "#FFFFFF")
    }
    private fun star(x: Double, y: Double, r: Double, c: String) {
      poly(c, x, y - r, x + r * 0.28, y - r * 0.28, x + r, y, x + r * 0.28, y + r * 0.28, x, y + r, x - r * 0.28, y + r * 0.28, x - r, y, x - r * 0.28, y - r * 0.28)
    }
    private fun sideParts() {
      // botón lateral (PTT) y perilla superior
      rrg(46.0, 104.0, 56.0, 142.0, 4.0, dk(), "#000000")
      rr(47.0, 108.0, 50.0, 138.0, 1.5, "#FFFFFF@0.25")
      rrg(62.0, 62.0, 80.0, 76.0, 4.0, "#2A2A33", "#0C0C12")
      rr(65.0, 64.0, 69.0, 74.0, 1.0, ac())
    }
    private fun facePanel() {
      rrg(64.0, 86.0, 136.0, 152.0, 16.0, "#1C1736", "#07050F")
      rrs(64.0, 86.0, 136.0, 152.0, 16.0, 1.5, "#FFFFFF@0.18")
      rr(70.0, 90.0, 130.0, 96.0, 3.0, "#FFFFFF@0.08")
    }
    private fun wPanel() {
      rrg(70.0, 162.0, 130.0, 208.0, 12.0, "#1C1736", "#07050F")
      rrs(70.0, 162.0, 130.0, 208.0, 12.0, 1.5, "#FFFFFF@0.15")
      wLogo(100.0, 185.0, 1.0, ac())
    }
    private fun wLogo(x: Double, y: Double, s: Double, c: String) {
      glow(x, y, 26.0 * s, c + "@0.35")
      polys(6.0 * s, c, x - 17.0 * s, y - 11.0 * s, x - 9.0 * s, y + 10.0 * s, x, y - 3.0 * s, x + 9.0 * s, y + 10.0 * s, x + 17.0 * s, y - 11.0 * s)
    }
    private fun backPlate() {
      rrg(66.0, 96.0, 134.0, 200.0, 12.0, "#000000@0.2", "#000000@0.07")
      line(78.0, 108.0, 122.0, 108.0, 3.0, "#000000@0.25")
      line(78.0, 120.0, 122.0, 120.0, 3.0, "#000000@0.25")
      line(78.0, 132.0, 122.0, 132.0, 3.0, "#000000@0.25")
      line(78.0, 144.0, 122.0, 144.0, 3.0, "#000000@0.25")
      rrg(76.0, 160.0, 124.0, 196.0, 8.0, "#000000@0.3", "#000000@0.15")
      wLogo(100.0, 178.0, 0.7, ac())
    }

    // ===== Rostros =====
    private fun eye(x: Double, y: Double, k: Double, c: String) {
      oval(x - 7.5, y - 10.0 * k, x + 7.5, y + 10.0 * k, c)
      if (k > 0.5) { circ(x - 2.0, y - 4.0, 2.6, "#FFFFFF@0.9") }
    }
    private fun smile(c: String) {
      arc(100.0, 124.0, 14.0, 28.0, 124.0, 4.5, c)
    }
    private fun face() {
      val c = ac()
      val b = blink()
      if (FC == 0) {
        eye(84.0, 112.0, b, c)
        eye(116.0, 112.0, b, c)
        smile(c)
      } else if (FC == 1) {
        eye(84.0, 112.0, b, c)
        eye(116.0, 112.0, b, c)
        line(89.0, 136.0, 111.0, 136.0, 4.5, c)
      } else if (FC == 2) {
        eye(84.0, 114.0, b * 0.75, c)
        eye(116.0, 114.0, b * 0.75, c)
        line(72.0, 98.0, 92.0, 106.0, 4.5, "#F87171")
        line(128.0, 98.0, 108.0, 106.0, 4.5, "#F87171")
        arc(100.0, 144.0, 12.0, 208.0, 124.0, 4.5, c)
      } else if (FC == 3) {
        arc(84.0, 118.0, 9.0, 198.0, 144.0, 4.5, c)
        arc(116.0, 118.0, 9.0, 198.0, 144.0, 4.5, c)
        pie(100.0, 126.0, 15.0, 0.0, 180.0, "#2A0B2E")
        oval(91.0, 133.0, 109.0, 142.0, "#FB7185")
        rr(88.0, 126.0, 112.0, 130.0, 1.0, "#FFFFFF")
      } else if (FC == 4) {
        eye(84.0, 112.0, b, c)
        polys(4.5, c, 108.0, 106.0, 120.0, 112.0, 108.0, 118.0)
        smile(c)
        oval(97.0, 132.0, 111.0, 142.0, "#FB7185")
      } else if (FC == 5) {
        circs(84.0, 112.0, 9.0, 4.0, c)
        circs(116.0, 112.0, 9.0, 4.0, c)
        circ(84.0, 112.0, 3.5, "#FFFFFF")
        circ(116.0, 112.0, 3.5, "#FFFFFF")
        oval(92.0, 128.0, 108.0, 146.0, "#2A0B2E")
        ovals(92.0, 128.0, 108.0, 146.0, 3.5, c)
      } else if (FC == 6) {
        glow(84.0, 112.0, 26.0, c + "@0.7")
        glow(116.0, 112.0, 26.0, c + "@0.7")
        eye(84.0, 112.0, b, "#FFFFFF")
        eye(116.0, 112.0, b, "#FFFFFF")
        arc(100.0, 128.0, 10.0, 30.0, 120.0, 3.5, c)
      } else if (FC == 7) {
        rrg(66.0, 102.0, 98.0, 126.0, 9.0, "#2B2B55", "#05050C")
        rrg(102.0, 102.0, 134.0, 126.0, 9.0, "#2B2B55", "#05050C")
        rr(98.0, 106.0, 102.0, 110.0, 1.0, "#05050C")
        line(72.0, 107.0, 84.0, 107.0, 2.5, "#FFFFFF@0.55")
        line(108.0, 107.0, 120.0, 107.0, 2.5, "#FFFFFF@0.55")
        rrs(66.0, 102.0, 98.0, 126.0, 9.0, 2.0, "#FFFFFF@0.35")
        rrs(102.0, 102.0, 134.0, 126.0, 9.0, 2.0, "#FFFFFF@0.35")
        arc(100.0, 128.0, 13.0, 28.0, 124.0, 4.5, c)
      } else if (FC == 8) {
        glow(100.0, 112.0, 50.0, "#22D3EE@0.4")
        rrg(64.0, 102.0, 136.0, 124.0, 11.0, "#7EEBFF", "#0369A1")
        rr(70.0, 106.0, 130.0, 111.0, 2.5, "#FFFFFF@0.65")
        rrs(64.0, 102.0, 136.0, 124.0, 11.0, 2.0, "#E0F7FF")
        arc(100.0, 130.0, 12.0, 28.0, 124.0, 4.5, c)
      } else {
        rr(64.0, 102.0, 136.0, 110.0, 0.0, "#0A0A12")
        rr(66.0, 110.0, 98.0, 118.0, 0.0, "#0A0A12")
        rr(70.0, 118.0, 94.0, 126.0, 0.0, "#0A0A12")
        rr(102.0, 110.0, 134.0, 118.0, 0.0, "#0A0A12")
        rr(106.0, 118.0, 130.0, 126.0, 0.0, "#0A0A12")
        rr(70.0, 111.0, 78.0, 115.0, 0.0, "#FFFFFF")
        rr(106.0, 111.0, 114.0, 115.0, 0.0, "#FFFFFF")
        rr(72.0, 118.0, 76.0, 122.0, 0.0, "#FFFFFF@0.7")
        rr(108.0, 118.0, 112.0, 122.0, 0.0, "#FFFFFF@0.7")
        arc(100.0, 130.0, 12.0, 28.0, 124.0, 4.5, c)
      }
    }

    // ===== Sombreros =====
    private fun hatMain(): String {
      if (SK == 2) { return "#7C2D12" }
      if (SK == 7) { return "#1E3A8A" }
      if (SK == 5) { return "#0C4A6E" }
      if (SK == 4) { return "#450A0A" }
      if (SK == 6) { return "#1A2E05" }
      if (SK == 8) { return "#2F3A18" }
      if (SK == 9) { return "#0F0F12" }
      return "#1A1236"
    }
    private fun hat() {
      val m = hatMain()
      if (HT == 1) {
        rrg(60.0, 36.0, 140.0, 84.0, 26.0, m, "#06040F")
        rr(66.0, 42.0, 80.0, 62.0, 7.0, "#FFFFFF@0.14")
        circ(100.0, 38.0, 4.5, ac())
        rrg(48.0, 70.0, 152.0, 90.0, 9.0, hi(), lo())
        rr(54.0, 73.0, 146.0, 77.0, 2.0, "#FFFFFF@0.25")
        wLogo(100.0, 58.0, 0.55, ac())
      } else if (HT == 2) {
        rrg(62.0, 30.0, 138.0, 80.0, 30.0, m, "#06040F")
        rrg(58.0, 62.0, 142.0, 86.0, 10.0, hi(), lo())
        line(68.0, 66.0, 68.0, 82.0, 2.0, "#000000@0.2")
        line(80.0, 66.0, 80.0, 82.0, 2.0, "#000000@0.2")
        line(92.0, 66.0, 92.0, 82.0, 2.0, "#000000@0.2")
        line(104.0, 66.0, 104.0, 82.0, 2.0, "#000000@0.2")
        line(116.0, 66.0, 116.0, 82.0, 2.0, "#000000@0.2")
        line(128.0, 66.0, 128.0, 82.0, 2.0, "#000000@0.2")
        circg(100.0, 26.0, 11.0, "#FFFFFF", ac())
      } else if (HT == 3) {
        ovalg(54.0, 28.0, 146.0, 98.0, "#6B7F3A", "#2B3315")
        oval(66.0, 40.0, 92.0, 56.0, "#3D4A1F")
        oval(104.0, 36.0, 132.0, 54.0, "#232B10")
        oval(86.0, 58.0, 118.0, 72.0, "#556B2F")
        rrg(50.0, 74.0, 150.0, 90.0, 7.0, "#3A4520", "#1E250D")
        line(60.0, 54.0, 56.0, 92.0, 3.0, "#1E250D")
        star(100.0, 56.0, 8.0, "#FDE047")
      } else if (HT == 4) {
        glow(100.0, 56.0, 50.0, "#FACC15@0.4")
        poly("#FACC15", 62.0, 84.0, 62.0, 44.0, 81.0, 62.0, 100.0, 30.0, 119.0, 62.0, 138.0, 44.0, 138.0, 84.0)
        poly("#FDE68A", 62.0, 84.0, 62.0, 44.0, 72.0, 54.0, 72.0, 84.0)
        rrg(62.0, 72.0, 138.0, 88.0, 4.0, "#FDE047", "#B45309")
        circ(100.0, 80.0, 5.0, "#F43F5E")
        circ(78.0, 80.0, 3.5, "#22D3EE")
        circ(122.0, 80.0, 3.5, "#22D3EE")
        circ(100.0, 29.0, 4.0, "#FFFFFF")
        circ(62.0, 43.0, 3.5, "#FFFFFF")
        circ(138.0, 43.0, 3.5, "#FFFFFF")
      } else if (HT == 5) {
        glow(100.0, 62.0, 56.0, "#22D3EE@0.3")
        ovalg(54.0, 26.0, 146.0, 98.0, "#3B4A9A", "#0E1240")
        rrg(62.0, 56.0, 138.0, 80.0, 12.0, "#0F172A", "#020617")
        rr(66.0, 62.0, 134.0, 68.0, 3.0, "#22D3EE")
        rr(70.0, 59.0, 96.0, 61.0, 1.0, "#FFFFFF@0.7")
        rr(96.0, 30.0, 104.0, 56.0, 3.0, "#22D3EE@0.8")
        circ(55.0, 70.0, 9.0, "#1E1B4B")
        circ(145.0, 70.0, 9.0, "#1E1B4B")
        circs(55.0, 70.0, 5.0, 2.0, "#22D3EE")
        circs(145.0, 70.0, 5.0, 2.0, "#22D3EE")
      } else if (HT == 7) {
        poly("#B91C1C", 64.0, 80.0, 72.0, 48.0, 98.0, 28.0, 130.0, 30.0, 152.0, 46.0, 144.0, 62.0, 138.0, 80.0)
        poly("#DC2626", 64.0, 80.0, 72.0, 48.0, 98.0, 28.0, 112.0, 30.0, 100.0, 54.0, 96.0, 80.0)
        rr(80.0, 38.0, 86.0, 70.0, 3.0, "#FFFFFF@0.18")
        rrg(56.0, 68.0, 144.0, 92.0, 12.0, "#FFFFFF", "#CBD5E1")
        circg(152.0, 50.0, 11.0, "#FFFFFF", "#CBD5E1")
      } else if (HT == 6) {
        oval(44.0, 74.0, 156.0, 96.0, "#0B1020")
        rrg(66.0, 4.0, 134.0, 84.0, 7.0, "#2A3350", "#0A0F1E")
        rr(66.0, 62.0, 134.0, 74.0, 0.0, "#7C3AED")
        rr(92.0, 60.0, 108.0, 76.0, 2.0, "#FACC15")
        rr(97.0, 65.0, 103.0, 71.0, 1.0, "#0B1020")
        rr(72.0, 10.0, 78.0, 56.0, 3.0, "#FFFFFF@0.12")
      }
    }

    // ===== Ropa =====
    private fun clothMain(): String {
      if (CL == 1) { return "#F1F5F9" }
      if (CL == 2) { return "#3A2A24" }
      if (CL == 3) { return "#5B6B34" }
      if (CL == 4) { return "#E2E8F0" }
      if (CL == 5) { return "#7C3AED" }
      if (CL == 6) { return "#DC2626" }
      return "#111827"
    }
    private fun cloth() {
      if (CL == 0) { return }
      val m = clothMain()
      push()
      clipRR(54.0, 74.0, 146.0, 222.0, 26.0)
      if (CL == 1) {
        rrg(50.0, 152.0, 150.0, 226.0, 0.0, "#FFFFFF", "#CBD5E1")
        rr(50.0, 152.0, 150.0, 158.0, 0.0, "#94A3B8@0.5")
        wLogo(100.0, 188.0, 0.9, "#7C3AED")
      } else if (CL == 2) {
        rrg(50.0, 150.0, 150.0, 226.0, 0.0, "#4A3830", "#1E1410")
        poly("#2A1D18", 50.0, 150.0, 82.0, 150.0, 100.0, 176.0, 118.0, 150.0, 150.0, 150.0, 150.0, 164.0, 108.0, 190.0, 92.0, 190.0, 50.0, 164.0)
        line(100.0, 176.0, 100.0, 226.0, 3.0, "#CBD5E1")
        rr(70.0, 196.0, 88.0, 204.0, 2.0, "#000000@0.25")
        rr(112.0, 196.0, 130.0, 204.0, 2.0, "#000000@0.25")
        line(60.0, 150.0, 60.0, 226.0, 2.0, "#F59E0B")
        line(140.0, 150.0, 140.0, 226.0, 2.0, "#F59E0B")
      } else if (CL == 3) {
        rrg(50.0, 150.0, 150.0, 226.0, 0.0, "#6B7D3C", "#3A4620")
        oval(60.0, 170.0, 84.0, 190.0, "#3A4620")
        oval(116.0, 176.0, 142.0, 198.0, "#4A5A28")
        rr(60.0, 160.0, 88.0, 184.0, 3.0, "#4A5A28")
        rr(112.0, 160.0, 140.0, 184.0, 3.0, "#4A5A28")
        rr(62.0, 162.0, 86.0, 166.0, 1.0, "#FFFFFF@0.2")
        rr(114.0, 162.0, 138.0, 166.0, 1.0, "#FFFFFF@0.2")
        rr(90.0, 152.0, 110.0, 226.0, 0.0, "#2F3A18")
        rr(52.0, 206.0, 148.0, 214.0, 0.0, "#1F2610")
        rr(94.0, 205.0, 106.0, 215.0, 2.0, "#FACC15")
      } else if (CL == 4) {
        rrg(50.0, 150.0, 150.0, 226.0, 0.0, "#F8FAFC", "#94A3B8")
        polys(2.5, "#22D3EE", 62.0, 150.0, 76.0, 182.0, 100.0, 192.0, 124.0, 182.0, 138.0, 150.0)
        polys(2.5, "#22D3EE", 70.0, 226.0, 78.0, 204.0, 122.0, 204.0, 130.0, 226.0)
        glow(100.0, 192.0, 30.0, "#22D3EE@0.35")
        circ(100.0, 192.0, 6.0, "#22D3EE")
      } else if (CL == 5) {
        rrg(50.0, 148.0, 150.0, 226.0, 0.0, "#8B5CF6", "#5B21B6")
        rrg(66.0, 190.0, 134.0, 218.0, 8.0, "#6D28D9", "#4C1D95")
        line(88.0, 150.0, 88.0, 176.0, 2.5, "#FFFFFF")
        line(112.0, 150.0, 112.0, 176.0, 2.5, "#FFFFFF")
        circ(88.0, 178.0, 3.0, "#FFFFFF")
        circ(112.0, 178.0, 3.0, "#FFFFFF")
      } else if (CL == 6) {
        rrg(50.0, 150.0, 150.0, 226.0, 0.0, "#EF4444", "#991B1B")
        rr(50.0, 160.0, 150.0, 166.0, 0.0, "#FFFFFF")
        rr(50.0, 172.0, 150.0, 175.0, 0.0, "#FFFFFF")
        rr(76.0, 184.0, 124.0, 214.0, 4.0, "#000000@0.15")
        polys(7.0, "#FFFFFF", 90.0, 188.0, 90.0, 210.0)
        rrs(98.0, 188.0, 112.0, 210.0, 6.0, 5.0, "#FFFFFF")
      } else {
        rrg(50.0, 150.0, 150.0, 226.0, 0.0, "#1F2937", "#030712")
        poly("#F8FAFC", 78.0, 150.0, 122.0, 150.0, 100.0, 200.0)
        poly("#CBD5E1", 100.0, 200.0, 122.0, 150.0, 108.0, 150.0)
        poly("#030712", 74.0, 150.0, 90.0, 150.0, 100.0, 190.0, 76.0, 226.0, 50.0, 226.0)
        poly("#030712", 126.0, 150.0, 110.0, 150.0, 100.0, 190.0, 124.0, 226.0, 150.0, 226.0)
        poly("#DC2626", 90.0, 156.0, 110.0, 156.0, 106.0, 166.0, 94.0, 166.0)
        circ(100.0, 161.0, 5.0, "#B91C1C")
        circ(100.0, 204.0, 2.5, "#CBD5E1")
        circ(100.0, 214.0, 2.5, "#CBD5E1")
      }
      pop()
    }
    private fun sleeveCol(): String {
      if (CL == 0) { return "" }
      if (CL == 6) { return "#EF4444" }
      if (CL == 5) { return "#7C3AED" }
      return clothMain()
    }

    // ===== Brazos y manos =====
    private fun armCol(): String {
      if (AC == 5) { return "#1B1530" }
      return lo()
    }
    private fun hand(x: Double, y: Double, up: Boolean) {
      if (AC == 5) {
        circg(x, y, 14.0, "#4B5563", "#0F172A")
        if (up) {
          rrg(x - 6.0, y - 26.0, x + 6.0, y - 6.0, 6.0, "#4B5563", "#0F172A")
        } else {
          rrg(x - 4.0, y - 18.0, x + 7.0, y - 4.0, 5.0, "#4B5563", "#0F172A")
        }
        rr(x - 12.0, y + 6.0, x + 12.0, y + 12.0, 3.0, ac())
        line(x - 6.0, y - 2.0, x + 6.0, y - 2.0, 1.5, "#FFFFFF@0.3")
      } else {
        circg(x, y, 14.0, "#FFFFFF", "#C7D2FE")
        if (up) {
          rrg(x - 6.0, y - 28.0, x + 6.0, y - 6.0, 6.0, "#FFFFFF", "#CBD5E1")
          line(x - 11.0, y + 2.0, x + 11.0, y + 2.0, 1.2, "#94A3B8@0.5")
        } else {
          rrg(x - 4.0, y - 18.0, x + 7.0, y - 4.0, 5.0, "#FFFFFF", "#CBD5E1")
        }
        rr(x - 12.0, y + 9.0, x + 12.0, y + 16.0, 4.0, ac())
      }
    }
    private fun limb(x1: Double, y1: Double, x2: Double, y2: Double, w: Double, c: String) {
      line(x1, y1, x2, y2, w, c)
      line(x1 + w * 0.22, y1 + w * 0.22, x2 + w * 0.22, y2 + w * 0.22, w * 0.4, "#000000@0.28")
      line(x1 - w * 0.16, y1 - w * 0.16, x2 - w * 0.16, y2 - w * 0.16, w * 0.3, "#FFFFFF@0.22")
    }
    private fun arms() {
      val wv = sn(T * 3.0) * 4.0
      // brazo izquierdo (mano en la cadera)
      limb(56.0, 152.0, 32.0, 180.0, 13.0, armCol())
      limb(32.0, 180.0, 42.0, 204.0, 13.0, armCol())
      if (CL != 0) { line(56.0, 152.0, 44.0, 166.0, 17.0, sleeveCol()) }
      if (AC == 6) {
        rrg(31.0, 192.0, 53.0, 203.0, 3.5, "#1F2937", "#030712")
        rr(35.0, 194.5, 49.0, 200.5, 2.0, "#22D3EE")
      }
      hand(42.0, 210.0, false)
      // brazo derecho (saludando con el pulgar arriba)
      limb(144.0, 152.0, 170.0, 158.0, 13.0, armCol())
      limb(170.0, 158.0, 176.0, 128.0 + wv, 13.0, armCol())
      if (CL != 0) { line(144.0, 152.0, 158.0, 155.0, 17.0, sleeveCol()) }
      hand(176.0, 118.0 + wv, true)
    }

    // ===== Piernas y calzado =====
    private fun legs() {
      limb(80.0, 218.0, 80.0, 262.0, 15.0, "#17112B")
      limb(120.0, 218.0, 120.0, 262.0, 15.0, "#17112B")
      oval(62.0, 214.0, 138.0, 230.0, "#000000@0.35")
      rr(75.0, 226.0, 78.0, 258.0, 1.5, "#FFFFFF@0.12")
      rr(115.0, 226.0, 118.0, 258.0, 1.5, "#FFFFFF@0.12")
    }
    private fun shoe(x: Double) {
      if (SH == 0) {
        rrg(x - 24.0, 258.0, x + 24.0, 286.0, 12.0, hi(), lo())
        rrg(x - 25.0, 276.0, x + 25.0, 288.0, 6.0, "#FFFFFF", "#CBD5E1")
        rr(x - 18.0, 262.0, x + 16.0, 266.0, 2.0, "#FFFFFF@0.4")
        wLogo(x, 272.0, 0.38, "#FFFFFF")
      } else if (SH == 1) {
        rrg(x - 20.0, 246.0, x + 20.0, 286.0, 8.0, "#4B5320", "#262B0E")
        rrg(x - 25.0, 278.0, x + 25.0, 290.0, 5.0, "#1C1C1C", "#050505")
        line(x - 14.0, 256.0, x + 14.0, 256.0, 2.5, "#000000@0.38")
        line(x - 14.0, 264.0, x + 14.0, 264.0, 2.5, "#000000@0.38")
        line(x - 14.0, 272.0, x + 14.0, 272.0, 2.5, "#000000@0.38")
        circ(x - 14.0, 256.0, 2.2, "#D4D4D8")
        circ(x - 14.0, 264.0, 2.2, "#D4D4D8")
      } else if (SH == 2) {
        rrg(x - 21.0, 244.0, x + 21.0, 286.0, 10.0, "#2A2F4A", "#0B0E1F")
        rr(x - 15.0, 250.0, x - 11.0, 280.0, 2.0, "#22D3EE")
        rrg(x - 26.0, 278.0, x + 26.0, 291.0, 7.0, "#E2E8F0", "#64748B")
        rr(x - 22.0, 284.0, x + 22.0, 288.0, 2.0, "#22D3EE")
      } else {
        glow(x, 286.0, 34.0, "#F0ABFC@0.75")
        rrg(x - 24.0, 258.0, x + 24.0, 286.0, 12.0, "#312E81", "#0B0724")
        rr(x - 18.0, 264.0, x + 16.0, 268.0, 2.0, "#F0ABFC")
        rrg(x - 25.0, 278.0, x + 25.0, 290.0, 6.0, "#FFFFFF", "#F0ABFC")
        rr(x - 20.0, 286.0, x + 20.0, 290.0, 2.0, "#22D3EE")
      }
    }

    // ===== Accesorios =====
    private fun backpack() {
      if (AC == 4) {
        rrg(122.0, 92.0, 166.0, 200.0, 14.0, "#B45309", "#78350F")
        rrg(130.0, 150.0, 162.0, 190.0, 8.0, "#92400E", "#5B2A0A")
        rr(128.0, 120.0, 164.0, 124.0, 2.0, "#000000@0.25")
      } else if (AC == 7) {
        glow(150.0, 150.0, 60.0, "#22D3EE@0.25")
        rrg(122.0, 86.0, 168.0, 204.0, 14.0, "#1E293B", "#020617")
        rr(150.0, 100.0, 154.0, 190.0, 2.0, "#22D3EE")
        rr(138.0, 130.0, 142.0, 190.0, 2.0, "#818CF8")
        line(160.0, 88.0, 168.0, 56.0, 3.5, "#334155")
        circ(168.0, 54.0, 5.0, "#22D3EE")
      }
    }
    private fun frontAcc() {
      if (AC == 4 || AC == 7) {
        line(70.0, 90.0, 70.0, 156.0, 7.0, "#1F2937")
        line(130.0, 90.0, 130.0, 156.0, 7.0, "#1F2937")
        rr(66.0, 150.0, 74.0, 158.0, 2.0, "#CBD5E1")
        rr(126.0, 150.0, 134.0, 158.0, 2.0, "#CBD5E1")
      } else if (AC == 2) {
        arc(100.0, 128.0, 32.0, 28.0, 124.0, 3.0, "#FDE047")
        beads()
        circg(100.0, 174.0, 7.0, "#FEF3C7", "#F59E0B")
        polys(2.5, "#92400E", 96.0, 171.0, 98.5, 178.0, 100.0, 173.0, 101.5, 178.0, 104.0, 171.0)
      } else if (AC == 3) {
        poly("#DC2626", 62.0, 150.0, 138.0, 150.0, 100.0, 192.0)
        poly("#B91C1C", 100.0, 192.0, 138.0, 150.0, 118.0, 150.0)
        circ(86.0, 166.0, 2.2, "#FFFFFF")
        circ(110.0, 164.0, 2.2, "#FFFFFF")
        circ(100.0, 178.0, 2.2, "#FFFFFF")
        circg(100.0, 152.0, 8.0, "#EF4444", "#991B1B")
      } else if (AC == 9) {
        rrg(54.0, 146.0, 146.0, 168.0, 10.0, "#EF4444", "#991B1B")
        line(70.0, 148.0, 66.0, 166.0, 3.0, "#FFFFFF")
        line(88.0, 148.0, 84.0, 166.0, 3.0, "#FFFFFF")
        line(106.0, 148.0, 102.0, 166.0, 3.0, "#FFFFFF")
        line(124.0, 148.0, 120.0, 166.0, 3.0, "#FFFFFF")
        line(140.0, 148.0, 136.0, 166.0, 3.0, "#FFFFFF")
        rrg(112.0, 160.0, 130.0, 208.0, 6.0, "#EF4444", "#991B1B")
        rr(112.0, 176.0, 130.0, 180.0, 0.0, "#FFFFFF")
        rr(112.0, 192.0, 130.0, 196.0, 0.0, "#FFFFFF")
        rr(112.0, 204.0, 130.0, 210.0, 3.0, "#FFFFFF")
      } else if (AC == 10) {
        glow(100.0, 126.0, 16.0, "#EF4444@0.6")
        circg(100.0, 126.0, 6.5, "#FCA5A5", "#DC2626")
      } else if (AC == 11) {
        line(24.0, 208.0, 24.0, 160.0, 8.0, "#FFFFFF")
        arc(32.0, 160.0, 8.0, 180.0, 180.0, 8.0, "#FFFFFF")
        line(24.0, 202.0, 24.0, 194.0, 8.0, "#DC2626")
        line(24.0, 186.0, 24.0, 178.0, 8.0, "#DC2626")
        line(24.0, 170.0, 24.0, 164.0, 8.0, "#DC2626")
        arc(32.0, 160.0, 8.0, 195.0, 40.0, 8.0, "#DC2626")
      } else if (AC == 8) {
        poly("#FACC15", 64.0, 164.0, 94.0, 164.0, 94.0, 188.0, 79.0, 202.0, 64.0, 188.0)
        poly("#7C2D12", 68.0, 168.0, 90.0, 168.0, 90.0, 186.0, 79.0, 197.0, 68.0, 186.0)
        star(79.0, 180.0, 7.0, "#FDE047")
      }
    }
    private fun beads() {
      circ(77.0, 148.0, 2.8, "#FDE047")
      circ(86.0, 156.0, 2.8, "#FDE047")
      circ(100.0, 160.0, 2.8, "#FDE047")
      circ(114.0, 156.0, 2.8, "#FDE047")
      circ(123.0, 148.0, 2.8, "#FDE047")
    }
    private fun antlers() {
      if (AC != 10) { return }
      polys(6.0, "#92400E", 76.0, 76.0, 68.0, 48.0, 58.0, 22.0)
      polys(5.0, "#92400E", 68.0, 48.0, 50.0, 40.0)
      polys(5.0, "#92400E", 64.0, 36.0, 76.0, 26.0)
      polys(6.0, "#92400E", 124.0, 76.0, 132.0, 48.0, 142.0, 22.0)
      polys(5.0, "#92400E", 132.0, 48.0, 150.0, 40.0)
      polys(5.0, "#92400E", 136.0, 36.0, 124.0, 26.0)
      polys(2.0, "#FCD34D@0.5", 76.0, 76.0, 68.0, 48.0, 58.0, 22.0)
    }
    private fun headphones() {
      if (AC != 1) { return }
      push()
      scl(1.0, 0.55, 100.0, 94.0)
      arc(100.0, 94.0, 53.0, 190.0, 160.0, 11.0, "#241B45")
      arc(100.0, 94.0, 53.0, 190.0, 160.0, 3.0, ac())
      pop()
      rrg(38.0, 86.0, 56.0, 126.0, 9.0, "#4338CA", "#1E1B4B")
      rrg(144.0, 86.0, 162.0, 126.0, 9.0, "#4338CA", "#1E1B4B")
      circ(47.0, 106.0, 5.0, "#1E1B4B")
      circ(153.0, 106.0, 5.0, "#1E1B4B")
      wLogo(47.0, 106.0, 0.22, ac())
      wLogo(153.0, 106.0, 0.22, ac())
    }

    // ===== Plataforma =====
    private fun stage() {
      glow(100.0, 190.0, 150.0, ac() + "@0.22")
      oval(24.0, 280.0, 176.0, 316.0, "#000000@0.35")
      oval(50.0, 292.0, 150.0, 306.0, "#000000@0.25")
      ovalg(30.0, 282.0, 170.0, 312.0, "#2A2058", "#0B0724")
      ovals(34.0, 284.0, 166.0, 308.0, 2.5, ac())
      ovals(52.0, 288.0, 148.0, 304.0, 1.5, ac() + "@0.6")
    }

    // ===== Entrada =====
    /** Coloca una capa a la profundidad z: giro real sobre el eje vertical (paralaje + estrechamiento). */
    private fun xf(z: Double) {
      mv(100.0 + YS * z, 0.0)
      scl(CS, 1.0, 0.0, 0.0)
      mv(-100.0, 0.0)
    }
    private fun slice(z: Double) {
      push()
      xf(z)
      rr(54.0, 74.0, 146.0, 222.0, 26.0, lo())
      rr(54.0, 74.0, 146.0, 222.0, 26.0, "#000000@0.3")
      pop()
    }
    private fun drawAvatar() {
      if (FULL) { stage() }
      push()
      xf(-24.0)
      if (!BACK) { backpack() }
      pop()
      if (HT == 0 && !BACK) { push(); xf(-8.0); antenna(); pop() }
      push(); xf(0.0); legs(); pop()
      push(); xf(6.0); shoe(80.0); shoe(120.0); pop()
      if (BACK) {
        slice(10.0)
        slice(6.0)
        slice(2.0)
        slice(-2.0)
        slice(-6.0)
        slice(-10.0)
        push(); xf(-14.0); bodyShape(); sideParts(); pop()
        push(); xf(-15.0); backPlate(); pop()
        push(); xf(-24.0); backpack(); pop()
      } else {
        slice(-14.0)
        slice(-10.0)
        slice(-6.0)
        slice(-2.0)
        slice(2.0)
        slice(6.0)
        push(); xf(10.0); bodyShape(); sideParts(); pop()
        push(); xf(12.0); facePanel(); face(); pop()
        push(); xf(12.0); wPanel(); pop()
        push(); xf(13.0); cloth(); pop()
        push(); xf(14.0); frontAcc(); pop()
      }
      push(); xf(6.0); antlers(); pop()
      push(); xf(8.0); hat(); pop()
      if (HT != 0 || BACK) { push(); xf(-4.0); antenna(); pop() }
      push(); xf(2.0); headphones(); pop()
      push(); xf(8.0); arms(); pop()
    }

}
