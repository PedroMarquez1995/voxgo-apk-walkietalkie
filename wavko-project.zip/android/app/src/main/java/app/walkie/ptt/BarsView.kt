package app.walkie.ptt

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/** Barras de ecualizador animadas: indican que alguien está hablando. */
class BarsView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#E9D5FF")
    }
    private val rect = RectF()
    private val bars = 4
    private var phase = 0f
    private var animator: ValueAnimator? = null

    fun setColor(c: Int) {
        paint.color = c
        invalidate()
    }

    fun start() {
        if (animator?.isRunning == true) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun stop() {
        animator?.cancel()
        animator = null
        phase = 0f
        invalidate()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val barW = w / (bars * 2 - 1)
        for (i in 0 until bars) {
            val t = phase.toDouble() * 2.0 * PI + i * 1.3
            val frac = 0.35f + 0.65f * (0.5f + 0.5f * sin(t).toFloat())
            val bh = h * frac
            val left = i * barW * 2f
            rect.set(left, (h - bh) / 2f, left + barW, (h + bh) / 2f)
            canvas.drawRoundRect(rect, barW / 2f, barW / 2f, paint)
        }
    }
}
