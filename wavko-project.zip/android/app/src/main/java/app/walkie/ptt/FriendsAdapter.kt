package app.walkie.ptt

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

/** Lista de amigos (y bloqueados cuando coinciden con la búsqueda) con su estado. */
class FriendsAdapter(
    private val onOpen: (Store.Friend) -> Unit,
    private val onRemove: (Store.Friend) -> Unit,
    private val onBlock: (Store.Friend, Boolean) -> Unit,   // (persona, estaba bloqueada)
    private val onInvite: (Store.Friend) -> Unit
) : RecyclerView.Adapter<FriendsAdapter.VH>() {

    class Row(val f: Store.Friend, val blocked: Boolean)

    private var rows: List<Row> = emptyList()
    private var status: Map<String, PresenceClient.FriendStatus> = emptyMap()
    private var canInvite = false
    private val gray = Color.parseColor("#6B6280")

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val avatar: WalkieView = v.findViewById(R.id.fAvatar)
        val dot: View = v.findViewById(R.id.fDot)
        val name: TextView = v.findViewById(R.id.fName)
        val sub: TextView = v.findViewById(R.id.fSub)
        val badge: TextView = v.findViewById(R.id.fBadge)
        val remove: ImageView = v.findViewById(R.id.fRemove)
        val block: ImageView = v.findViewById(R.id.fBlock)
        val invite: TextView = v.findViewById(R.id.fInvite)
    }

    fun submit(rows: List<Row>, status: Map<String, PresenceClient.FriendStatus>, canInvite: Boolean) {
        this.rows = rows
        this.status = status
        this.canInvite = canInvite
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_friend, parent, false))

    override fun getItemCount() = rows.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val ctx = h.itemView.context
        val green = ContextCompat.getColor(ctx, R.color.green)
        val lavender = ContextCompat.getColor(ctx, R.color.lavender)
        val muted = ContextCompat.getColor(ctx, R.color.muted)
        val row = rows[position]
        val f = row.f
        val st = status[f.code]
        val online = !row.blocked && st?.online == true

        h.name.text = f.name.ifBlank { ctx.getString(R.string.friend_default, Store.prettyCode(f.code)) }
        h.avatar.setSkin(if (online && st != null) st.skin else f.skin)
        h.dot.backgroundTintList = ColorStateList.valueOf(if (online) green else gray)
        h.avatar.alpha = if (online) 1f else 0.55f

        when {
            row.blocked -> {
                h.sub.text = ctx.getString(R.string.blocked_tag)
                h.sub.setTextColor(ContextCompat.getColor(ctx, R.color.danger))
            }
            online && st?.inChannel == true -> {
                h.sub.text = ctx.getString(R.string.in_channel)
                h.sub.setTextColor(lavender)
            }
            online -> {
                h.sub.text = ctx.getString(R.string.online)
                h.sub.setTextColor(green)
            }
            else -> {
                h.sub.text = ctx.getString(R.string.offline)
                h.sub.setTextColor(muted)
            }
        }

        val unread = if (row.blocked) 0 else Chats.unread(ctx, f.code)
        h.badge.visibility = if (unread > 0) View.VISIBLE else View.GONE
        h.badge.text = if (unread > 99) "99+" else unread.toString()

        h.invite.visibility = if (canInvite && online) View.VISIBLE else View.GONE
        h.invite.setOnClickListener { onInvite(f) }
        // Bloquear / desbloquear
        h.block.contentDescription = ctx.getString(if (row.blocked) R.string.cd_unblock else R.string.cd_block)
        h.block.imageTintList = ColorStateList.valueOf(if (row.blocked) green else muted)
        h.block.setOnClickListener { onBlock(f, row.blocked) }
        // Eliminar (solo amigos; un bloqueado se quita de la lista desbloqueándolo)
        h.remove.visibility = if (row.blocked) View.GONE else View.VISIBLE
        h.remove.setOnClickListener { onRemove(f) }
        h.itemView.setOnClickListener { if (!row.blocked) onOpen(f) }
    }
}
