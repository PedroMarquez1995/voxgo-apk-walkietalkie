package app.walkie.ptt

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Lista de amigos con su estado: en línea, en un canal o desconectado. */
class FriendsAdapter(private val onRemove: (Store.Friend) -> Unit) :
    RecyclerView.Adapter<FriendsAdapter.VH>() {

    private var friends: List<Store.Friend> = emptyList()
    private var status: Map<String, PresenceClient.FriendStatus> = emptyMap()

    private val green = Color.parseColor("#22C55E")
    private val gray = Color.parseColor("#6B6280")
    private val lavender = Color.parseColor("#E9D5FF")
    private val muted = Color.parseColor("#A394C7")

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val avatar: WalkieView = v.findViewById(R.id.fAvatar)
        val dot: View = v.findViewById(R.id.fDot)
        val name: TextView = v.findViewById(R.id.fName)
        val sub: TextView = v.findViewById(R.id.fSub)
        val remove: ImageView = v.findViewById(R.id.fRemove)
    }

    fun submit(friends: List<Store.Friend>, status: Map<String, PresenceClient.FriendStatus>) {
        this.friends = friends
        this.status = status
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_friend, parent, false))

    override fun getItemCount() = friends.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val f = friends[position]
        val st = status[f.code]
        val online = st?.online == true

        h.name.text = f.name.ifBlank { "Amigo ${Store.prettyCode(f.code)}" }
        h.avatar.setSkin(if (online && st != null) st.skin else f.skin)
        h.dot.backgroundTintList = ColorStateList.valueOf(if (online) green else gray)
        h.avatar.alpha = if (online) 1f else 0.55f

        when {
            online && st?.inChannel == true -> {
                h.sub.text = "En un canal"
                h.sub.setTextColor(lavender)
            }
            online -> {
                h.sub.text = "En línea"
                h.sub.setTextColor(green)
            }
            else -> {
                h.sub.text = "Desconectado"
                h.sub.setTextColor(muted)
            }
        }
        h.remove.setOnClickListener { onRemove(f) }
    }
}
