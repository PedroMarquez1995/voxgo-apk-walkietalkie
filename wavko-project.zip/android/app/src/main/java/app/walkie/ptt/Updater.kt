package app.walkie.ptt

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.content.FileProvider
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/** Busca nuevas versiones en los Releases de GitHub (repositorio público) y las instala. */
object Updater {
    class Info(val code: Int, val name: String, val apkUrl: String)

    private val http by lazy {
        OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()
    }
    private val main = Handler(Looper.getMainLooper())

    fun available() = BuildConfig.UPDATE_REPO.contains("/")

    /** cb(info?, error): info null y error null = ya tienes la última versión. */
    fun check(cb: (Info?, String?) -> Unit) {
        Thread {
            var info: Info? = null
            var err: String? = null
            try {
                val req = Request.Builder()
                    .url("https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/releases/latest")
                    .header("Accept", "application/vnd.github+json").build()
                http.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) {
                        err = "http ${r.code}"
                    } else {
                        val j = JSONObject(r.body?.string() ?: "{}")
                        val code = j.optString("tag_name").removePrefix("v").toIntOrNull() ?: 0
                        val assets = j.optJSONArray("assets")
                        var url = ""
                        if (assets != null) for (i in 0 until assets.length()) {
                            val a = assets.getJSONObject(i)
                            if (a.optString("name").endsWith(".apk")) url = a.optString("browser_download_url")
                        }
                        if (code > BuildConfig.VERSION_CODE && url.isNotEmpty()) {
                            info = Info(code, j.optString("name").ifBlank { "v$code" }, url)
                        }
                    }
                }
            } catch (e: Exception) {
                err = e.message ?: "error"
            }
            main.post { cb(info, err) }
        }.start()
    }

    /** Descarga el APK y abre el instalador de Android. cb(error?) */
    fun install(ctx: Context, info: Info, cb: (String?) -> Unit) {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            cb("permission")
            return
        }
        Thread {
            var err: String? = null
            try {
                val dir = File(ctx.cacheDir, "updates").apply { mkdirs() }
                val f = File(dir, "wavko.apk")
                http.newCall(Request.Builder().url(info.apkUrl).build()).execute().use { r ->
                    if (!r.isSuccessful) throw java.io.IOException("http ${r.code}")
                    r.body!!.byteStream().use { input -> f.outputStream().use { input.copyTo(it) } }
                }
                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".updates", f)
                main.post {
                    ctx.startActivity(
                        Intent(Intent.ACTION_VIEW)
                            .setDataAndType(uri, "application/vnd.android.package-archive")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            } catch (e: Exception) {
                err = e.message ?: "error"
            }
            main.post { cb(err) }
        }.start()
    }
}
