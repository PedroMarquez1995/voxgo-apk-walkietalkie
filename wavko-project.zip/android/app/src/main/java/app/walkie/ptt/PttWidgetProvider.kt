package app.walkie.ptt

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/**
 * Widget "Toca para hablar". Un widget solo detecta toques (no "mantener pulsado"),
 * así que funciona como interruptor: un toque empieza a transmitir y otro toque termina.
 */
class PttWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        manager.updateAppWidget(ids, build(context))
    }

    companion object {
        const val ACTION_TOGGLE = "app.wavko.action.TOGGLE_TALK"

        /** Redibuja todos los widgets según el estado actual del servicio. */
        fun refresh(context: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(ComponentName(context, PttWidgetProvider::class.java))
                if (ids.isNotEmpty()) mgr.updateAppWidget(ids, build(context))
            } catch (e: Exception) {
                // el widget no es crítico
            }
        }

        fun togglePendingIntent(context: Context, requestCode: Int): PendingIntent =
            PendingIntent.getBroadcast(
                context,
                requestCode,
                Intent(context, PttActionReceiver::class.java).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        private fun build(context: Context): RemoteViews {
            val svc = PttService.instance
            val connected = svc?.state == PttService.CONNECTED
            val tx = svc?.transmitting == true

            val rv = RemoteViews(context.packageName, R.layout.widget_ptt)
            val bg = when {
                tx -> R.drawable.widget_bg_tx
                connected -> R.drawable.widget_bg_idle
                else -> R.drawable.widget_bg_off
            }
            rv.setInt(R.id.widgetRoot, "setBackgroundResource", bg)
            rv.setTextViewText(
                R.id.widgetLabel,
                when {
                    tx -> context.getString(R.string.widget_tx)
                    connected -> "Toca para hablar"
                    else -> context.getString(R.string.widget_open)
                }
            )

            val click = if (connected) {
                togglePendingIntent(context, 1)
            } else {
                PendingIntent.getActivity(
                    context,
                    2,
                    Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            }
            rv.setOnClickPendingIntent(R.id.widgetRoot, click)
            return rv
        }
    }
}
