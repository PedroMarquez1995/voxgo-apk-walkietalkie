package app.walkie.ptt

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/** Recibe los push del servidor: invitaciones a un canal y mensajes de voz. */
class WavkoMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        Push.send(applicationContext, token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val d = message.data
        when (d["type"]) {
            "voice" -> Push.notifyVoice(applicationContext, d["name"].orEmpty())
            "invite" -> {
                val id = d["id"].orEmpty()
                if (id.isNotEmpty()) {
                    Push.notifyInviteId(applicationContext, d["name"].orEmpty(), id, d["channel"].orEmpty())
                }
            }
        }
    }
}
