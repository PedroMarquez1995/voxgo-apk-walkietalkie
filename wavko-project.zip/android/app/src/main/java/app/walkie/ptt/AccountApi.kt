package app.walkie.ptt

import android.content.Context
import android.os.Handler
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException

/**
 * Llamadas HTTP a las cuentas del servidor (registro, amigos, bloqueos…).
 * El resultado llega siempre en el hilo principal. status 0 = no hubo conexión.
 */
class AccountApi(private val http: OkHttpClient, private val main: Handler) {

    data class Result(val status: Int, val json: JSONObject?) {
        val ok: Boolean get() = status in 200..299
        val error: String get() = json?.optString("error").orEmpty()
    }

    fun call(
        ctx: Context, method: String, path: String, body: JSONObject? = null,
        auth: Boolean = true, cb: (Result) -> Unit
    ) {
        val base = Store.apiBase(ctx)
        if (base.isEmpty()) {
            main.post { cb(Result(0, null)) }
            return
        }
        val request = try {
            val b = Request.Builder().url(base + path)
            val srvKey = Store.prefs(ctx).getString("key", "") ?: ""
            if (srvKey.isNotEmpty()) b.header("X-Wavko-Key", srvKey)
            if (auth) b.header("Authorization", "Bearer ${Store.friendCode(ctx)}.${Store.token(ctx)}")
            if (method == "GET") {
                b.get()
            } else {
                b.method(method, (body ?: JSONObject()).toString().toRequestBody("application/json".toMediaType()))
            }
            b.build()
        } catch (e: IllegalArgumentException) {
            main.post { cb(Result(0, null)) }
            return
        }
        http.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                main.post { cb(Result(0, null)) }
            }

            override fun onResponse(call: Call, response: Response) {
                val text = try {
                    response.use { it.body?.string() ?: "" }
                } catch (e: IOException) {
                    ""
                }
                val j = try {
                    JSONObject(text)
                } catch (e: Exception) {
                    null
                }
                val status = response.code
                main.post { cb(Result(status, j)) }
            }
        })
    }

    /** Descarga o sube bytes en bruto (mensajes de voz). cb(status, datos); status 0 = sin conexión. */
    fun bytes(
        ctx: Context, method: String, path: String, body: ByteArray? = null,
        cb: (Int, ByteArray?) -> Unit
    ) {
        val base = Store.apiBase(ctx)
        if (base.isEmpty()) {
            main.post { cb(0, null) }
            return
        }
        val request = try {
            val b = Request.Builder().url(base + path)
            val srvKey = Store.prefs(ctx).getString("key", "") ?: ""
            if (srvKey.isNotEmpty()) b.header("X-Wavko-Key", srvKey)
            b.header("Authorization", "Bearer ${Store.friendCode(ctx)}.${Store.token(ctx)}")
            when {
                method == "GET" -> b.get()
                body != null -> b.method(method, body.toRequestBody("application/octet-stream".toMediaType()))
                else -> b.method(method, ByteArray(0).toRequestBody(null))
            }
            b.build()
        } catch (e: IllegalArgumentException) {
            main.post { cb(0, null) }
            return
        }
        http.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                main.post { cb(0, null) }
            }

            override fun onResponse(call: Call, response: Response) {
                val data = try {
                    response.use { it.body?.bytes() }
                } catch (e: IOException) {
                    null
                }
                val status = response.code
                main.post { cb(status, data) }
            }
        })
    }
}
