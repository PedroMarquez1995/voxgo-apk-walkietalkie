package app.walkie.ptt

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Cifrado del audio de los canales con clave.
 *
 * De la clave que escribe la persona se derivan DOS valores distintos (PBKDF2):
 *  - la "prueba" que se manda al servidor para comprobar que la clave es correcta, y
 *  - la clave AES-256 con la que se cifra el audio, que nunca sale del teléfono.
 * Así el servidor puede verificar la entrada pero no puede escuchar el canal.
 *
 * Paquete cifrado: 0x45 | nonce (12 bytes) | AES-GCM(audio) con etiqueta de 16 bytes.
 */
object ChannelCrypto {
    const val TAG: Byte = 0x45
    private const val ITERATIONS = 20_000
    private const val NONCE = 12
    private const val TAG_BITS = 128
    private val rnd = SecureRandom()

    private fun pbkdf2(pass: String, salt: String): ByteArray {
        val spec = PBEKeySpec(pass.toCharArray(), salt.toByteArray(Charsets.UTF_8), ITERATIONS, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    /** Lo que se envía al servidor en lugar de la clave. `channel` ya debe estar normalizado. */
    fun proof(pass: String, channel: String): String =
        Base64.encodeToString(pbkdf2(pass, "wavko-auth:$channel"), Base64.NO_WRAP)

    fun key(pass: String, channel: String): SecretKey =
        SecretKeySpec(pbkdf2(pass, "wavko-enc:$channel"), "AES")

    fun seal(key: SecretKey, plain: ByteArray): ByteArray? = try {
        val nonce = ByteArray(NONCE).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(TAG_BITS, nonce))
        val ct = c.doFinal(plain)
        val out = ByteArray(1 + NONCE + ct.size)
        out[0] = TAG
        System.arraycopy(nonce, 0, out, 1, NONCE)
        System.arraycopy(ct, 0, out, 1 + NONCE, ct.size)
        out
    } catch (e: Exception) {
        null
    }

    /** Devuelve el audio original o null si el paquete no es válido o no se pudo autenticar. */
    fun open(key: SecretKey, data: ByteArray): ByteArray? {
        if (data.size < 1 + NONCE + TAG_BITS / 8 || data[0] != TAG) return null
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_BITS, data.copyOfRange(1, 1 + NONCE)))
            c.doFinal(data, 1 + NONCE, data.size - 1 - NONCE)
        } catch (e: Exception) {
            null
        }
    }
}
