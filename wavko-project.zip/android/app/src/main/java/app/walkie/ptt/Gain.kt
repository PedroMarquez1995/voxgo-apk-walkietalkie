package app.walkie.ptt

import android.media.AudioTrack
import android.media.audiofx.LoudnessEnhancer
import kotlin.math.tanh

/** Sube el volumen de la voz (el micrófono de comunicación y el altavoz suelen sonar bajo) sin que sature. */
object Gain {
    const val CAPTURE = 2.5f
    const val PLAYBACK = 2.2f

    /** Amplifica con limitador suave: lo suave sube casi lineal y los picos se comprimen en vez de distorsionar. */
    fun boost(pcm: ShortArray, n: Int, g: Float) {
        for (i in 0 until n) {
            pcm[i] = (32767f * tanh(g * pcm[i] / 32768f)).toInt().toShort()
        }
    }

    /** Refuerzo extra del sistema (+6 dB); si el teléfono no lo permite se ignora. */
    fun enhance(track: AudioTrack): LoudnessEnhancer? = try {
        LoudnessEnhancer(track.audioSessionId).apply {
            setTargetGain(600)
            enabled = true
        }
    } catch (e: Exception) {
        null
    }
}
