package app.walkie.ptt

import android.media.MediaCodec
import android.media.MediaFormat
import android.os.Build
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Opus mediante el códec del sistema (MediaCodec). Es "audio HD" opcional:
 * si el teléfono no trae codificador Opus (Android < 10) se usa µ-law como siempre.
 *
 * Formato de paquete en la red:
 *  - µ-law (compatible con versiones anteriores): 640 bytes sin cabecera.
 *  - Opus: un byte 0x4F ('O') seguido del paquete Opus (20 ms, 16 kHz, mono).
 */
object OpusCodec {
    const val TAG: Byte = 0x4F
    const val RATE = 16000
    const val FRAME = 320 // 20 ms a 16 kHz

    fun encoderAvailable(): Boolean = Build.VERSION.SDK_INT >= 29

    class Encoder {
        private var codec: MediaCodec? = null
        private var pts = 0L
        private val info = MediaCodec.BufferInfo()

        val ok: Boolean get() = codec != null

        init {
            if (encoderAvailable()) {
                try {
                    val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_OPUS, RATE, 1)
                    fmt.setInteger(MediaFormat.KEY_BIT_RATE, 24000)
                    val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_OPUS)
                    c.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    c.start()
                    codec = c
                } catch (e: Exception) {
                    codec = null
                }
            }
        }

        /** Codifica 320 muestras a partir de `off` y entrega cada paquete (ya con la marca 'O'). */
        fun encode(pcm: ShortArray, off: Int, out: (ByteArray) -> Unit) {
            val c = codec ?: return
            try {
                val ii = c.dequeueInputBuffer(5000)
                if (ii >= 0) {
                    val buf = c.getInputBuffer(ii) ?: return
                    buf.clear()
                    buf.order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until FRAME) buf.putShort(pcm[off + i])
                    c.queueInputBuffer(ii, 0, FRAME * 2, pts, 0)
                    pts += 20000
                }
                while (true) {
                    val oi = c.dequeueOutputBuffer(info, 0)
                    if (oi >= 0) {
                        val ob = c.getOutputBuffer(oi)
                        if (ob != null && info.size > 0 &&
                            (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                        ) {
                            val pkt = ByteArray(info.size + 1)
                            pkt[0] = TAG
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            ob.get(pkt, 1, info.size)
                            out(pkt)
                        }
                        c.releaseOutputBuffer(oi, false)
                    } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED ||
                        oi == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED
                    ) {
                        continue
                    } else {
                        break
                    }
                }
            } catch (e: Exception) {
                release()
            }
        }

        fun release() {
            val c = codec ?: return
            codec = null
            try {
                c.stop()
            } catch (e: Exception) {
            }
            try {
                c.release()
            } catch (e: Exception) {
            }
        }
    }

    class Decoder {
        private var codec: MediaCodec? = null
        private var pts = 0L
        private var outRate = 48000
        private val info = MediaCodec.BufferInfo()

        val ok: Boolean get() = codec != null

        init {
            try {
                val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_OPUS, RATE, 1)
                fmt.setByteBuffer("csd-0", opusHead())
                fmt.setByteBuffer("csd-1", nanos(0L))
                fmt.setByteBuffer("csd-2", nanos(80_000_000L))
                val c = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_AUDIO_OPUS)
                c.configure(fmt, null, null, 0)
                c.start()
                codec = c
            } catch (e: Exception) {
                codec = null
            }
        }

        private fun opusHead(): ByteBuffer {
            val b = ByteBuffer.allocate(19).order(ByteOrder.LITTLE_ENDIAN)
            b.put("OpusHead".toByteArray(Charsets.US_ASCII))
            b.put(1) // versión
            b.put(1) // canales
            b.putShort(0) // pre-skip
            b.putInt(RATE) // frecuencia original
            b.putShort(0) // ganancia
            b.put(0) // mapeo de canales
            b.flip()
            return b
        }

        private fun nanos(v: Long): ByteBuffer {
            val b = ByteBuffer.allocate(8).order(ByteOrder.nativeOrder())
            b.putLong(v)
            b.flip()
            return b
        }

        /** Decodifica un paquete (sin la marca) y devuelve PCM a 16 kHz; puede ser vacío. */
        fun decode(data: ByteArray, offset: Int, length: Int): ShortArray {
            val c = codec ?: return ShortArray(0)
            val result = ArrayList<ShortArray>()
            try {
                val ii = c.dequeueInputBuffer(5000)
                if (ii >= 0) {
                    val buf = c.getInputBuffer(ii) ?: return ShortArray(0)
                    buf.clear()
                    buf.put(data, offset, length)
                    c.queueInputBuffer(ii, 0, length, pts, 0)
                    pts += 20000
                }
                while (true) {
                    val oi = c.dequeueOutputBuffer(info, 0)
                    if (oi >= 0) {
                        val ob = c.getOutputBuffer(oi)
                        if (ob != null && info.size > 0) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                            val raw = ShortArray(sb.remaining())
                            sb.get(raw)
                            result.add(toRate(raw))
                        }
                        c.releaseOutputBuffer(oi, false)
                    } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        try {
                            val f = c.outputFormat
                            if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                                outRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            }
                        } catch (e: Exception) {
                        }
                    } else if (oi == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED) {
                        continue
                    } else {
                        break
                    }
                }
            } catch (e: Exception) {
                release()
                return ShortArray(0)
            }
            val total = result.sumOf { it.size }
            val out = ShortArray(total)
            var p = 0
            for (r in result) {
                System.arraycopy(r, 0, out, p, r.size)
                p += r.size
            }
            return out
        }

        /** El decodificador suele entregar 48 kHz; lo pasamos a 16 kHz promediando. */
        private fun toRate(src: ShortArray): ShortArray {
            if (outRate == RATE || outRate <= 0) return src
            val ratio = outRate / RATE
            if (ratio < 2 || outRate % RATE != 0) {
                // razón no entera: remuestreo simple por vecino más cercano
                val n = (src.size.toLong() * RATE / outRate).toInt()
                return ShortArray(n) { src[minOf(src.size - 1, (it.toLong() * outRate / RATE).toInt())] }
            }
            val n = src.size / ratio
            return ShortArray(n) { i ->
                var sum = 0
                for (k in 0 until ratio) sum += src[i * ratio + k]
                (sum / ratio).toShort()
            }
        }

        fun release() {
            val c = codec ?: return
            codec = null
            try {
                c.stop()
            } catch (e: Exception) {
            }
            try {
                c.release()
            } catch (e: Exception) {
            }
        }
    }
}
