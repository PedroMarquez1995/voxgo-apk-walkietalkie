package app.walkie.ptt

import android.graphics.Color
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Mensaje para mostrar en una burbuja (conversación con un amigo o chat del canal). */
class Bubble(
    val id: String, val mine: Boolean, val sender: String, val kind: String,
    val text: String, val dur: Long, val ts: Long
)

/** Burbujas estilo WhatsApp: tuyos a la derecha, de los demás a la izquierda (con el nombre de quien escribe). */
class ChatAdapter(
    private val showSender: Boolean,
    private val onPlay: (Bubble) -> Unit = {}
) : RecyclerView.Adapter<ChatAdapter.VH>() {

    private var items: List<Bubble> = emptyList()
    var playingId: String? = null
        set(v) {
            field = v
            notifyDataSetChanged()
        }

    private val time = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val palette = intArrayOf(
        "#DB2777", "#16A34A", "#D97706", "#0891B2", "#EA580C", "#2563EB", "#BE185D", "#65A30D"
    ).map { Color.parseColor(it) }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val root: LinearLayout = v.findViewById(R.id.bRoot)
        val bubble: LinearLayout = v.findViewById(R.id.bBubble)
        val name: TextView = v.findViewById(R.id.bName)
        val text: TextView = v.findViewById(R.id.bText)
        val voice: View = v.findViewById(R.id.bVoice)
        val play: TextView = v.findViewById(R.id.bPlay)
        val dur: TextView = v.findViewById(R.id.bDur)
        val time: TextView = v.findViewById(R.id.bTime)
    }

    fun submit(list: List<Bubble>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_bubble, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val b = items[position]
        val ctx = h.itemView.context
        val d = ctx.resources.displayMetrics.density
        val fg = if (b.mine) Color.WHITE else ContextCompat.getColor(ctx, R.color.text)
        h.root.gravity = if (b.mine) Gravity.END else Gravity.START
        h.root.setPadding(
            if (b.mine) (56 * d).toInt() else 0, h.root.paddingTop,
            if (b.mine) 0 else (56 * d).toInt(), h.root.paddingBottom
        )
        h.bubble.setBackgroundResource(if (b.mine) R.drawable.bg_bubble_out else R.drawable.bg_bubble_in)

        val sender = showSender && !b.mine
        h.name.visibility = if (sender) View.VISIBLE else View.GONE
        if (sender) {
            h.name.text = b.sender
            h.name.setTextColor(palette[(b.sender.hashCode() and 0x7fffffff) % palette.size])
        }
        if (b.kind == "voice") {
            h.text.visibility = View.GONE
            h.voice.visibility = View.VISIBLE
            h.play.text = if (playingId == b.id) "■" else "▶"
            h.dur.text = ctx.getString(R.string.voice_secs, ((b.dur + 500) / 1000).toInt())
            h.dur.setTextColor(fg)
            h.play.setOnClickListener { onPlay(b) }
        } else {
            h.voice.visibility = View.GONE
            h.text.visibility = View.VISIBLE
            h.text.text = b.text
            h.text.setTextColor(fg)
        }
        h.time.text = time.format(Date(b.ts))
        h.time.setTextColor(fg)
    }
}
