package app.walkie.ptt

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

/** Avatar: un walkie-talkie dibujado con código, con los colores de la skin elegida. */
class WalkieView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var skin: Skin = Skins.get(0)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    fun setSkin(id: Int) {
        skin = Skins.get(id)
        invalidate()
    }

    private fun rr(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float) {
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, rad, rad, paint)
    }

    private fun alpha(color: Int, a: Int) =
        Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // Dibujamos en una caja de 100 x 140 y la escalamos al tamaño de la vista
        val scale = min(w / 100f, h / 140f)
        canvas.save()
        canvas.translate((w - 100f * scale) / 2f, (h - 140f * scale) / 2f)
        canvas.scale(scale, scale)

        paint.style = Paint.Style.FILL
        paint.shader = null

        // Antena
        paint.color = skin.detail
        rr(canvas, 66f, 0f, 74f, 34f, 4f)
        paint.color = skin.accent
        rr(canvas, 66f, 0f, 74f, 11f, 4f)

        // Botón lateral
        paint.color = skin.detail
        rr(canvas, 9f, 50f, 19f, 74f, 4f)

        // Cuerpo
        paint.shader = LinearGradient(0f, 26f, 0f, 138f, skin.body, skin.bodyDark, Shader.TileMode.CLAMP)
        rr(canvas, 16f, 26f, 84f, 138f, 16f)
        paint.shader = null

        // Altavoz
        paint.color = alpha(skin.detail, 150)
        for (i in 0 until 4) {
            val y = 40f + i * 8f
            rr(canvas, 28f, y, 72f, y + 4f, 2f)
        }

        // Pantalla con barras de audio
        paint.color = skin.screen
        rr(canvas, 28f, 76f, 72f, 98f, 5f)
        paint.color = skin.accent
        val bars = floatArrayOf(6f, 12f, 8f, 14f, 7f)
        for (i in bars.indices) {
            val x = 34f + i * 7.2f
            rr(canvas, x, 87f - bars[i] / 2f, x + 3f, 87f + bars[i] / 2f, 1.5f)
        }

        // Botón de hablar
        paint.color = alpha(skin.detail, 160)
        canvas.drawCircle(50f, 118f, 13.5f, paint)
        paint.color = skin.accent
        canvas.drawCircle(50f, 118f, 10.5f, paint)

        canvas.restore()
    }
}
