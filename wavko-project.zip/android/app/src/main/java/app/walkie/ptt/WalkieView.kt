package app.walkie.ptt

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.RectF
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.min

/**
 * Muestra el personaje Wavko. Por defecto un busto (cabeza y torso) para listas pequeñas;
 * con [full] el cuerpo entero sobre su plataforma. Con [animated] respira y mueve la antena;
 * con [turnable] se puede girar arrastrando o tocando.
 */
class WalkieView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var avatar = Avatar.DEFAULT
    private val region = RectF(14f, 16f, 186f, 262f)
    private val bust = RectF(14f, 16f, 186f, 262f)
    private val whole = RectF(0f, 0f, AvatarArt.W, AvatarArt.H)
    private var useWhole = false
    private var custom: RectF? = null
    private var yaw = 0f
    private var spinner: ValueAnimator? = null
    private val t0 = SystemClock.uptimeMillis()

    /** Cuerpo entero con plataforma (si no, busto). */
    var full: Boolean = false
        set(v) {
            field = v
            useWhole = v
            invalidate()
        }

    /** Animación suave de espera. */
    var animated: Boolean = false
        set(v) {
            field = v
            invalidate()
        }

    /** Girar arrastrando (y dar una vuelta al tocar). */
    var turnable: Boolean = false

    /** Compatible con el sistema anterior: recibe el número de skin/personaje. */
    fun setSkin(id: Int) = setAvatar(id)

    fun setAvatar(a: Int) {
        avatar = a
        invalidate()
    }

    /** Recorta una zona del espacio de diseño (200 x 350): sirve para las miniaturas del Taller. */
    fun setRegion(l: Float, t: Float, r: Float, b: Float) {
        custom = RectF(l, t, r, b)
        invalidate()
    }

    fun spin() {
        spinner?.cancel()
        spinner = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 1100
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                yaw = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        spinner?.cancel()
        super.onDetachedFromWindow()
    }

    private var downX = 0f
    private var lastX = 0f
    private var moved = false

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!turnable) return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                spinner?.cancel()
                downX = e.x
                lastX = e.x
                moved = false
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(e.x - downX) > 12f) moved = true
                if (moved) {
                    yaw = (yaw + (e.x - lastX) * 0.9f + 360f) % 360f
                    invalidate()
                }
                lastX = e.x
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) {
                    performClick()
                    spin()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = custom ?: if (useWhole) whole else bust
        val s = min(w / r.width(), h / r.height())
        val t = if (animated) (SystemClock.uptimeMillis() - t0) / 1000.0 else 1.3

        canvas.save()
        canvas.translate(w / 2f, h / 2f)
        canvas.scale(s, s)
        canvas.translate(-r.centerX(), -r.centerY())

        // Respiración suave mientras espera
        if (animated) canvas.translate(0f, (Math.sin(t * 2.2) * 2.0).toFloat())

        // El giro es real: AvatarArt coloca cada capa a su profundidad (se ve el grosor y la espalda)
        AvatarArt.render(canvas, avatar, t, Math.toRadians(yaw.toDouble()), full)
        canvas.restore()

        if (animated) postInvalidateOnAnimation()
    }
}
