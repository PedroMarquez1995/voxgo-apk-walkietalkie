package app.walkie.ptt

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min

/**
 * Ondas que se expanden desde el centro (se usan detrás del botón de hablar
 * y detrás del logo en la bienvenida). No dibuja nada mientras no esté iniciada.
 */
class RippleView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val density = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }

    private var color = Color.parseColor("#8B5CF6")
    private var progress = 0f
    private var animator: ValueAnimator? = null

    /** Radio (en dp) desde el que nacen las ondas: el del botón o logo que hay encima. */
    var baseRadiusDp = 75f

    fun setColor(c: Int) {
        color = c
        invalidate()
    }

    fun start() {
        if (animator?.isRunning == true) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2200
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun stop() {
        animator?.cancel()
        animator = null
        progress = 0f
        invalidate()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        if (animator == null) return
        val cx = width / 2f
        val cy = height / 2f
        val base = baseRadiusDp * density
        val maxR = min(width, height) / 2f
        if (maxR <= base) return
        for (i in 0 until 3) {
            val p = (progress + i / 3f) % 1f
            val r = base + (maxR - base) * p
            val a = ((1f - p) * 0.6f * 255f).toInt()
            fill.color = color
            fill.alpha = (a * 0.3f).toInt()
            canvas.drawCircle(cx, cy, r, fill)
            stroke.color = color
            stroke.alpha = a
            canvas.drawCircle(cx, cy, r, stroke)
        }
    }
}
