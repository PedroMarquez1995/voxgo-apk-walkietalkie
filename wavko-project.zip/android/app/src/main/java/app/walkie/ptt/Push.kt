package app.walkie.ptt

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import okhttp3.OkHttpClient
import org.json.JSONObject

/** Notificaciones push (Firebase). Si la app se compiló sin google-services.json, no hace nada. */
object Push {
    const val CH_INVITES = "wavko_invites"
    const val CH_VOICE = "wavko_voice"

    private val http by lazy { OkHttpClient() }

    fun api() = AccountApi(http, Handler(Looper.getMainLooper()))

    /** Pide el token de este teléfono y lo registra en tu cuenta del servidor. */
    fun register(ctx: Context) {
        if (!Store.hasAccount(ctx)) return
        try {
            if (FirebaseApp.getApps(ctx).isEmpty()) return
            FirebaseMessaging.getInstance().token.addOnSuccessListener { t -> send(ctx, t) }
        } catch (e: Exception) {
            // Firebase no está configurado
        }
    }

    fun send(ctx: Context, token: String) {
        if (!Store.hasAccount(ctx) || token.isEmpty()) return
        api().call(ctx.applicationContext, "POST", "/api/push", JSONObject().put("token", token)) { }
    }

    fun notify(
        ctx: Context, id: Int, channelId: String, channelName: String,
        title: String, text: String, open: Intent
    ) {
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_HIGH)
            )
            val pi = PendingIntent.getActivity(
                ctx, id, open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, channelId)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(id, n)
        } catch (e: Exception) {
            // sin permiso de notificaciones
        }
    }

    fun notifyVoice(ctx: Context, fromName: String) {
        val who = fromName.ifBlank { ctx.getString(R.string.a_friend) }
        notify(
            ctx, 21, CH_VOICE, ctx.getString(R.string.notif_voice),
            ctx.getString(R.string.voice_notif_title, who), ctx.getString(R.string.voice_notif_text),
            Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_OPEN_VOICE, true)
        )
    }

    fun notifyInviteId(ctx: Context, fromName: String, inviteId: String, channel: String) {
        val who = fromName.ifBlank { ctx.getString(R.string.a_friend) }
        notify(
            ctx, 22, CH_INVITES, ctx.getString(R.string.notif_invites),
            ctx.getString(R.string.invite_title, who), ctx.getString(R.string.invite_text, channel),
            Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_INVITE_ID, inviteId)
        )
    }
}
