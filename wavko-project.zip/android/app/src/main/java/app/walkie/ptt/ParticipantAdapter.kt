package app.walkie.ptt

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

/** Lista de personas conectadas al canal, con indicador verde y de "hablando". */
class ParticipantAdapter(private val onClick: (String) -> Unit) : RecyclerView.Adapter<ParticipantAdapter.VH>() {

    private var names: List<String> = emptyList()
    private var me = ""
    private var talker: String? = null
    private var meTransmitting = false
    private var skins: Map<String, Int> = emptyMap()
    private var mySkin = 0


    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val row: View = v
        val avatar: WalkieView = v.findViewById(R.id.avatar)
        val name: TextView = v.findViewById(R.id.pName)
        val sub: TextView = v.findViewById(R.id.pSub)
        val bars: BarsView = v.findViewById(R.id.pBars)
    }

    fun submit(
        users: List<String>, me: String, talker: String?, meTransmitting: Boolean,
        skins: Map<String, Int>, mySkin: Int
    ) {
        this.skins = skins
        this.mySkin = mySkin
        this.names = users
        this.me = me
        this.talker = talker
        this.meTransmitting = meTransmitting
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_participant, parent, false)
        return VH(v)
    }

    override fun getItemCount() = names.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val ctx = h.itemView.context
        val lavender = ContextCompat.getColor(ctx, R.color.lavender)
        val muted = ContextCompat.getColor(ctx, R.color.muted)
        val pink = ContextCompat.getColor(ctx, R.color.pink)
        val n = names[position]
        h.row.setOnClickListener { onClick(n) }
        val isMe = n == me
        val talking = if (isMe) meTransmitting else (n == talker)

        h.name.text = if (isMe) ctx.getString(R.string.you_suffix, n) else n
        h.avatar.setSkin(if (isMe) mySkin else (skins[n] ?: 0))
        h.row.setBackgroundResource(if (talking) R.drawable.bg_row_talking else R.drawable.bg_row)

        if (talking) {
            h.sub.text = if (isMe) ctx.getString(R.string.transmitting_dots) else ctx.getString(R.string.talking_dots)
            h.sub.setTextColor(if (isMe) pink else lavender)
            h.bars.setColor(if (isMe) pink else lavender)
            h.bars.visibility = View.VISIBLE
            h.bars.start()
        } else {
            h.sub.text = ctx.getString(R.string.connected)
            h.sub.setTextColor(muted)
            h.bars.stop()
            h.bars.visibility = View.GONE
        }
    }
}
