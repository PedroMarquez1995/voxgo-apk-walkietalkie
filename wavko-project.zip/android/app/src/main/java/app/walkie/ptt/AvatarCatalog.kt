package app.walkie.ptt

/** Catálogo del Taller (generado): nombres, niveles de desbloqueo y personajes de la colección. */
object AvatarCatalog {
    /** Nivel de desbloqueo: 0 gratis, 1 logro, 2 premium, 3 edición limitada. */
    val NAMES_SKIN = intArrayOf(R.string.av_skin_0, R.string.av_skin_1, R.string.av_skin_2, R.string.av_skin_3, R.string.av_skin_4, R.string.av_skin_5, R.string.av_skin_6, R.string.av_skin_7, R.string.av_skin_8, R.string.av_skin_9)
    val TIERS_SKIN = intArrayOf(0, 0, 0, 0, 0, 0, 1, 2, 1, 2)
    val NAMES_HAT = intArrayOf(R.string.av_hat_0, R.string.av_hat_1, R.string.av_hat_2, R.string.av_hat_3, R.string.av_hat_4, R.string.av_hat_5, R.string.av_hat_6)
    val TIERS_HAT = intArrayOf(0, 0, 0, 1, 2, 2, 3)
    val NAMES_ANT = intArrayOf(R.string.av_ant_0, R.string.av_ant_1, R.string.av_ant_2, R.string.av_ant_3, R.string.av_ant_4, R.string.av_ant_5, R.string.av_ant_6, R.string.av_ant_7)
    val TIERS_ANT = intArrayOf(0, 0, 0, 0, 1, 2, 1, 3)
    val NAMES_FACE = intArrayOf(R.string.av_face_0, R.string.av_face_1, R.string.av_face_2, R.string.av_face_3, R.string.av_face_4, R.string.av_face_5, R.string.av_face_6, R.string.av_face_7, R.string.av_face_8, R.string.av_face_9)
    val TIERS_FACE = intArrayOf(0, 0, 0, 0, 0, 0, 1, 0, 2, 2)
    val NAMES_CLOTH = intArrayOf(R.string.av_cloth_0, R.string.av_cloth_1, R.string.av_cloth_2, R.string.av_cloth_3, R.string.av_cloth_4, R.string.av_cloth_5, R.string.av_cloth_6, R.string.av_cloth_7)
    val TIERS_CLOTH = intArrayOf(0, 0, 0, 1, 2, 0, 0, 2)
    val NAMES_ACC = intArrayOf(R.string.av_acc_0, R.string.av_acc_1, R.string.av_acc_2, R.string.av_acc_3, R.string.av_acc_4, R.string.av_acc_5, R.string.av_acc_6, R.string.av_acc_7, R.string.av_acc_8)
    val TIERS_ACC = intArrayOf(0, 0, 2, 0, 0, 1, 0, 2, 1)
    val NAMES_SHOE = intArrayOf(R.string.av_shoe_0, R.string.av_shoe_1, R.string.av_shoe_2, R.string.av_shoe_3)
    val TIERS_SHOE = intArrayOf(0, 1, 2, 3)
    val NAMES = arrayOf(NAMES_SKIN, NAMES_HAT, NAMES_ANT, NAMES_FACE, NAMES_CLOTH, NAMES_ACC, NAMES_SHOE)
    val TIERS = arrayOf(TIERS_SKIN, TIERS_HAT, TIERS_ANT, TIERS_FACE, TIERS_CLOTH, TIERS_ACC, TIERS_SHOE)
    val CAT_TITLES = intArrayOf(R.string.cat_skin, R.string.cat_hat, R.string.cat_ant, R.string.cat_face, R.string.cat_cloth, R.string.cat_acc, R.string.cat_shoe)
    /** Personajes de la colección: nombre y (skin, sombrero, antena, rostro, ropa, accesorio, calzado). */
    val PRESETS: List<Pair<String, IntArray>> = listOf(
        "WAVKO Cyber" to intArrayOf(0, 1, 5, 7, 0, 1, 0),
        "WAVKO Golden" to intArrayOf(2, 4, 6, 7, 0, 2, 0),
        "WAVKO Tactical" to intArrayOf(8, 3, 0, 7, 3, 1, 1),
        "WAVKO Neon" to intArrayOf(3, 5, 4, 8, 4, 1, 3),
        "WAVKO Space" to intArrayOf(5, 5, 7, 6, 4, 7, 2),
        "WAVKO Red Storm" to intArrayOf(4, 0, 7, 2, 2, 3, 1)
    )
}
