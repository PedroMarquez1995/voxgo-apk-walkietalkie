package app.walkie.ptt

import android.Manifest
import android.annotation.SuppressLint
import android.appwidget.AppWidgetManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.button.MaterialButtonToggleGroup
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import org.json.JSONArray
import org.json.JSONObject
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.textfield.TextInputEditText
import okhttp3.OkHttpClient

class MainActivity : AppCompatActivity(), PttService.Listener {

    companion object {
        const val EXTRA_INVITE_CHANNEL = "invite_channel"
        const val EXTRA_INVITE_PASS = "invite_pass"
        const val EXTRA_INVITE_FROM = "invite_from"
        const val EXTRA_INVITE_ID = "invite_id"
        const val EXTRA_OPEN_VOICE = "open_voice"
    }

    private var service: PttService? = null
    private var pendingMode: String? = null
    private var welcomeDone = false

    // Bienvenida
    private lateinit var welcome: View
    private lateinit var welcomeRipple: RippleView
    private lateinit var welcomeLogo: View
    private lateinit var welcomeTitle: View
    private lateinit var welcomeTagline: View
    private lateinit var btnWelcome: Button

    // Cabecera
    private lateinit var statusDot: View
    private lateinit var statusView: TextView

    // Panel para crear / unirse
    private lateinit var panelConnect: View
    private lateinit var inputName: TextInputEditText
    private lateinit var inputChannel: TextInputEditText
    private lateinit var inputPass: TextInputEditText
    private lateinit var inputServer: TextInputEditText
    private lateinit var inputKey: TextInputEditText
    private lateinit var chkVolume: MaterialSwitch
    private lateinit var btnJoin: View
    private lateinit var btnCreate: View
    private lateinit var connectMsg: TextView

    // Panel del canal
    private lateinit var panelChannel: View
    private lateinit var channelTitle: TextView
    private lateinit var channelCount: TextView
    private lateinit var banner: View
    private lateinit var bannerBars: BarsView
    private lateinit var bannerText: TextView
    private lateinit var list: RecyclerView
    private val adapter = ParticipantAdapter { name -> onParticipantClick(name) }

    // Botón de hablar
    private lateinit var pttArea: View
    private lateinit var ripple: RippleView
    private lateinit var btnPtt: View
    private lateinit var pttLabel: TextView
    private lateinit var btnDisconnect: View

    // Pestañas
    private lateinit var tabChannels: View
    private lateinit var tabFriends: View
    private lateinit var tabProfile: View
    private lateinit var tabSettings: View
    private lateinit var bottomNav: BottomNavigationView

    // Amigos
    private lateinit var myCode: TextView
    private lateinit var inputFriendCode: TextInputEditText
    private lateinit var friendsEmpty: TextView
    private lateinit var friendsConn: TextView
    private lateinit var friendsList: RecyclerView
    private lateinit var friendsAdapter: FriendsAdapter
    private var friends = mutableListOf<Store.Friend>()
    private var friendStatus: Map<String, PresenceClient.FriendStatus> = emptyMap()
    private var presence: PresenceClient? = null
    private val presenceClient = OkHttpClient()

    // Perfil
    private lateinit var profileWalkie: WalkieView
    private lateinit var profileSkinName: TextView
    private lateinit var inputProfileName: TextInputEditText
    private lateinit var skinsRow: LinearLayout
    private var mySkin = 0

    private val prefs by lazy { Store.prefs(this) }

    private val cGreen by lazy { ContextCompat.getColor(this, R.color.green) }
    private val cAmber by lazy { ContextCompat.getColor(this, R.color.amber) }
    private val cGray = Color.parseColor("#6B6280")
    private val cPink by lazy { ContextCompat.getColor(this, R.color.pink) }
    private val cLavender by lazy { ContextCompat.getColor(this, R.color.lavender) }
    private var currentTab = R.id.nav_channels
    private var lastCanInvite = false
    private lateinit var recentsBox: View
    private lateinit var recentsRow: LinearLayout
    private lateinit var batteryStatus: TextView
    private lateinit var chkHd: MaterialSwitch
    private lateinit var chkBeep: MaterialSwitch
    private var inviteDialog: AlertDialog? = null

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = (binder as PttService.LocalBinder).service
            service?.listener = this@MainActivity
            // Si ya estabas dentro de un canal, no hace falta pasar otra vez por la bienvenida
            if (service?.state != PttService.DISCONNECTED) dismissWelcome(false)
            render()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            render()
        }
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val mode = pendingMode
            pendingMode = null
            if (mode != null) {
                if (hasMic()) {
                    doConnect(mode)
                } else {
                    toast(getString(R.string.mic_needed))
                }
            }
        }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        AppCompatDelegate.setDefaultNightMode(Store.nightMode(this))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        welcome = findViewById(R.id.welcome)
        welcomeRipple = findViewById(R.id.welcomeRipple)
        welcomeLogo = findViewById(R.id.welcomeLogo)
        welcomeTitle = findViewById(R.id.welcomeTitle)
        welcomeTagline = findViewById(R.id.welcomeTagline)
        btnWelcome = findViewById(R.id.btnWelcome)
        welcomeHello = findViewById(R.id.welcomeHello)
        btnGoogleCreate = findViewById(R.id.btnGoogleCreate)
        btnHaveAccount = findViewById(R.id.btnHaveAccount)
        googleEmail = prefs.getString("googleEmail", "") ?: ""

        statusDot = findViewById(R.id.statusDot)
        statusView = findViewById(R.id.status)

        panelConnect = findViewById(R.id.panelConnect)
        inputName = findViewById(R.id.inputName)
        inputChannel = findViewById(R.id.inputChannel)
        inputPass = findViewById(R.id.inputPass)
        inputServer = findViewById(R.id.inputServer)
        inputKey = findViewById(R.id.inputKey)
        chkVolume = findViewById(R.id.chkVolume)
        btnJoin = findViewById(R.id.btnJoin)
        btnCreate = findViewById(R.id.btnCreate)
        connectMsg = findViewById(R.id.connectMsg)

        panelChannel = findViewById(R.id.panelChannel)
        channelTitle = findViewById(R.id.channelTitle)
        channelCount = findViewById(R.id.channelCount)
        banner = findViewById(R.id.banner)
        bannerBars = findViewById(R.id.bannerBars)
        bannerText = findViewById(R.id.bannerText)
        list = findViewById(R.id.list)

        pttArea = findViewById(R.id.pttArea)
        ripple = findViewById(R.id.ripple)
        btnPtt = findViewById(R.id.btnPtt)
        pttLabel = findViewById(R.id.pttLabel)
        btnDisconnect = findViewById(R.id.btnDisconnect)

        tabChannels = findViewById(R.id.tabChannels)
        tabFriends = findViewById(R.id.tabFriends)
        tabProfile = findViewById(R.id.tabProfile)
        tabSettings = findViewById(R.id.tabSettings)
        bottomNav = findViewById(R.id.bottomNav)
        recentsBox = findViewById(R.id.recentsBox)
        recentsRow = findViewById(R.id.recentsRow)
        batteryStatus = findViewById(R.id.batteryStatus)
        chkHd = findViewById(R.id.chkHd)
        chkBeep = findViewById(R.id.chkBeep)

        myCode = findViewById(R.id.myCode)
        inputFriendCode = findViewById(R.id.inputFriendCode)
        friendsEmpty = findViewById(R.id.friendsEmpty)
        friendsConn = findViewById(R.id.friendsConn)
        friendsList = findViewById(R.id.friendsList)

        profileWalkie = findViewById(R.id.profileWalkie)
        profileSkinName = findViewById(R.id.profileSkinName)
        inputProfileName = findViewById(R.id.inputProfileName)
        skinsRow = findViewById(R.id.skinsRow)

        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        ripple.baseRadiusDp = 75f
        welcomeRipple.baseRadiusDp = 62f

        // Valores guardados (el canal y la clave del canal no se recuerdan a propósito)
        inputServer.setText(prefs.getString("server", BuildConfig.DEFAULT_SERVER))
        inputName.setText(Store.name(this))
        inputProfileName.setText(Store.name(this))
        mySkin = Store.skin(this)
        inputChannel.setText(prefs.getString("channel", ""))
        inputKey.setText(prefs.getString("key", BuildConfig.DEFAULT_KEY))
        chkVolume.isChecked = prefs.getBoolean("volPtt", false)

        setupTabs()
        val savedTab = savedInstanceState?.getInt("tab", R.id.nav_channels) ?: R.id.nav_channels
        if (savedTab != R.id.nav_channels) {
            tabChannels.visibility = View.GONE
            tabView(savedTab).visibility = View.VISIBLE
            currentTab = savedTab
            bottomNav.selectedItemId = savedTab
        }
        setupFriends()
        setupProfile()
        setupSettings()
        setupRecents()
        handleInviteIntent(intent)
        btnJoin.setOnClickListener { onConnectClicked("join") }
        btnCreate.setOnClickListener { onConnectClicked("create") }
        btnDisconnect.setOnClickListener { service?.disconnect() }
        findViewById<View>(R.id.btnChat).setOnClickListener { showChat() }
        btnWelcome.setOnClickListener { dismissWelcome(true) }

        btnPtt.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                    service?.startTalking()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    service?.stopTalking()
                }
            }
            true
        }

        renderWelcome()
        welcomeDone = savedInstanceState?.getBoolean("welcomeDone") == true
        if (welcomeDone) {
            welcome.visibility = View.GONE
        } else {
            playWelcome()
        }
        render()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleInviteIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        renderBattery()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("welcomeDone", welcomeDone)
        outState.putInt("tab", currentTab)
    }

    override fun onStart() {
        super.onStart()
        bindService(Intent(this, PttService::class.java), conn, Context.BIND_AUTO_CREATE)
        statusHandler.removeCallbacks(statusTick)
        statusHandler.post(statusTick)
        Inbox.listeners.add(inboxListener)
        refreshAccount()
        startPresence()
        if (Store.hasAccount(this)) askNotifications()
    }

    override fun onStop() {
        statusHandler.removeCallbacks(statusTick)
        Inbox.listeners.remove(inboxListener)
        presence?.stop()
        presence = null
        service?.listener = null
        try {
            unbindService(conn)
        } catch (e: IllegalArgumentException) {
        }
        service = null
        super.onStop()
    }

    override fun onChanged() = render()

    override fun onChat() {
        renderChat()
        val u = service?.chatUnread ?: 0
        findViewById<TextView>(R.id.btnChat).text =
            if (u > 0) getString(R.string.btn_chat_n, u) else getString(R.string.btn_chat)
    }

    // ------------------------------------------------------ Chat del canal

    private var chatDialog: android.app.Dialog? = null
    private var chatAdapter: ChatAdapter? = null
    private var chatListView: RecyclerView? = null

    /** Chat de texto del canal: burbujas estilo WhatsApp, cada persona con su nombre y su color. */
    private fun showChat() {
        val s = service ?: return
        s.chatUnread = 0
        findViewById<TextView>(R.id.btnChat).text = getString(R.string.btn_chat)
        val v = layoutInflater.inflate(R.layout.dialog_chat, null)
        val rv = v.findViewById<RecyclerView>(R.id.dChatList)
        val input = v.findViewById<EditText>(R.id.dChatInput)
        val adapter = ChatAdapter(showSender = true, onLong = { b -> askDeleteChat(b) })
        rv.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        rv.adapter = adapter
        chatAdapter = adapter
        chatListView = rv
        val send = {
            val t = input.text.toString()
            if (t.isNotBlank()) {
                service?.sendChat(t)
                input.setText("")
            }
        }
        v.findViewById<View>(R.id.dChatSend).setOnClickListener { send() }
        input.setOnEditorActionListener { _, _, _ -> send(); true }
        chatDialog?.dismiss()
        v.findViewById<TextView>(R.id.dChatTitle).text = getString(R.string.chat_title, s.channelName)
        Emojis.setup(this, v.findViewById(R.id.dChatEmoji), v.findViewById(R.id.dChatEmojiPanel), input)
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        dlg.setContentView(v)
        dlg.setOnDismissListener { chatAdapter = null; chatListView = null }
        v.findViewById<View>(R.id.dChatClose).setOnClickListener { dlg.dismiss() }
        dlg.window?.apply {
            setBackgroundDrawableResource(R.color.bg)
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT)
        }
        chatDialog = dlg
        dlg.show()
        renderChat()
    }

    private fun askDeleteChat(b: Bubble) {
        val opts = mutableListOf(getString(R.string.delete_for_me))
        if (b.mine) opts += getString(R.string.delete_for_all)
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_msg_title)
            .setItems(opts.toTypedArray()) { _, which -> service?.deleteChat(b.id, which == 1) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun renderChat() {
        val a = chatAdapter ?: return
        val s = service ?: return
        s.chatUnread = 0
        a.submit(s.chat.map { Bubble(it.id, it.mine, it.name, "text", it.text, 0, it.ts) })
        if (s.chat.isNotEmpty()) chatListView?.scrollToPosition(s.chat.size - 1)
    }

    private fun playWelcome() {
        welcomeRipple.start()
        val d = resources.displayMetrics.density
        listOf(welcomeLogo, welcomeTitle, welcomeTagline, btnWelcome).forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = 28f * d
            v.animate()
                .alpha(if (v === btnWelcome) welcomeButtonAlpha() else 1f)
                .translationY(0f)
                .setStartDelay(150L + i * 140L)
                .setDuration(600)
                .start()
        }
        welcomeLogo.scaleX = 0.75f
        welcomeLogo.scaleY = 0.75f
        welcomeLogo.animate().scaleX(1f).scaleY(1f).setStartDelay(150).setDuration(700).start()
    }

    private fun dismissWelcome(animated: Boolean) {
        if (welcomeDone) return
        welcomeDone = true
        if (animated) {
            welcome.animate().alpha(0f).setDuration(350).withEndAction {
                welcome.visibility = View.GONE
                welcomeRipple.stop()
            }.start()
        } else {
            welcome.visibility = View.GONE
            welcomeRipple.stop()
        }
    }

    // ---------------------------------------------------------------- Teclas

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (welcomeDone && chkVolume.isChecked && keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event?.repeatCount == 0) service?.startTalking()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (welcomeDone && chkVolume.isChecked && keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            service?.stopTalking()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    // ------------------------------------------------------------ Conexión

    private fun onConnectClicked(mode: String) {
        val s = service
        if (s == null) {
            toast(getString(R.string.service_not_ready))
            return
        }
        if (s.state != PttService.DISCONNECTED) return
        if (inputChannel.text.isNullOrBlank()) {
            inputChannel.error = getString(R.string.enter_channel)
            return
        }
        if (inputServer.text.isNullOrBlank()) {
            showTab(R.id.nav_settings)
            inputServer.error = getString(R.string.enter_server)
            return
        }
        val perms = mutableListOf<String>()
        if (!hasMic()) perms += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            perms += Manifest.permission.POST_NOTIFICATIONS
        }
        if (perms.isNotEmpty()) {
            pendingMode = mode
            permLauncher.launch(perms.toTypedArray())
        } else {
            doConnect(mode)
        }
    }

    private fun doConnect(mode: String) {
        val url = Store.normalizeUrl(inputServer.text.toString())
        val channel = inputChannel.text.toString().trim()
        val name = inputName.text.toString().trim().ifEmpty { Build.MODEL }
        inputProfileName.setText(name)
        val key = inputKey.text.toString()
        val pass = inputPass.text.toString()

        prefs.edit()
            .putString("server", inputServer.text.toString().trim())
            .putString("name", name)
            .putString("channel", channel)
            .putString("key", key)
            .putBoolean("volPtt", chkVolume.isChecked)
            .apply()

        Store.touchChannel(this, channel, created = mode == "create")
        renderRecents()
        ContextCompat.startForegroundService(this, Intent(this, PttService::class.java))
        service?.connect(url, channel, name, key, mode, pass, mySkin)
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    // ------------------------------------------------------------------ UI

    private fun render() {
        val s = service
        val st = s?.state ?: PttService.DISCONNECTED
        val disconnected = st == PttService.DISCONNECTED
        val connected = st == PttService.CONNECTED
        val tx = s?.transmitting == true
        val talker = s?.talker
        val users = s?.users ?: emptyList()

        if (connected != lastCanInvite) {
            lastCanInvite = connected
            if (::friendsAdapter.isInitialized) renderFriends()
        }

        // Chip de estado
        statusView.text = if (disconnected) getString(R.string.disconnected) else (s?.statusText ?: "")
        val dot = when (st) {
            PttService.CONNECTED -> cGreen
            PttService.CONNECTING -> cAmber
            else -> cGray
        }
        statusDot.backgroundTintList = ColorStateList.valueOf(dot)

        // Qué panel se ve
        panelConnect.visibility = if (disconnected) View.VISIBLE else View.GONE
        panelChannel.visibility = if (disconnected) View.GONE else View.VISIBLE
        pttArea.visibility = if (disconnected) View.GONE else View.VISIBLE
        btnDisconnect.visibility = if (disconnected) View.GONE else View.VISIBLE

        if (disconnected) {
            // Mensaje de error / motivo de la desconexión (p. ej. "Ese canal no existe")
            val msg = s?.statusText.orEmpty()
            if (msg.isEmpty() || msg == getString(R.string.disconnected)) {
                connectMsg.visibility = View.GONE
            } else {
                connectMsg.text = msg
                connectMsg.visibility = View.VISIBLE
            }
            ripple.stop()
            bannerBars.stop()
            return
        }
        connectMsg.visibility = View.GONE

        // Canal
        val ch = s?.channelName.orEmpty()
        channelTitle.text = if (ch.isEmpty()) getString(R.string.connecting) else "#$ch"
        channelCount.text = resources.getQuantityString(R.plurals.connected_count, users.size, users.size)

        // Quién está hablando
        when {
            tx -> {
                bannerText.text = getString(R.string.you_transmitting)
                bannerText.setTextColor(android.graphics.Color.WHITE)
                banner.setBackgroundResource(R.drawable.bg_banner_tx)
                bannerBars.setColor(cPink)
                bannerBars.visibility = View.VISIBLE
                bannerBars.start()
            }
            talker != null -> {
                bannerText.text = getString(R.string.someone_talking, talker)
                bannerText.setTextColor(ContextCompat.getColor(this, R.color.text))
                banner.setBackgroundResource(R.drawable.bg_banner_talk)
                bannerBars.setColor(cLavender)
                bannerBars.visibility = View.VISIBLE
                bannerBars.start()
            }
            else -> {
                bannerText.text = if (connected) getString(R.string.channel_free) else getString(R.string.connecting)
                bannerText.setTextColor(ContextCompat.getColor(this, R.color.text))
                banner.setBackgroundResource(R.drawable.bg_banner_idle)
                bannerBars.stop()
                bannerBars.visibility = View.GONE
            }
        }

        adapter.submit(users, s?.myName.orEmpty(), talker, tx, s?.skins ?: emptyMap(), mySkin)
        if (connected) maybeAskBattery()

        // Botón de hablar
        val busy = !tx && talker != null
        btnPtt.setBackgroundResource(
            when {
                tx -> R.drawable.bg_ptt_tx
                connected -> R.drawable.bg_ptt_idle
                else -> R.drawable.bg_ptt_off
            }
        )
        btnPtt.alpha = if (busy) 0.55f else 1f
        pttLabel.text = when {
            tx -> getString(R.string.ptt_tx)
            !connected -> getString(R.string.ptt_connecting)
            busy -> getString(R.string.ptt_busy)
            else -> getString(R.string.ptt_hold)
        }
        if (tx) {
            ripple.setColor(cPink)
            ripple.start()
        } else {
            ripple.stop()
        }
    }

    // ------------------------------------------------------------- Pestañas

    private fun setupTabs() {
        bottomNav.setOnItemSelectedListener { item ->
            showTab(item.itemId, fromNav = true)
            true
        }
    }

    private fun tabView(id: Int): View = when (id) {
        R.id.nav_friends -> tabFriends
        R.id.nav_profile -> tabProfile
        R.id.nav_settings -> tabSettings
        else -> tabChannels
    }

    private fun tabIndex(id: Int) = when (id) {
        R.id.nav_friends -> 1
        R.id.nav_profile -> 2
        R.id.nav_settings -> 3
        else -> 0
    }

    private fun showTab(id: Int, fromNav: Boolean = false) {
        if (id != currentTab) {
            val dir = if (tabIndex(id) > tabIndex(currentTab)) 1f else -1f
            val d = resources.displayMetrics.density
            tabView(currentTab).visibility = View.GONE
            val next = tabView(id)
            next.visibility = View.VISIBLE
            next.alpha = 0f
            next.translationX = 28f * d * dir
            next.animate().alpha(1f).translationX(0f).setDuration(220).start()
            currentTab = id
            if (id == R.id.nav_settings) renderBattery()
        }
        if (!fromNav) bottomNav.selectedItemId = id
    }

    // ------------------------------------------------------ Cuenta y amigos

    private val api by lazy { AccountApi(presenceClient, android.os.Handler(mainLooper)) }
    private var registering = false
    private var presenceConnected = true
    private var incoming = listOf<Store.Friend>()
    private var outgoing = listOf<Store.Friend>()
    private var blockedPeople = listOf<Store.Friend>()
    private lateinit var requestsBox: View
    private lateinit var requestsList: LinearLayout
    private lateinit var outgoingText: TextView
    private lateinit var accountStatus: TextView
    private lateinit var blockedList: LinearLayout
    private lateinit var blockedEmpty: TextView
    private val inboxListener: () -> Unit = { renderFriends() }
    private var googleEmail = ""   // correo de Google vinculado (también se guarda en prefs)
    private lateinit var welcomeHello: TextView
    private lateinit var btnGoogleCreate: View
    private lateinit var btnHaveAccount: View
    private var googleOn = false   // el servidor tiene el acceso con Google activado

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { Push.register(this) }

    private fun setupFriends() {
        requestsBox = findViewById(R.id.requestsBox)
        requestsList = findViewById(R.id.requestsList)
        outgoingText = findViewById(R.id.outgoingText)
        accountStatus = findViewById(R.id.accountStatus)
        blockedList = findViewById(R.id.blockedList)
        blockedEmpty = findViewById(R.id.blockedEmpty)

        friends = Store.loadFriends(this)
        blockedPeople = Store.loadBlocked(this).map { Store.Friend(it, "", 0) }
        friendsAdapter = FriendsAdapter(
            { f -> openChat(f) },
            { f -> confirmRemoveFriend(f) },
            { f, wasBlocked -> if (wasBlocked) unblockPerson(f.code) else confirmBlock(f) },
            { f -> inviteFriend(f) }
        )
        // El mismo cuadro sirve para buscar (nombre o código) y para añadir un amigo nuevo
        inputFriendCode.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) = renderFriends()
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        friendsList.layoutManager = LinearLayoutManager(this)
        friendsList.adapter = friendsAdapter

        findViewById<View>(R.id.btnCopyCode).setOnClickListener {
            copyText(Store.friendCode(this))
            toast(getString(R.string.code_copied))
        }
        findViewById<View>(R.id.btnShareCode).setOnClickListener {
            val text = getString(R.string.share_text, Store.prettyCode(Store.friendCode(this)))
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text),
                    getString(R.string.share_code)
                )
            )
        }
        findViewById<View>(R.id.btnAddFriend).setOnClickListener { addFriend() }

        findViewById<View>(R.id.btnGoogleCreate).setOnClickListener { googleCreate() }
        findViewById<View>(R.id.btnHaveAccount).setOnClickListener { googleLoginExisting() }
        findViewById<View>(R.id.btnGoogle).setOnClickListener { googleChange() }
        findViewById<View>(R.id.btnLogout).setOnClickListener { confirmSignOut() }
        findViewById<View>(R.id.btnDeleteAccount).setOnClickListener { confirmDeleteAccount() }
        findViewById<View>(R.id.updateCard).visibility = if (Updater.available()) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnUpdate).setOnClickListener { checkUpdates() }

        renderFriends()
        renderRequests()
        renderBlocked()
        renderAccount()
    }

    private fun copyText(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(getString(R.string.app_name), text))
    }

    private fun addFriend() {
        val code = Store.cleanCode(inputFriendCode.text.toString())
        when {
            code.length < 4 -> inputFriendCode.error = getString(R.string.code_invalid)
            code == Store.friendCode(this) -> inputFriendCode.error = getString(R.string.code_own)
            friends.any { it.code == code } -> inputFriendCode.error = getString(R.string.code_dup)
            else -> sendFriendRequest(code, true)
        }
    }

    private fun sendFriendRequest(code: String, fromForm: Boolean) {
        if (!Store.hasAccount(this)) {
            toast(getString(R.string.account_pending))
            return
        }
        api.call(this, "POST", "/api/friends/add", JSONObject().put("code", code)) { r ->
            if (r.ok) {
                if (fromForm) inputFriendCode.setText("")
                val friendsNow = r.json?.optString("state") == "friends"
                toast(getString(if (friendsNow) R.string.friend_added else R.string.request_sent))
                refreshAccount()
            } else if (r.status == 401) {
                sessionClosed()
            } else if (r.error == "not_found") {
                if (fromForm) inputFriendCode.error = getString(R.string.code_notfound)
            } else if (r.error == "blocked") {
                toast(getString(R.string.you_blocked_that))
            } else if (r.error == "full") {
                toast(getString(R.string.friends_full))
            } else if (r.error == "invalid") {
                if (fromForm) inputFriendCode.error = getString(R.string.code_invalid)
            } else {
                toast(getString(R.string.recover_offline))
            }
        }
    }

    private fun removeFriend(code: String) = simplePost("/api/friends/remove", code, R.string.friend_removed)

    private fun blockPerson(code: String) = simplePost("/api/block", code, R.string.user_blocked)

    private fun unblockPerson(code: String) = simplePost("/api/unblock", code, R.string.user_unblocked)

    private fun simplePost(path: String, code: String, msg: Int) {
        api.call(this, "POST", path, JSONObject().put("code", code)) { r ->
            if (r.ok) {
                toast(getString(msg))
                refreshAccount()
            } else if (r.status == 401) {
                sessionClosed()
            } else {
                toast(getString(R.string.recover_offline))
            }
        }
    }

    private fun respondRequest(code: String, accept: Boolean) {
        api.call(
            this, "POST", "/api/friends/respond",
            JSONObject().put("code", code).put("accept", accept)
        ) { r ->
            if (r.status == 401) {
                sessionClosed()
            } else {
                if (r.ok && accept) toast(getString(R.string.friend_added))
                refreshAccount()
            }
        }
    }

    private fun parsePeople(a: JSONArray?): List<Store.Friend> {
        if (a == null) return emptyList()
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Store.Friend(o.optString("code"), o.optString("name"), o.optInt("skin", 0))
        }
    }

    /** Descarga del servidor amigos, solicitudes y bloqueados. */
    private fun refreshAccount() {
        if (!Store.hasAccount(this)) return
        api.call(this, "GET", "/api/me") { r ->
            val j = r.json
            if (r.status == 401) {
                sessionClosed()
            } else if (r.ok && j != null) {
                friends = parsePeople(j.optJSONArray("friends")).toMutableList()
                incoming = parsePeople(j.optJSONArray("incoming"))
                outgoing = parsePeople(j.optJSONArray("outgoing"))
                blockedPeople = parsePeople(j.optJSONArray("blocked"))
                cacheGoogle(j.optString("google"))
                googleOn = j.optBoolean("googleEnabled", false)
                renderAccount()
                renderWelcome()
                Store.saveFriends(this, friends)
                Store.saveBlocked(this, blockedPeople.map { it.code })
                service?.updateMuted()
                renderFriends()
                renderRequests()
                renderBlocked()
                Inbox.sync(this, api)
            }
        }
    }

    private fun sessionClosed() {
        Store.clearToken(this)
        presence?.stop()
        presence = null
        cacheGoogle("")
        renderAccount()
        showWelcomeAgain()
        toast(getString(R.string.session_closed))
    }

    /** La primera vez se crea la cuenta sola; se conserva el código que ya tenías. */
    // ------------------------------------------------------ Inicio con Google

    private fun cacheGoogle(email: String) {
        googleEmail = email
        prefs.edit().putString("googleEmail", email).apply()
    }

    /** Con Google configurado, solo se puede seguir si la cuenta tiene un Google vinculado. */
    private fun googleSigned() = !GoogleAuth.enabled() || (Store.hasAccount(this) && googleEmail.isNotEmpty())

    private fun welcomeButtonAlpha() = if (googleSigned()) 1f else 0.35f

    private fun renderWelcome() {
        val ok = googleSigned()
        btnWelcome.isEnabled = ok
        // Si se interrumpió la animación de entrada, deja todo en su sitio (sin botones encimados ni desplazados)
        listOf(welcomeLogo, welcomeTitle, welcomeTagline, btnWelcome).forEach {
            it.animate().cancel()
            it.translationY = 0f
            it.alpha = 1f
        }
        welcomeLogo.scaleX = 1f
        welcomeLogo.scaleY = 1f
        btnWelcome.alpha = welcomeButtonAlpha()
        val showHello = ok && GoogleAuth.enabled()
        welcomeHello.visibility = if (showHello) View.VISIBLE else View.GONE
        welcomeHello.text = getString(R.string.welcome_hello, Store.name(this))
        val showButtons = !ok && GoogleAuth.enabled()
        btnGoogleCreate.visibility = if (showButtons) View.VISIBLE else View.GONE
        btnHaveAccount.visibility = if (showButtons) View.VISIBLE else View.GONE
    }

    private fun showWelcomeAgain() {
        welcomeDone = false
        welcome.animate().cancel()
        welcome.alpha = 1f
        welcome.visibility = View.VISIBLE
        renderWelcome()
        welcomeRipple.start()
    }

    private fun googleError(status: Int, err: String?) {
        toast(
            getString(
                when {
                    status == 0 -> R.string.recover_offline
                    err == "google_taken" -> R.string.google_taken
                    err == "not_linked" -> R.string.google_not_linked
                    err == "google_off" -> R.string.google_off
                    else -> R.string.google_failed
                }
            )
        )
    }

    private fun googleFailed(err: String?) {
        if (err != null) toast(getString(R.string.google_failed) + " (" + err.take(160) + ")")
    }

    /** Crea la cuenta del teléfono si todavía no existe (se necesita para vincular Google). */
    private fun registerAnon(cb: (Boolean) -> Unit) {
        if (Store.hasAccount(this)) {
            cb(true)
            return
        }
        val body = JSONObject()
            .put("name", Store.name(this))
            .put("skin", mySkin)
            .put("code", Store.friendCode(this))
        api.call(this, "POST", "/api/register", body, auth = false) { r ->
            val j = r.json
            if (r.ok && j != null) {
                Store.saveAccount(this, j.optString("code"), j.optString("token"), j.optString("recovery"))
                cb(true)
            } else {
                cb(false)
            }
        }
    }

    private fun setProfileName(n: String) {
        prefs.edit().putString("name", n).apply()
        inputName.setText(n)
        inputProfileName.setText(n)
    }

    /** Tras entrar o vincular: se pone al día todo y se muestra el saludo. */
    private fun afterAccount() {
        renderAccount()
        renderWelcome()
        refreshAccount()
        startPresence()
        Push.register(this)
        askNotifications()
    }

    private fun afterLogin(j: JSONObject, email: String) {
        Store.saveAccount(this, j.optString("code"), j.optString("token"), null)
        val nm = j.optString("name")
        if (nm.isNotBlank()) setProfileName(nm)
        selectSkin(j.optInt("skin", 0))
        cacheGoogle(email)
        afterAccount()
    }

    /** "Crear cuenta con Google": si ese Google ya tiene cuenta entra; si no, vincula la cuenta de este teléfono. */
    private fun googleCreate() {
        GoogleAuth.idToken(this) { tok, err ->
            if (tok == null) {
                googleFailed(err)
                return@idToken
            }
            val email = GoogleAuth.lastEmail
            val gname = GoogleAuth.lastName
            api.call(this, "POST", "/api/google/login", JSONObject().put("idToken", tok), auth = false) { r ->
                val j = r.json
                if (r.ok && j != null) {
                    afterLogin(j, email)
                } else if (r.error == "not_linked") {
                    registerAnon { ok ->
                        if (!ok) {
                            toast(getString(R.string.recover_offline))
                        } else {
                            api.call(this, "POST", "/api/google/link", JSONObject().put("idToken", tok)) { r2 ->
                                if (r2.ok) {
                                    if (prefs.getString("name", null).isNullOrBlank() && gname.isNotBlank()) {
                                        setProfileName(gname)
                                        syncProfile()
                                    }
                                    cacheGoogle(email)
                                    afterAccount()
                                } else {
                                    googleError(r2.status, r2.error)
                                }
                            }
                        }
                    }
                } else {
                    googleError(r.status, r.error)
                }
            }
        }
    }

    /** "Ya tengo cuenta": solo entra con un Google que ya tenga cuenta Wavko. */
    private fun googleLoginExisting() {
        GoogleAuth.idToken(this) { tok, err ->
            if (tok == null) {
                googleFailed(err)
                return@idToken
            }
            val email = GoogleAuth.lastEmail
            api.call(this, "POST", "/api/google/login", JSONObject().put("idToken", tok), auth = false) { r ->
                val j = r.json
                if (r.ok && j != null) afterLogin(j, email) else googleError(r.status, r.error)
            }
        }
    }

    /** Perfil: cambiar el correo de Google vinculado a esta cuenta. */
    private fun googleChange() {
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_google_change)
            .setMessage(getString(R.string.google_change_msg, googleEmail.ifEmpty { "—" }))
            .setPositiveButton(R.string.continue_) { _, _ ->
                GoogleAuth.idToken(this) { tok, err ->
                    if (tok == null) {
                        googleFailed(err)
                        return@idToken
                    }
                    val email = GoogleAuth.lastEmail
                    api.call(this, "POST", "/api/google/link", JSONObject().put("idToken", tok)) { r ->
                        if (r.ok) {
                            cacheGoogle(email)
                            renderAccount()
                            toast(getString(R.string.google_link_ok))
                        } else {
                            googleError(r.status, r.error)
                        }
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ------------------------------------------------------ Cerrar sesión / eliminar cuenta

    private fun confirmSignOut() {
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_logout)
            .setMessage(R.string.logout_msg)
            .setPositiveButton(R.string.btn_logout) { _, _ -> doSignOut() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirmDeleteAccount() {
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_delete_account)
            .setMessage(R.string.delete_account_msg)
            .setPositiveButton(R.string.delete_account_confirm) { _, _ ->
                api.call(this, "POST", "/api/account/delete", JSONObject()) { r ->
                    if (r.ok || r.status == 401) {
                        doSignOut(wipe = true)
                        toast(getString(R.string.account_deleted))
                    } else {
                        toast(getString(if (r.status == 0) R.string.recover_offline else R.string.google_failed))
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    /** Deja este teléfono sin sesión (la cuenta sigue en el servidor y se recupera entrando con Google). */
    private fun doSignOut(wipe: Boolean = false) {
        service?.disconnect()
        presence?.stop()
        presence = null
        try {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().deleteToken()
        } catch (e: Exception) {
            // Firebase no está configurado
        }
        Store.signOut(this, wipe)
        googleEmail = ""
        incoming = emptyList()
        outgoing = emptyList()
        channelCounts = emptyMap()
        if (wipe) {
            friends = mutableListOf()
            blockedPeople = emptyList()
            Chats.clearAll(this)
        }
        renderAccount()
        renderFriends()
        renderRequests()
        renderBlocked()
        renderRecents()
        showTab(R.id.nav_channels)
        showWelcomeAgain()
    }

    private fun renderAccount() {
        myCode.text = Store.prettyCode(Store.friendCode(this))
        accountStatus.text = if (Store.hasAccount(this)) {
            getString(R.string.account_active, Store.prettyCode(Store.friendCode(this)))
        } else {
            getString(R.string.account_pending)
        }
        if (googleEmail.isNotEmpty()) {
            accountStatus.text = accountStatus.text.toString() + "\n" + getString(R.string.google_linked, googleEmail)
        }
        findViewById<TextView>(R.id.btnGoogle).apply {
            visibility = if (GoogleAuth.enabled() && Store.hasAccount(this@MainActivity)) View.VISIBLE else View.GONE
            text = getString(R.string.btn_google_change)
        }
        val msg = when {
            !Store.hasAccount(this) -> getString(R.string.account_pending)
            !presenceConnected -> getString(R.string.friends_offline)
            else -> ""
        }
        friendsConn.visibility = if (msg.isEmpty()) View.GONE else View.VISIBLE
        friendsConn.text = msg
    }

    private fun personLabel(p: Store.Friend) = p.name.ifBlank { Store.prettyCode(p.code) }

    private fun renderFriends() {
        val q = inputFriendCode.text.toString().trim()
        val qc = Store.cleanCode(q)
        val ql = q.lowercase()
        fun match(p: Store.Friend) = p.name.lowercase().contains(ql) || (qc.isNotEmpty() && p.code.contains(qc))
        val rows = mutableListOf<FriendsAdapter.Row>()
        if (q.isEmpty()) {
            friends.forEach { rows += FriendsAdapter.Row(it, false) }
        } else {
            friends.filter { match(it) }.forEach { rows += FriendsAdapter.Row(it, false) }
            blockedPeople.filter { match(it) }.forEach { rows += FriendsAdapter.Row(it, true) }
        }
        friendsEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        friendsEmpty.text = getString(if (q.isEmpty()) R.string.friends_empty else R.string.friends_no_results)
        friendsAdapter.submit(rows, friendStatus, service?.state == PttService.CONNECTED)
    }

    private fun openChat(f: Store.Friend) {
        startActivity(
            Intent(this, ChatActivity::class.java)
                .putExtra(ChatActivity.EXTRA_CODE, f.code)
                .putExtra(ChatActivity.EXTRA_NAME, f.name)
                .putExtra(ChatActivity.EXTRA_SKIN, friendStatus[f.code]?.skin ?: f.skin)
        )
    }

    private fun confirmRemoveFriend(f: Store.Friend) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.remove_friend_title, personLabel(f)))
            .setMessage(R.string.remove_friend_msg)
            .setPositiveButton(R.string.friend_menu_remove) { _, _ -> removeFriend(f.code) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirmBlock(f: Store.Friend) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.block_title, personLabel(f)))
            .setMessage(R.string.block_msg)
            .setPositiveButton(R.string.friend_menu_block) { _, _ -> blockPerson(f.code) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun renderRequests() {
        requestsBox.visibility = if (incoming.isEmpty()) View.GONE else View.VISIBLE
        requestsList.removeAllViews()
        for (q in incoming) {
            val v = layoutInflater.inflate(R.layout.item_request, requestsList, false)
            v.findViewById<WalkieView>(R.id.rAvatar).setSkin(q.skin)
            v.findViewById<TextView>(R.id.rName).text = personLabel(q)
            v.findViewById<TextView>(R.id.rSub).text = getString(R.string.request_sub, Store.prettyCode(q.code))
            v.findViewById<View>(R.id.rAccept).setOnClickListener { respondRequest(q.code, true) }
            v.findViewById<View>(R.id.rDecline).setOnClickListener { respondRequest(q.code, false) }
            v.findViewById<View>(R.id.rBlock).setOnClickListener { blockPerson(q.code) }
            requestsList.addView(v)
        }
        outgoingText.visibility = if (outgoing.isEmpty()) View.GONE else View.VISIBLE
        outgoingText.text = getString(R.string.pending_sent, outgoing.joinToString(", ") { personLabel(it) })
    }

    private fun renderBlocked() {
        blockedEmpty.visibility = if (blockedPeople.isEmpty()) View.VISIBLE else View.GONE
        blockedList.removeAllViews()
        for (p in blockedPeople) {
            val v = layoutInflater.inflate(R.layout.item_blocked, blockedList, false)
            v.findViewById<TextView>(R.id.bName).text = personLabel(p)
            v.findViewById<View>(R.id.bUnblock).setOnClickListener { unblockPerson(p.code) }
            blockedList.addView(v)
        }
    }

    private fun startPresence() {
        val url = Store.normalizeUrl(prefs.getString("server", BuildConfig.DEFAULT_SERVER) ?: "")
        if (url.isEmpty() || !Store.hasAccount(this)) return
        presence?.stop()
        presence = PresenceClient(presenceClient, android.os.Handler(mainLooper)).also { pc ->
            pc.listener = object : PresenceClient.Listener {
                override fun onStatus(list: List<PresenceClient.FriendStatus>) {
                    friendStatus = list.associateBy { it.code }
                    renderFriends()
                }

                override fun onInvite(fromCode: String, fromName: String, skin: Int, channel: String, pass: String) {
                    showInvite(fromName, channel, pass)
                }

                override fun onInviteResult(toCode: String, delivered: Boolean) {
                    toast(getString(if (delivered) R.string.invite_sent else R.string.invite_failed))
                }

                override fun onFriendsChanged() = refreshAccount()

                override fun onVoice(fromName: String) {
                    Inbox.sync(this@MainActivity, api)
                    toast(getString(R.string.voice_notif_title, fromName.ifBlank { getString(R.string.a_friend) }))
                }

                override fun onAuthError() = sessionClosed()

                override fun onConnection(connected: Boolean) {
                    presenceConnected = connected
                    renderAccount()
                }
            }
            pc.start(
                url, prefs.getString("key", BuildConfig.DEFAULT_KEY) ?: "",
                Store.friendCode(this), Store.token(this), Store.name(this), mySkin,
                service?.state == PttService.CONNECTED
            )
        }
    }

    // ------------------------------------------------------ Recuperación de cuenta

    private var pendingUpdate: Updater.Info? = null

    private fun checkUpdates() {
        val status = findViewById<TextView>(R.id.updateStatus)
        val btn = findViewById<TextView>(R.id.btnUpdate)
        val u = pendingUpdate
        if (u != null) {
            status.text = getString(R.string.update_downloading)
            Updater.install(this, u) { err ->
                status.text = when (err) {
                    null -> getString(R.string.update_opening)
                    "permission" -> getString(R.string.update_permission)
                    else -> getString(R.string.update_failed)
                }
            }
            return
        }
        status.text = getString(R.string.update_checking)
        Updater.check { info, err ->
            when {
                err != null -> status.text = getString(R.string.update_failed)
                info == null -> status.text = getString(R.string.update_latest)
                else -> {
                    pendingUpdate = info
                    status.text = getString(R.string.update_new, info.name)
                    btn.text = getString(R.string.btn_install_update)
                }
            }
        }
    }

    /**
     * Correo y contraseña. login=true (bienvenida): Entrar con una cuenta existente o Crear cuenta.
     * login=false (Perfil): asocia o cambia el correo y la contraseña de esta cuenta.
     */
    /** Vincula (o desvincula) tu cuenta de Google: así puedes recuperar tu cuenta sin la clave. */
    /** Entrar con Google (por ejemplo tras reinstalar): recupera tu cuenta y tus amigos. */
    // ------------------------------------------- Acciones sobre participantes del canal

    private fun onParticipantClick(name: String) {
        val s = service ?: return
        if (name == s.myName || s.state != PttService.CONNECTED) return
        val code = s.codes[name].orEmpty()
        val options = mutableListOf<Pair<String, () -> Unit>>()
        if (code.isNotEmpty()) {
            if (blockedPeople.any { it.code == code }) {
                options += getString(R.string.btn_unblock) to { unblockPerson(code) }
            } else {
                if (friends.none { it.code == code } && outgoing.none { it.code == code }) {
                    options += getString(R.string.act_add_friend) to { sendFriendRequest(code, false) }
                }
                options += getString(R.string.btn_block) to { blockPerson(code) }
            }
        }
        options += getString(R.string.act_kick) to {
            if (s.owner.isNotEmpty() && s.owner == s.myName) {
                s.kick(name)
                toast(getString(R.string.kick_done, name))
            } else {
                toast(getString(R.string.kick_owner_only))
            }
        }
        if (options.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(options.map { it.first }.toTypedArray()) { _, i -> options[i].second() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    /** Guarda nombre/skin en el servidor y avisa a la presencia. */
    private fun syncProfile() {
        presence?.update(Store.name(this), mySkin)
        if (Store.hasAccount(this)) {
            api.call(
                this, "POST", "/api/profile",
                JSONObject().put("name", Store.name(this)).put("skin", mySkin)
            ) { }
        }
    }

    // --------------------------------------------------------------- Perfil

    private fun setupProfile() {
        val d = resources.displayMetrics.density
        for (i in Skins.all.indices) {
            val cell = FrameLayout(this)
            val lp = LinearLayout.LayoutParams((72 * d).toInt(), (100 * d).toInt())
            lp.marginEnd = (10 * d).toInt()
            cell.layoutParams = lp
            cell.tag = i
            val w = WalkieView(this)
            w.setSkin(i)
            val wlp = FrameLayout.LayoutParams((40 * d).toInt(), (56 * d).toInt())
            wlp.gravity = android.view.Gravity.CENTER
            cell.addView(w, wlp)
            cell.setOnClickListener { selectSkin(i) }
            skinsRow.addView(cell)
        }
        findViewById<View>(R.id.btnSaveName).setOnClickListener {
            val n = inputProfileName.text.toString().trim()
            if (n.isEmpty()) {
                inputProfileName.error = getString(R.string.enter_name)
                return@setOnClickListener
            }
            prefs.edit().putString("name", n).apply()
            inputName.setText(n)
            syncProfile()
            toast(getString(R.string.name_saved))
        }
        selectSkin(mySkin, save = false)
    }

    private fun selectSkin(i: Int, save: Boolean = true) {
        mySkin = i
        if (save) {
            prefs.edit().putInt("skin", i).apply()
            syncProfile()
        }
        profileWalkie.setSkin(i)
        profileSkinName.text = resources.getStringArray(R.array.skin_names).getOrElse(i) { "" }
        for (k in 0 until skinsRow.childCount) {
            skinsRow.getChildAt(k).setBackgroundResource(
                if (k == i) R.drawable.bg_skin_selected else R.drawable.bg_skin_normal
            )
        }
        if (save && service?.state == PttService.DISCONNECTED) render()
    }

    // -------------------------------------------------------------- Ajustes

    private fun setupSettings() {
        chkVolume.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("volPtt", on).apply() }
        chkBeep.isChecked = prefs.getBoolean("beep", true)
        chkBeep.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("beep", on).apply() }
        chkHd.isChecked = prefs.getBoolean("hd", false)
        chkHd.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("hd", on).apply()
            if (on && !OpusCodec.encoderAvailable()) toast(getString(R.string.hd_unavailable))
        }
        val themeGroup = findViewById<MaterialButtonToggleGroup>(R.id.themeGroup)
        themeGroup.check(
            when (Store.themeMode(this)) {
                1 -> R.id.themeLight
                2 -> R.id.themeDark
                else -> R.id.themeSystem
            }
        )
        themeGroup.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val mode = when (id) {
                R.id.themeLight -> 1
                R.id.themeDark -> 2
                else -> 0
            }
            if (mode != Store.themeMode(this)) {
                prefs.edit().putInt("theme", mode).apply()
                AppCompatDelegate.setDefaultNightMode(Store.nightMode(this))
            }
        }
        findViewById<View>(R.id.btnBattery).setOnClickListener { openBatterySettings() }
        findViewById<View>(R.id.btnBrandGuide).setOnClickListener {
            val brand = Build.MANUFACTURER.lowercase().trim().replace(" ", "-")
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://dontkillmyapp.com/$brand")))
            } catch (e: Exception) {
                toast(getString(R.string.no_browser))
            }
        }
        renderBattery()
        findViewById<View>(R.id.btnSaveServer).setOnClickListener {
            prefs.edit()
                .putString("server", inputServer.text.toString().trim())
                .putString("key", inputKey.text.toString())
                .apply()
            refreshAccount()
            refreshAccount()
            startPresence()
            toast(getString(R.string.server_saved))
        }
        findViewById<View>(R.id.btnAddWidget).setOnClickListener {
            val mgr = AppWidgetManager.getInstance(this)
            if (mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(ComponentName(this, PttWidgetProvider::class.java), null, null)
            } else {
                toast(getString(R.string.widget_manual))
            }
        }
        val ver = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            ""
        }
        findViewById<TextView>(R.id.aboutText).text = getString(R.string.about, ver)
    }

    // ------------------------------------------------------ Batería / segundo plano

    private fun ignoringBattery(): Boolean = try {
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
    } catch (e: Exception) {
        true
    }

    private fun renderBattery() {
        val ok = ignoringBattery()
        batteryStatus.text = getString(if (ok) R.string.battery_ok else R.string.battery_restricted)
        batteryStatus.setTextColor(if (ok) cGreen else cAmber)
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            } catch (e2: Exception) {
                toast(getString(R.string.no_browser))
            }
        }
    }

    /** La primera vez que te conectas, si la batería puede cerrar Wavko, te lo avisamos. */
    private fun maybeAskBattery() {
        if (prefs.getBoolean("batteryAsked", false) || ignoringBattery()) return
        prefs.edit().putBoolean("batteryAsked", true).apply()
        AlertDialog.Builder(this)
            .setTitle(R.string.battery_dialog_title)
            .setMessage(R.string.battery_dialog_text)
            .setPositiveButton(R.string.battery_fix) { _, _ -> openBatterySettings() }
            .setNegativeButton(R.string.later, null)
            .show()
    }

    // ------------------------------------------------------ Invitaciones

    private fun inviteFriend(f: Store.Friend) {
        val s = service ?: return
        if (s.state != PttService.CONNECTED || s.channelName.isEmpty()) return
        val sent = presence?.sendInvite(f.code, s.channelName, s.channelPass) ?: false
        if (!sent) toast(getString(R.string.invite_failed))
    }

    private fun showInvite(from: String, channel: String, pass: String) {
        Store.touchChannel(this, channel, invited = true)
        renderRecents()
        inviteDialog?.dismiss()
        val who = from.ifBlank { getString(R.string.a_friend) }
        inviteDialog = AlertDialog.Builder(this)
            .setTitle(getString(R.string.invite_title, who))
            .setMessage(getString(R.string.invite_text, channel))
            .setPositiveButton(R.string.join) { _, _ -> acceptInvite(channel, pass) }
            .setNegativeButton(R.string.ignore, null)
            .show()
    }

    private fun acceptInvite(channel: String, pass: String) {
        showTab(R.id.nav_channels)
        if (service?.state != PttService.DISCONNECTED) {
            toast(getString(R.string.leave_first))
            return
        }
        inputChannel.setText(channel)
        inputPass.setText(pass)
        onConnectClicked("join")
    }

    private fun handleInviteIntent(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_OPEN_VOICE, false) == true) {
            i.removeExtra(EXTRA_OPEN_VOICE)
            showTab(R.id.nav_friends)
            Inbox.sync(this, api)
        }
        val invId = i?.getStringExtra(EXTRA_INVITE_ID)
        if (!invId.isNullOrEmpty()) {
            i.removeExtra(EXTRA_INVITE_ID)
            // Invitación recibida por push: se pide al servidor su contenido (de un solo uso)
            api.call(this, "GET", "/api/invite/$invId") { r ->
                val j = r.json
                if (r.ok && j != null) {
                    showInvite(j.optString("name"), j.optString("channel"), j.optString("pass"))
                } else {
                    toast(getString(R.string.invite_expired))
                }
            }
            return
        }
        val ch = i?.getStringExtra(EXTRA_INVITE_CHANNEL) ?: return
        val pass = i.getStringExtra(EXTRA_INVITE_PASS) ?: ""
        val from = i.getStringExtra(EXTRA_INVITE_FROM) ?: ""
        i.removeExtra(EXTRA_INVITE_CHANNEL)
        i.removeExtra(EXTRA_INVITE_PASS)
        i.removeExtra(EXTRA_INVITE_FROM)
        showInvite(from, ch, pass)
    }

    // ------------------------------------------------------ Mensajes de voz

    /** Mantener pulsado el micrófono de un amigo graba; al soltar se envía. */
    private fun askNotifications() {
        Push.register(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED &&
            !prefs.getBoolean("askedNotif", false)
        ) {
            prefs.edit().putBoolean("askedNotif", true).apply()
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // ------------------------------------------------------ Recientes y favoritos

    private fun setupRecents() = renderRecents()

    /** Cuántas personas hay dentro de cada canal (null = aún no se sabe). */
    private var channelCounts = mapOf<String, Int>()
    private val statusHandler = Handler(Looper.getMainLooper())
    private val statusTick = object : Runnable {
        override fun run() {
            refreshChannelStatus()
            statusHandler.postDelayed(this, 15_000)
        }
    }

    private fun refreshChannelStatus() {
        if (!Store.hasAccount(this)) return
        val names = Store.loadChannels(this).map { it.name }
        if (names.isEmpty()) return
        val arr = JSONArray()
        names.forEach { arr.put(it) }
        api.call(this, "POST", "/api/channels/status", JSONObject().put("names", arr)) { r ->
            val o = r.json?.optJSONObject("counts")
            if (r.ok && o != null) {
                channelCounts = names.associateWith { o.optInt(it, 0) }
                renderRecents()
            }
        }
    }

    private fun renderRecents() {
        val all = Store.loadChannels(this)
        recentsRow.removeAllViews()
        recentsBox.visibility = if (all.isEmpty()) View.GONE else View.VISIBLE
        val d = resources.displayMetrics.density
        fun header(text: String) {
            val tv = TextView(this)
            tv.text = text
            tv.setTextColor(ContextCompat.getColor(this, R.color.muted))
            tv.textSize = 12f
            tv.setTypeface(null, android.graphics.Typeface.BOLD)
            tv.setPadding(0, (6 * d).toInt(), 0, (6 * d).toInt())
            recentsRow.addView(tv)
        }
        fun rows(list: List<Store.Chan>) {
            for (c in list) {
                val v = layoutInflater.inflate(R.layout.item_channel, recentsRow, false)
                v.findViewById<TextView>(R.id.cName).text = "# " + c.name
                val n = channelCounts[c.name]
                val tags = mutableListOf<String>()
                if (c.created) tags += getString(R.string.tag_created)
                if (c.invited) tags += getString(R.string.tag_invited)
                val state = when {
                    n == null -> ""
                    n > 0 -> "● " + getString(R.string.channel_active_n, n)
                    else -> "● " + getString(R.string.channel_inactive)
                }
                val sub = (listOf(state) + tags).filter { it.isNotEmpty() }.joinToString("  ·  ")
                val sp = android.text.SpannableString(sub)
                if (state.isNotEmpty()) {
                    sp.setSpan(
                        android.text.style.ForegroundColorSpan(
                            if ((n ?: 0) > 0) android.graphics.Color.parseColor("#22C55E")
                            else ContextCompat.getColor(this, R.color.muted)
                        ), 0, 1, 0
                    )
                }
                v.findViewById<TextView>(R.id.cSub).text = sp
                v.findViewById<TextView>(R.id.cFav).apply {
                    text = if (c.fav) "★" else "☆"
                    setOnClickListener {
                        Store.toggleFavorite(this@MainActivity, c.name)
                        renderRecents()
                    }
                }
                val busy = (service?.state ?: PttService.DISCONNECTED) != PttService.DISCONNECTED
                v.findViewById<View>(R.id.cJoin).apply {
                    alpha = if (busy) 0.5f else 1f
                    setOnClickListener { joinFromList(c.name) }
                }
                v.findViewById<View>(R.id.cDelete).setOnClickListener { confirmDeleteChannel(c) }
                recentsRow.addView(v)
            }
        }
        val favs = all.filter { it.fav }
        val others = all.filter { !it.fav }
        if (favs.isNotEmpty()) {
            header(getString(R.string.lbl_favorites))
            rows(favs)
        }
        if (others.isNotEmpty()) {
            header(getString(R.string.lbl_recents_only))
            rows(others)
        }
    }

    /** "Unirme a canal" desde la lista: pide la clave (opcional) y entra. */
    private fun joinFromList(name: String) {
        val s = service
        if (s == null || s.state != PttService.DISCONNECTED) {
            toast(getString(R.string.leave_first))
            return
        }
        val pass = EditText(this)
        pass.hint = getString(R.string.hint_channel_pass_optional)
        pass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        pass.setSingleLine()
        val d = resources.displayMetrics.density
        val box = FrameLayout(this)
        box.setPadding((22 * d).toInt(), (8 * d).toInt(), (22 * d).toInt(), 0)
        box.addView(pass)
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.join_title, name))
            .setView(box)
            .setPositiveButton(R.string.btn_join_channel) { _, _ ->
                inputChannel.setText(name)
                inputPass.setText(pass.text.toString())
                onConnectClicked("join")
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirmDeleteChannel(c: Store.Chan) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.delete_channel_title, c.name))
            .setMessage(R.string.delete_channel_msg)
            .setPositiveButton(R.string.btn_delete_channel) { _, _ ->
                Store.removeChannel(this, c.name)
                renderRecents()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
