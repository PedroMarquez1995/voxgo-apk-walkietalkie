package app.walkie.ptt

import android.Manifest
import android.annotation.SuppressLint
import android.appwidget.AppWidgetManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.button.MaterialButtonToggleGroup
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.textfield.TextInputEditText
import okhttp3.OkHttpClient

class MainActivity : AppCompatActivity(), PttService.Listener {

    companion object {
        const val EXTRA_INVITE_CHANNEL = "invite_channel"
        const val EXTRA_INVITE_PASS = "invite_pass"
        const val EXTRA_INVITE_FROM = "invite_from"
    }

    private var service: PttService? = null
    private var pendingMode: String? = null
    private var welcomeDone = false

    // Bienvenida
    private lateinit var welcome: View
    private lateinit var welcomeRipple: RippleView
    private lateinit var welcomeLogo: View
    private lateinit var welcomeTitle: View
    private lateinit var welcomeTagline: View
    private lateinit var btnWelcome: Button

    // Cabecera
    private lateinit var statusDot: View
    private lateinit var statusView: TextView

    // Panel para crear / unirse
    private lateinit var panelConnect: View
    private lateinit var inputName: TextInputEditText
    private lateinit var inputChannel: TextInputEditText
    private lateinit var inputPass: TextInputEditText
    private lateinit var inputServer: TextInputEditText
    private lateinit var inputKey: TextInputEditText
    private lateinit var chkVolume: MaterialSwitch
    private lateinit var btnJoin: View
    private lateinit var btnCreate: View
    private lateinit var connectMsg: TextView

    // Panel del canal
    private lateinit var panelChannel: View
    private lateinit var channelTitle: TextView
    private lateinit var channelCount: TextView
    private lateinit var banner: View
    private lateinit var bannerBars: BarsView
    private lateinit var bannerText: TextView
    private lateinit var list: RecyclerView
    private val adapter = ParticipantAdapter()

    // Botón de hablar
    private lateinit var pttArea: View
    private lateinit var ripple: RippleView
    private lateinit var btnPtt: View
    private lateinit var pttLabel: TextView
    private lateinit var btnDisconnect: View

    // Pestañas
    private lateinit var tabChannels: View
    private lateinit var tabFriends: View
    private lateinit var tabProfile: View
    private lateinit var tabSettings: View
    private lateinit var bottomNav: BottomNavigationView

    // Amigos
    private lateinit var myCode: TextView
    private lateinit var inputFriendCode: TextInputEditText
    private lateinit var friendsEmpty: TextView
    private lateinit var friendsConn: TextView
    private lateinit var friendsList: RecyclerView
    private lateinit var friendsAdapter: FriendsAdapter
    private var friends = mutableListOf<Store.Friend>()
    private var friendStatus: Map<String, PresenceClient.FriendStatus> = emptyMap()
    private var presence: PresenceClient? = null
    private val presenceClient = OkHttpClient()

    // Perfil
    private lateinit var profileWalkie: WalkieView
    private lateinit var profileSkinName: TextView
    private lateinit var inputProfileName: TextInputEditText
    private lateinit var skinsRow: LinearLayout
    private var mySkin = 0

    private val prefs by lazy { Store.prefs(this) }

    private val cGreen by lazy { ContextCompat.getColor(this, R.color.green) }
    private val cAmber by lazy { ContextCompat.getColor(this, R.color.amber) }
    private val cGray = Color.parseColor("#6B6280")
    private val cPink by lazy { ContextCompat.getColor(this, R.color.pink) }
    private val cLavender by lazy { ContextCompat.getColor(this, R.color.lavender) }
    private var currentTab = R.id.nav_channels
    private var lastCanInvite = false
    private lateinit var recentsBox: View
    private lateinit var recentsRow: LinearLayout
    private lateinit var batteryStatus: TextView
    private lateinit var chkHd: MaterialSwitch
    private lateinit var chkBeep: MaterialSwitch
    private var inviteDialog: AlertDialog? = null

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = (binder as PttService.LocalBinder).service
            service?.listener = this@MainActivity
            // Si ya estabas dentro de un canal, no hace falta pasar otra vez por la bienvenida
            if (service?.state != PttService.DISCONNECTED) dismissWelcome(false)
            render()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            render()
        }
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val mode = pendingMode
            pendingMode = null
            if (mode != null) {
                if (hasMic()) {
                    doConnect(mode)
                } else {
                    toast(getString(R.string.mic_needed))
                }
            }
        }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        AppCompatDelegate.setDefaultNightMode(Store.nightMode(this))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        welcome = findViewById(R.id.welcome)
        welcomeRipple = findViewById(R.id.welcomeRipple)
        welcomeLogo = findViewById(R.id.welcomeLogo)
        welcomeTitle = findViewById(R.id.welcomeTitle)
        welcomeTagline = findViewById(R.id.welcomeTagline)
        btnWelcome = findViewById(R.id.btnWelcome)

        statusDot = findViewById(R.id.statusDot)
        statusView = findViewById(R.id.status)

        panelConnect = findViewById(R.id.panelConnect)
        inputName = findViewById(R.id.inputName)
        inputChannel = findViewById(R.id.inputChannel)
        inputPass = findViewById(R.id.inputPass)
        inputServer = findViewById(R.id.inputServer)
        inputKey = findViewById(R.id.inputKey)
        chkVolume = findViewById(R.id.chkVolume)
        btnJoin = findViewById(R.id.btnJoin)
        btnCreate = findViewById(R.id.btnCreate)
        connectMsg = findViewById(R.id.connectMsg)

        panelChannel = findViewById(R.id.panelChannel)
        channelTitle = findViewById(R.id.channelTitle)
        channelCount = findViewById(R.id.channelCount)
        banner = findViewById(R.id.banner)
        bannerBars = findViewById(R.id.bannerBars)
        bannerText = findViewById(R.id.bannerText)
        list = findViewById(R.id.list)

        pttArea = findViewById(R.id.pttArea)
        ripple = findViewById(R.id.ripple)
        btnPtt = findViewById(R.id.btnPtt)
        pttLabel = findViewById(R.id.pttLabel)
        btnDisconnect = findViewById(R.id.btnDisconnect)

        tabChannels = findViewById(R.id.tabChannels)
        tabFriends = findViewById(R.id.tabFriends)
        tabProfile = findViewById(R.id.tabProfile)
        tabSettings = findViewById(R.id.tabSettings)
        bottomNav = findViewById(R.id.bottomNav)
        recentsBox = findViewById(R.id.recentsBox)
        recentsRow = findViewById(R.id.recentsRow)
        batteryStatus = findViewById(R.id.batteryStatus)
        chkHd = findViewById(R.id.chkHd)
        chkBeep = findViewById(R.id.chkBeep)

        myCode = findViewById(R.id.myCode)
        inputFriendCode = findViewById(R.id.inputFriendCode)
        friendsEmpty = findViewById(R.id.friendsEmpty)
        friendsConn = findViewById(R.id.friendsConn)
        friendsList = findViewById(R.id.friendsList)

        profileWalkie = findViewById(R.id.profileWalkie)
        profileSkinName = findViewById(R.id.profileSkinName)
        inputProfileName = findViewById(R.id.inputProfileName)
        skinsRow = findViewById(R.id.skinsRow)

        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        ripple.baseRadiusDp = 75f
        welcomeRipple.baseRadiusDp = 62f

        // Valores guardados (el canal y la clave del canal no se recuerdan a propósito)
        inputServer.setText(prefs.getString("server", BuildConfig.DEFAULT_SERVER))
        inputName.setText(Store.name(this))
        inputProfileName.setText(Store.name(this))
        mySkin = Store.skin(this)
        inputChannel.setText(prefs.getString("channel", ""))
        inputKey.setText(prefs.getString("key", BuildConfig.DEFAULT_KEY))
        chkVolume.isChecked = prefs.getBoolean("volPtt", false)

        setupTabs()
        val savedTab = savedInstanceState?.getInt("tab", R.id.nav_channels) ?: R.id.nav_channels
        if (savedTab != R.id.nav_channels) {
            tabChannels.visibility = View.GONE
            tabView(savedTab).visibility = View.VISIBLE
            currentTab = savedTab
            bottomNav.selectedItemId = savedTab
        }
        setupFriends()
        setupProfile()
        setupSettings()
        setupRecents()
        handleInviteIntent(intent)
        btnJoin.setOnClickListener { onConnectClicked("join") }
        btnCreate.setOnClickListener { onConnectClicked("create") }
        btnDisconnect.setOnClickListener { service?.disconnect() }
        btnWelcome.setOnClickListener { dismissWelcome(true) }

        btnPtt.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                    service?.startTalking()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    service?.stopTalking()
                }
            }
            true
        }

        welcomeDone = savedInstanceState?.getBoolean("welcomeDone") == true
        if (welcomeDone) {
            welcome.visibility = View.GONE
        } else {
            playWelcome()
        }
        render()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleInviteIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        renderBattery()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("welcomeDone", welcomeDone)
        outState.putInt("tab", currentTab)
    }

    override fun onStart() {
        super.onStart()
        bindService(Intent(this, PttService::class.java), conn, Context.BIND_AUTO_CREATE)
        startPresence()
    }

    override fun onStop() {
        presence?.stop()
        presence = null
        service?.listener = null
        try {
            unbindService(conn)
        } catch (e: IllegalArgumentException) {
        }
        service = null
        super.onStop()
    }

    override fun onChanged() = render()

    // ------------------------------------------------------------ Bienvenida

    private fun playWelcome() {
        welcomeRipple.start()
        val d = resources.displayMetrics.density
        listOf(welcomeLogo, welcomeTitle, welcomeTagline, btnWelcome).forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = 28f * d
            v.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(150L + i * 140L)
                .setDuration(600)
                .start()
        }
        welcomeLogo.scaleX = 0.75f
        welcomeLogo.scaleY = 0.75f
        welcomeLogo.animate().scaleX(1f).scaleY(1f).setStartDelay(150).setDuration(700).start()
    }

    private fun dismissWelcome(animated: Boolean) {
        if (welcomeDone) return
        welcomeDone = true
        if (animated) {
            welcome.animate().alpha(0f).setDuration(350).withEndAction {
                welcome.visibility = View.GONE
                welcomeRipple.stop()
            }.start()
        } else {
            welcome.visibility = View.GONE
            welcomeRipple.stop()
        }
    }

    // ---------------------------------------------------------------- Teclas

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (welcomeDone && chkVolume.isChecked && keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event?.repeatCount == 0) service?.startTalking()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (welcomeDone && chkVolume.isChecked && keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            service?.stopTalking()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    // ------------------------------------------------------------ Conexión

    private fun onConnectClicked(mode: String) {
        val s = service
        if (s == null) {
            toast(getString(R.string.service_not_ready))
            return
        }
        if (s.state != PttService.DISCONNECTED) return
        if (inputChannel.text.isNullOrBlank()) {
            inputChannel.error = getString(R.string.enter_channel)
            return
        }
        if (inputServer.text.isNullOrBlank()) {
            showTab(R.id.nav_settings)
            inputServer.error = getString(R.string.enter_server)
            return
        }
        val perms = mutableListOf<String>()
        if (!hasMic()) perms += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            perms += Manifest.permission.POST_NOTIFICATIONS
        }
        if (perms.isNotEmpty()) {
            pendingMode = mode
            permLauncher.launch(perms.toTypedArray())
        } else {
            doConnect(mode)
        }
    }

    private fun doConnect(mode: String) {
        val url = Store.normalizeUrl(inputServer.text.toString())
        val channel = inputChannel.text.toString().trim()
        val name = inputName.text.toString().trim().ifEmpty { Build.MODEL }
        inputProfileName.setText(name)
        val key = inputKey.text.toString()
        val pass = inputPass.text.toString()

        prefs.edit()
            .putString("server", inputServer.text.toString().trim())
            .putString("name", name)
            .putString("channel", channel)
            .putString("key", key)
            .putBoolean("volPtt", chkVolume.isChecked)
            .apply()

        Store.touchChannel(this, channel)
        renderRecents()
        ContextCompat.startForegroundService(this, Intent(this, PttService::class.java))
        service?.connect(url, channel, name, key, mode, pass, mySkin)
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    // ------------------------------------------------------------------ UI

    private fun render() {
        val s = service
        val st = s?.state ?: PttService.DISCONNECTED
        val disconnected = st == PttService.DISCONNECTED
        val connected = st == PttService.CONNECTED
        val tx = s?.transmitting == true
        val talker = s?.talker
        val users = s?.users ?: emptyList()

        if (connected != lastCanInvite) {
            lastCanInvite = connected
            if (::friendsAdapter.isInitialized) renderFriends()
        }

        // Chip de estado
        statusView.text = if (disconnected) getString(R.string.disconnected) else (s?.statusText ?: "")
        val dot = when (st) {
            PttService.CONNECTED -> cGreen
            PttService.CONNECTING -> cAmber
            else -> cGray
        }
        statusDot.backgroundTintList = ColorStateList.valueOf(dot)

        // Qué panel se ve
        panelConnect.visibility = if (disconnected) View.VISIBLE else View.GONE
        panelChannel.visibility = if (disconnected) View.GONE else View.VISIBLE
        pttArea.visibility = if (disconnected) View.GONE else View.VISIBLE
        btnDisconnect.visibility = if (disconnected) View.GONE else View.VISIBLE

        if (disconnected) {
            // Mensaje de error / motivo de la desconexión (p. ej. "Ese canal no existe")
            val msg = s?.statusText.orEmpty()
            if (msg.isEmpty() || msg == getString(R.string.disconnected)) {
                connectMsg.visibility = View.GONE
            } else {
                connectMsg.text = msg
                connectMsg.visibility = View.VISIBLE
            }
            ripple.stop()
            bannerBars.stop()
            return
        }
        connectMsg.visibility = View.GONE

        // Canal
        val ch = s?.channelName.orEmpty()
        channelTitle.text = if (ch.isEmpty()) getString(R.string.connecting) else "#$ch"
        channelCount.text = resources.getQuantityString(R.plurals.connected_count, users.size, users.size)

        // Quién está hablando
        when {
            tx -> {
                bannerText.text = getString(R.string.you_transmitting)
                banner.setBackgroundResource(R.drawable.bg_banner_tx)
                bannerBars.setColor(cPink)
                bannerBars.visibility = View.VISIBLE
                bannerBars.start()
            }
            talker != null -> {
                bannerText.text = getString(R.string.someone_talking, talker)
                banner.setBackgroundResource(R.drawable.bg_banner_talk)
                bannerBars.setColor(cLavender)
                bannerBars.visibility = View.VISIBLE
                bannerBars.start()
            }
            else -> {
                bannerText.text = if (connected) getString(R.string.channel_free) else getString(R.string.connecting)
                banner.setBackgroundResource(R.drawable.bg_banner_idle)
                bannerBars.stop()
                bannerBars.visibility = View.GONE
            }
        }

        adapter.submit(users, s?.myName.orEmpty(), talker, tx, s?.skins ?: emptyMap(), mySkin)
        if (connected) maybeAskBattery()

        // Botón de hablar
        val busy = !tx && talker != null
        btnPtt.setBackgroundResource(
            when {
                tx -> R.drawable.bg_ptt_tx
                connected -> R.drawable.bg_ptt_idle
                else -> R.drawable.bg_ptt_off
            }
        )
        btnPtt.alpha = if (busy) 0.55f else 1f
        pttLabel.text = when {
            tx -> getString(R.string.ptt_tx)
            !connected -> getString(R.string.ptt_connecting)
            busy -> getString(R.string.ptt_busy)
            else -> getString(R.string.ptt_hold)
        }
        if (tx) {
            ripple.setColor(cPink)
            ripple.start()
        } else {
            ripple.stop()
        }
    }

    // ------------------------------------------------------------- Pestañas

    private fun setupTabs() {
        bottomNav.setOnItemSelectedListener { item ->
            showTab(item.itemId, fromNav = true)
            true
        }
    }

    private fun tabView(id: Int): View = when (id) {
        R.id.nav_friends -> tabFriends
        R.id.nav_profile -> tabProfile
        R.id.nav_settings -> tabSettings
        else -> tabChannels
    }

    private fun tabIndex(id: Int) = when (id) {
        R.id.nav_friends -> 1
        R.id.nav_profile -> 2
        R.id.nav_settings -> 3
        else -> 0
    }

    private fun showTab(id: Int, fromNav: Boolean = false) {
        if (id != currentTab) {
            val dir = if (tabIndex(id) > tabIndex(currentTab)) 1f else -1f
            val d = resources.displayMetrics.density
            tabView(currentTab).visibility = View.GONE
            val next = tabView(id)
            next.visibility = View.VISIBLE
            next.alpha = 0f
            next.translationX = 28f * d * dir
            next.animate().alpha(1f).translationX(0f).setDuration(220).start()
            currentTab = id
            if (id == R.id.nav_settings) renderBattery()
        }
        if (!fromNav) bottomNav.selectedItemId = id
    }

    // --------------------------------------------------------------- Amigos

    private fun setupFriends() {
        friends = Store.loadFriends(this)
        myCode.text = Store.prettyCode(Store.friendCode(this))
        friendsAdapter = FriendsAdapter({ f ->
            friends.removeAll { it.code == f.code }
            Store.saveFriends(this, friends)
            presence?.update(Store.name(this), mySkin, friends.map { it.code })
            renderFriends()
        }, { f -> inviteFriend(f) })
        friendsList.layoutManager = LinearLayoutManager(this)
        friendsList.adapter = friendsAdapter

        findViewById<View>(R.id.btnCopyCode).setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText(getString(R.string.app_name), Store.friendCode(this)))
            toast(getString(R.string.code_copied))
        }
        findViewById<View>(R.id.btnShareCode).setOnClickListener {
            val text = getString(R.string.share_text, Store.prettyCode(Store.friendCode(this)))
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text),
                    getString(R.string.share_code)
                )
            )
        }
        findViewById<View>(R.id.btnAddFriend).setOnClickListener { addFriend() }
        renderFriends()
    }

    private fun addFriend() {
        val code = Store.cleanCode(inputFriendCode.text.toString())
        when {
            code.length < 4 -> inputFriendCode.error = getString(R.string.code_invalid)
            code == Store.friendCode(this) -> inputFriendCode.error = getString(R.string.code_own)
            friends.any { it.code == code } -> inputFriendCode.error = getString(R.string.code_dup)
            else -> {
                friends.add(Store.Friend(code, "", 0))
                Store.saveFriends(this, friends)
                inputFriendCode.setText("")
                presence?.update(Store.name(this), mySkin, friends.map { it.code })
                renderFriends()
                toast(getString(R.string.friend_added))
            }
        }
    }

    private fun renderFriends() {
        friendsEmpty.visibility = if (friends.isEmpty()) View.VISIBLE else View.GONE
        friendsAdapter.submit(friends.toList(), friendStatus, service?.state == PttService.CONNECTED)
    }

    private fun startPresence() {
        val url = Store.normalizeUrl(prefs.getString("server", BuildConfig.DEFAULT_SERVER) ?: "")
        if (url.isEmpty()) return
        presence?.stop()
        presence = PresenceClient(presenceClient, android.os.Handler(mainLooper)).also { pc ->
            pc.listener = object : PresenceClient.Listener {
                override fun onStatus(list: List<PresenceClient.FriendStatus>) {
                    friendStatus = list.associateBy { it.code }
                    var changed = false
                    for (f in friends) {
                        val st = friendStatus[f.code] ?: continue
                        if (st.online && !st.name.isNullOrBlank() && (st.name != f.name || st.skin != f.skin)) {
                            f.name = st.name
                            f.skin = st.skin
                            changed = true
                        }
                    }
                    if (changed) Store.saveFriends(this@MainActivity, friends)
                    renderFriends()
                }

                override fun onInvite(fromCode: String, fromName: String, skin: Int, channel: String, pass: String) {
                    showInvite(fromName, channel, pass)
                }

                override fun onInviteResult(toCode: String, delivered: Boolean) {
                    toast(getString(if (delivered) R.string.invite_sent else R.string.invite_failed))
                }

                override fun onConnection(connected: Boolean) {
                    friendsConn.visibility = if (connected) View.GONE else View.VISIBLE
                    friendsConn.text = getString(R.string.friends_offline)
                }
            }
            pc.start(
                url, prefs.getString("key", BuildConfig.DEFAULT_KEY) ?: "",
                Store.friendCode(this), Store.name(this), mySkin,
                service?.state == PttService.CONNECTED, friends.map { it.code }
            )
        }
    }

    // --------------------------------------------------------------- Perfil

    private fun setupProfile() {
        val d = resources.displayMetrics.density
        for (i in Skins.all.indices) {
            val cell = FrameLayout(this)
            val lp = LinearLayout.LayoutParams((72 * d).toInt(), (100 * d).toInt())
            lp.marginEnd = (10 * d).toInt()
            cell.layoutParams = lp
            cell.tag = i
            val w = WalkieView(this)
            w.setSkin(i)
            val wlp = FrameLayout.LayoutParams((40 * d).toInt(), (56 * d).toInt())
            wlp.gravity = android.view.Gravity.CENTER
            cell.addView(w, wlp)
            cell.setOnClickListener { selectSkin(i) }
            skinsRow.addView(cell)
        }
        findViewById<View>(R.id.btnSaveName).setOnClickListener {
            val n = inputProfileName.text.toString().trim()
            if (n.isEmpty()) {
                inputProfileName.error = getString(R.string.enter_name)
                return@setOnClickListener
            }
            prefs.edit().putString("name", n).apply()
            inputName.setText(n)
            presence?.update(n, mySkin, friends.map { it.code })
            toast(getString(R.string.name_saved))
        }
        selectSkin(mySkin, save = false)
    }

    private fun selectSkin(i: Int, save: Boolean = true) {
        mySkin = i
        if (save) {
            prefs.edit().putInt("skin", i).apply()
            presence?.update(Store.name(this), i, friends.map { it.code })
        }
        profileWalkie.setSkin(i)
        profileSkinName.text = resources.getStringArray(R.array.skin_names).getOrElse(i) { "" }
        for (k in 0 until skinsRow.childCount) {
            skinsRow.getChildAt(k).setBackgroundResource(
                if (k == i) R.drawable.bg_skin_selected else R.drawable.bg_skin_normal
            )
        }
        if (save && service?.state == PttService.DISCONNECTED) render()
    }

    // -------------------------------------------------------------- Ajustes

    private fun setupSettings() {
        chkVolume.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("volPtt", on).apply() }
        chkBeep.isChecked = prefs.getBoolean("beep", true)
        chkBeep.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("beep", on).apply() }
        chkHd.isChecked = prefs.getBoolean("hd", false)
        chkHd.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("hd", on).apply()
            if (on && !OpusCodec.encoderAvailable()) toast(getString(R.string.hd_unavailable))
        }
        val themeGroup = findViewById<MaterialButtonToggleGroup>(R.id.themeGroup)
        themeGroup.check(
            when (Store.themeMode(this)) {
                1 -> R.id.themeLight
                2 -> R.id.themeDark
                else -> R.id.themeSystem
            }
        )
        themeGroup.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val mode = when (id) {
                R.id.themeLight -> 1
                R.id.themeDark -> 2
                else -> 0
            }
            if (mode != Store.themeMode(this)) {
                prefs.edit().putInt("theme", mode).apply()
                AppCompatDelegate.setDefaultNightMode(Store.nightMode(this))
            }
        }
        findViewById<View>(R.id.btnBattery).setOnClickListener { openBatterySettings() }
        findViewById<View>(R.id.btnBrandGuide).setOnClickListener {
            val brand = Build.MANUFACTURER.lowercase().trim().replace(" ", "-")
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://dontkillmyapp.com/$brand")))
            } catch (e: Exception) {
                toast(getString(R.string.no_browser))
            }
        }
        renderBattery()
        findViewById<View>(R.id.btnSaveServer).setOnClickListener {
            prefs.edit()
                .putString("server", inputServer.text.toString().trim())
                .putString("key", inputKey.text.toString())
                .apply()
            startPresence()
            toast(getString(R.string.server_saved))
        }
        findViewById<View>(R.id.btnAddWidget).setOnClickListener {
            val mgr = AppWidgetManager.getInstance(this)
            if (mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(ComponentName(this, PttWidgetProvider::class.java), null, null)
            } else {
                toast(getString(R.string.widget_manual))
            }
        }
        val ver = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            ""
        }
        findViewById<TextView>(R.id.aboutText).text = getString(R.string.about, ver)
    }

    // ------------------------------------------------------ Batería / segundo plano

    private fun ignoringBattery(): Boolean = try {
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
    } catch (e: Exception) {
        true
    }

    private fun renderBattery() {
        val ok = ignoringBattery()
        batteryStatus.text = getString(if (ok) R.string.battery_ok else R.string.battery_restricted)
        batteryStatus.setTextColor(if (ok) cGreen else cAmber)
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            } catch (e2: Exception) {
                toast(getString(R.string.no_browser))
            }
        }
    }

    /** La primera vez que te conectas, si la batería puede cerrar Wavko, te lo avisamos. */
    private fun maybeAskBattery() {
        if (prefs.getBoolean("batteryAsked", false) || ignoringBattery()) return
        prefs.edit().putBoolean("batteryAsked", true).apply()
        AlertDialog.Builder(this)
            .setTitle(R.string.battery_dialog_title)
            .setMessage(R.string.battery_dialog_text)
            .setPositiveButton(R.string.battery_fix) { _, _ -> openBatterySettings() }
            .setNegativeButton(R.string.later, null)
            .show()
    }

    // ------------------------------------------------------ Invitaciones

    private fun inviteFriend(f: Store.Friend) {
        val s = service ?: return
        if (s.state != PttService.CONNECTED || s.channelName.isEmpty()) return
        val sent = presence?.sendInvite(f.code, s.channelName, s.channelPass) ?: false
        if (!sent) toast(getString(R.string.invite_failed))
    }

    private fun showInvite(from: String, channel: String, pass: String) {
        inviteDialog?.dismiss()
        val who = from.ifBlank { getString(R.string.a_friend) }
        inviteDialog = AlertDialog.Builder(this)
            .setTitle(getString(R.string.invite_title, who))
            .setMessage(getString(R.string.invite_text, channel))
            .setPositiveButton(R.string.join) { _, _ -> acceptInvite(channel, pass) }
            .setNegativeButton(R.string.ignore, null)
            .show()
    }

    private fun acceptInvite(channel: String, pass: String) {
        showTab(R.id.nav_channels)
        if (service?.state != PttService.DISCONNECTED) {
            toast(getString(R.string.leave_first))
            return
        }
        inputChannel.setText(channel)
        inputPass.setText(pass)
        onConnectClicked("join")
    }

    private fun handleInviteIntent(i: Intent?) {
        val ch = i?.getStringExtra(EXTRA_INVITE_CHANNEL) ?: return
        val pass = i.getStringExtra(EXTRA_INVITE_PASS) ?: ""
        val from = i.getStringExtra(EXTRA_INVITE_FROM) ?: ""
        i.removeExtra(EXTRA_INVITE_CHANNEL)
        i.removeExtra(EXTRA_INVITE_PASS)
        i.removeExtra(EXTRA_INVITE_FROM)
        showInvite(from, ch, pass)
    }

    // ------------------------------------------------------ Recientes y favoritos

    private fun setupRecents() = renderRecents()

    private fun renderRecents() {
        val list = Store.loadChannels(this).sortedByDescending { it.fav }
        recentsRow.removeAllViews()
        recentsBox.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        val d = resources.displayMetrics.density
        for (c in list) {
            val tv = TextView(this)
            tv.text = if (c.fav) "★ ${c.name}" else c.name
            tv.setTextColor(ContextCompat.getColor(this, R.color.text))
            tv.textSize = 14f
            tv.setBackgroundResource(R.drawable.bg_chip)
            tv.setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = (8 * d).toInt()
            tv.layoutParams = lp
            tv.setOnClickListener { inputChannel.setText(c.name) }
            tv.setOnLongClickListener {
                Store.toggleFavorite(this, c.name)
                renderRecents()
                true
            }
            recentsRow.addView(tv)
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
