package app.walkie.ptt

import android.Manifest
import android.annotation.SuppressLint
import android.appwidget.AppWidgetManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.button.MaterialButtonToggleGroup
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import org.json.JSONArray
import org.json.JSONObject
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.textfield.TextInputEditText
import okhttp3.OkHttpClient

class MainActivity : AppCompatActivity(), PttService.Listener {

    companion object {
        const val EXTRA_INVITE_CHANNEL = "invite_channel"
        const val EXTRA_INVITE_PASS = "invite_pass"
        const val EXTRA_INVITE_FROM = "invite_from"
        const val EXTRA_INVITE_ID = "invite_id"
        const val EXTRA_OPEN_VOICE = "open_voice"
    }

    private var service: PttService? = null
    private var pendingMode: String? = null
    private var welcomeDone = false

    // Bienvenida
    private lateinit var welcome: View
    private lateinit var welcomeRipple: RippleView
    private lateinit var welcomeLogo: View
    private lateinit var welcomeTitle: View
    private lateinit var welcomeTagline: View
    private lateinit var btnWelcome: Button

    // Cabecera
    private lateinit var statusDot: View
    private lateinit var statusView: TextView

    // Panel para crear / unirse
    private lateinit var panelConnect: View
    private lateinit var inputName: TextInputEditText
    private lateinit var inputChannel: TextInputEditText
    private lateinit var inputPass: TextInputEditText
    private lateinit var inputServer: TextInputEditText
    private lateinit var inputKey: TextInputEditText
    private lateinit var chkVolume: MaterialSwitch
    private lateinit var btnJoin: View
    private lateinit var btnCreate: View
    private lateinit var connectMsg: TextView

    // Panel del canal
    private lateinit var panelChannel: View
    private lateinit var channelTitle: TextView
    private lateinit var channelCount: TextView
    private lateinit var banner: View
    private lateinit var bannerBars: BarsView
    private lateinit var bannerText: TextView
    private lateinit var list: RecyclerView
    private val adapter = ParticipantAdapter { name -> onParticipantClick(name) }

    // Botón de hablar
    private lateinit var pttArea: View
    private lateinit var ripple: RippleView
    private lateinit var btnPtt: View
    private lateinit var pttLabel: TextView
    private lateinit var btnDisconnect: View

    // Pestañas
    private lateinit var tabChannels: View
    private lateinit var tabFriends: View
    private lateinit var tabProfile: View
    private lateinit var tabSettings: View
    private lateinit var bottomNav: BottomNavigationView

    // Amigos
    private lateinit var myCode: TextView
    private lateinit var inputFriendCode: TextInputEditText
    private lateinit var friendsEmpty: TextView
    private lateinit var friendsConn: TextView
    private lateinit var friendsList: RecyclerView
    private lateinit var friendsAdapter: FriendsAdapter
    private var friends = mutableListOf<Store.Friend>()
    private var friendStatus: Map<String, PresenceClient.FriendStatus> = emptyMap()
    private var presence: PresenceClient? = null
    private val presenceClient = OkHttpClient()

    // Perfil
    private lateinit var profileWalkie: WalkieView
    private lateinit var profileSkinName: TextView
    private lateinit var inputProfileName: TextInputEditText
    private lateinit var skinsRow: LinearLayout
    private var mySkin = 0

    private val prefs by lazy { Store.prefs(this) }

    private val cGreen by lazy { ContextCompat.getColor(this, R.color.green) }
    private val cAmber by lazy { ContextCompat.getColor(this, R.color.amber) }
    private val cGray = Color.parseColor("#6B6280")
    private val cPink by lazy { ContextCompat.getColor(this, R.color.pink) }
    private val cLavender by lazy { ContextCompat.getColor(this, R.color.lavender) }
    private var currentTab = R.id.nav_channels
    private var lastCanInvite = false
    private lateinit var recentsBox: View
    private lateinit var recentsRow: LinearLayout
    private lateinit var batteryStatus: TextView
    private lateinit var chkHd: MaterialSwitch
    private lateinit var chkBeep: MaterialSwitch
    private var inviteDialog: AlertDialog? = null

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = (binder as PttService.LocalBinder).service
            service?.listener = this@MainActivity
            // Si ya estabas dentro de un canal, no hace falta pasar otra vez por la bienvenida
            if (service?.state != PttService.DISCONNECTED) dismissWelcome(false)
            render()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            render()
        }
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val mode = pendingMode
            pendingMode = null
            if (mode != null) {
                if (hasMic()) {
                    doConnect(mode)
                } else {
                    toast(getString(R.string.mic_needed))
                }
            }
        }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        AppCompatDelegate.setDefaultNightMode(Store.nightMode(this))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        welcome = findViewById(R.id.welcome)
        welcomeRipple = findViewById(R.id.welcomeRipple)
        welcomeLogo = findViewById(R.id.welcomeLogo)
        welcomeTitle = findViewById(R.id.welcomeTitle)
        welcomeTagline = findViewById(R.id.welcomeTagline)
        btnWelcome = findViewById(R.id.btnWelcome)

        statusDot = findViewById(R.id.statusDot)
        statusView = findViewById(R.id.status)

        panelConnect = findViewById(R.id.panelConnect)
        inputName = findViewById(R.id.inputName)
        inputChannel = findViewById(R.id.inputChannel)
        inputPass = findViewById(R.id.inputPass)
        inputServer = findViewById(R.id.inputServer)
        inputKey = findViewById(R.id.inputKey)
        chkVolume = findViewById(R.id.chkVolume)
        btnJoin = findViewById(R.id.btnJoin)
        btnCreate = findViewById(R.id.btnCreate)
        connectMsg = findViewById(R.id.connectMsg)

        panelChannel = findViewById(R.id.panelChannel)
        channelTitle = findViewById(R.id.channelTitle)
        channelCount = findViewById(R.id.channelCount)
        banner = findViewById(R.id.banner)
        bannerBars = findViewById(R.id.bannerBars)
        bannerText = findViewById(R.id.bannerText)
        list = findViewById(R.id.list)

        pttArea = findViewById(R.id.pttArea)
        ripple = findViewById(R.id.ripple)
        btnPtt = findViewById(R.id.btnPtt)
        pttLabel = findViewById(R.id.pttLabel)
        btnDisconnect = findViewById(R.id.btnDisconnect)

        tabChannels = findViewById(R.id.tabChannels)
        tabFriends = findViewById(R.id.tabFriends)
        tabProfile = findViewById(R.id.tabProfile)
        tabSettings = findViewById(R.id.tabSettings)
        bottomNav = findViewById(R.id.bottomNav)
        recentsBox = findViewById(R.id.recentsBox)
        recentsRow = findViewById(R.id.recentsRow)
        batteryStatus = findViewById(R.id.batteryStatus)
        chkHd = findViewById(R.id.chkHd)
        chkBeep = findViewById(R.id.chkBeep)

        myCode = findViewById(R.id.myCode)
        inputFriendCode = findViewById(R.id.inputFriendCode)
        friendsEmpty = findViewById(R.id.friendsEmpty)
        friendsConn = findViewById(R.id.friendsConn)
        friendsList = findViewById(R.id.friendsList)

        profileWalkie = findViewById(R.id.profileWalkie)
        profileSkinName = findViewById(R.id.profileSkinName)
        inputProfileName = findViewById(R.id.inputProfileName)
        skinsRow = findViewById(R.id.skinsRow)

        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        ripple.baseRadiusDp = 75f
        welcomeRipple.baseRadiusDp = 62f

        // Valores guardados (el canal y la clave del canal no se recuerdan a propósito)
        inputServer.setText(prefs.getString("server", BuildConfig.DEFAULT_SERVER))
        inputName.setText(Store.name(this))
        inputProfileName.setText(Store.name(this))
        mySkin = Store.skin(this)
        inputChannel.setText(prefs.getString("channel", ""))
        inputKey.setText(prefs.getString("key", BuildConfig.DEFAULT_KEY))
        chkVolume.isChecked = prefs.getBoolean("volPtt", false)

        setupTabs()
        val savedTab = savedInstanceState?.getInt("tab", R.id.nav_channels) ?: R.id.nav_channels
        if (savedTab != R.id.nav_channels) {
            tabChannels.visibility = View.GONE
            tabView(savedTab).visibility = View.VISIBLE
            currentTab = savedTab
            bottomNav.selectedItemId = savedTab
        }
        setupFriends()
        setupProfile()
        setupSettings()
        setupRecents()
        handleInviteIntent(intent)
        btnJoin.setOnClickListener { onConnectClicked("join") }
        btnCreate.setOnClickListener { onConnectClicked("create") }
        btnDisconnect.setOnClickListener { service?.disconnect() }
        findViewById<View>(R.id.btnChat).setOnClickListener { showChat() }
        btnWelcome.setOnClickListener { dismissWelcome(true) }

        btnPtt.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                    service?.startTalking()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    service?.stopTalking()
                }
            }
            true
        }

        welcomeDone = savedInstanceState?.getBoolean("welcomeDone") == true
        if (welcomeDone) {
            welcome.visibility = View.GONE
        } else {
            playWelcome()
        }
        render()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleInviteIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        renderBattery()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("welcomeDone", welcomeDone)
        outState.putInt("tab", currentTab)
    }

    override fun onStart() {
        super.onStart()
        bindService(Intent(this, PttService::class.java), conn, Context.BIND_AUTO_CREATE)
        ensureAccount()
        refreshAccount()
        startPresence()
        if (Store.hasAccount(this)) askNotifications()
    }

    override fun onStop() {
        recorder?.stop()
        voicePlayer.stop()
        presence?.stop()
        presence = null
        service?.listener = null
        try {
            unbindService(conn)
        } catch (e: IllegalArgumentException) {
        }
        service = null
        super.onStop()
    }

    override fun onChanged() = render()

    override fun onChat() {
        renderChat()
        val u = service?.chatUnread ?: 0
        findViewById<TextView>(R.id.btnChat).text =
            if (u > 0) getString(R.string.btn_chat_n, u) else getString(R.string.btn_chat)
    }

    // ------------------------------------------------------ Chat del canal

    private var chatDialog: AlertDialog? = null
    private var chatText: TextView? = null
    private var chatScroll: android.widget.ScrollView? = null

    private fun showChat() {
        val s = service ?: return
        s.chatUnread = 0
        findViewById<TextView>(R.id.btnChat).text = getString(R.string.btn_chat)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text))
            textSize = 15f
            setPadding(pad, pad, pad, pad)
        }
        val scroll = android.widget.ScrollView(this).apply {
            addView(tv)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (260 * resources.displayMetrics.density).toInt()
            )
        }
        val input = EditText(this).apply {
            hint = getString(R.string.chat_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            filters = arrayOf(android.text.InputFilter.LengthFilter(500))
            setSingleLine(true)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(scroll)
            addView(input, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(pad, 0, pad, 0) })
        }
        chatText = tv
        chatScroll = scroll
        chatDialog?.dismiss()
        val send = {
            val t = input.text.toString()
            if (t.isNotBlank()) {
                service?.sendChat(t)
                input.setText("")
            }
        }
        input.setOnEditorActionListener { _, _, _ -> send(); true }
        chatDialog = AlertDialog.Builder(this)
            .setTitle(getString(R.string.chat_title, s.channelName))
            .setView(box)
            .setPositiveButton(R.string.chat_send, null)
            .setNegativeButton(R.string.close, null)
            .create().also { d ->
                d.setOnDismissListener { chatText = null; chatScroll = null }
                d.show()
                // el botón "Enviar" no cierra el diálogo
                d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { send() }
            }
        renderChat()
    }

    private fun renderChat() {
        val tv = chatText ?: return
        val s = service ?: return
        s.chatUnread = 0
        val sb = android.text.SpannableStringBuilder()
        if (s.chat.isEmpty()) sb.append(getString(R.string.chat_empty))
        for (m in s.chat) {
            val who = if (m.mine) getString(R.string.chat_me) else m.name
            val start = sb.length
            sb.append(who).append(": ")
            sb.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), start, sb.length, 0)
            sb.append(m.text).append('\n')
        }
        tv.text = sb
        chatScroll?.post { chatScroll?.fullScroll(View.FOCUS_DOWN) }
    }

    // ------------------------------------------------------------ Bienvenida

    private fun playWelcome() {
        welcomeRipple.start()
        val d = resources.displayMetrics.density
        listOf(welcomeLogo, welcomeTitle, welcomeTagline, btnWelcome).forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = 28f * d
            v.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(150L + i * 140L)
                .setDuration(600)
                .start()
        }
        welcomeLogo.scaleX = 0.75f
        welcomeLogo.scaleY = 0.75f
        welcomeLogo.animate().scaleX(1f).scaleY(1f).setStartDelay(150).setDuration(700).start()
    }

    private fun dismissWelcome(animated: Boolean) {
        if (welcomeDone) return
        welcomeDone = true
        if (animated) {
            welcome.animate().alpha(0f).setDuration(350).withEndAction {
                welcome.visibility = View.GONE
                welcomeRipple.stop()
            }.start()
        } else {
            welcome.visibility = View.GONE
            welcomeRipple.stop()
        }
    }

    // ---------------------------------------------------------------- Teclas

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (welcomeDone && chkVolume.isChecked && keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event?.repeatCount == 0) service?.startTalking()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (welcomeDone && chkVolume.isChecked && keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            service?.stopTalking()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    // ------------------------------------------------------------ Conexión

    private fun onConnectClicked(mode: String) {
        val s = service
        if (s == null) {
            toast(getString(R.string.service_not_ready))
            return
        }
        if (s.state != PttService.DISCONNECTED) return
        if (inputChannel.text.isNullOrBlank()) {
            inputChannel.error = getString(R.string.enter_channel)
            return
        }
        if (inputServer.text.isNullOrBlank()) {
            showTab(R.id.nav_settings)
            inputServer.error = getString(R.string.enter_server)
            return
        }
        val perms = mutableListOf<String>()
        if (!hasMic()) perms += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            perms += Manifest.permission.POST_NOTIFICATIONS
        }
        if (perms.isNotEmpty()) {
            pendingMode = mode
            permLauncher.launch(perms.toTypedArray())
        } else {
            doConnect(mode)
        }
    }

    private fun doConnect(mode: String) {
        val url = Store.normalizeUrl(inputServer.text.toString())
        val channel = inputChannel.text.toString().trim()
        val name = inputName.text.toString().trim().ifEmpty { Build.MODEL }
        inputProfileName.setText(name)
        val key = inputKey.text.toString()
        val pass = inputPass.text.toString()

        prefs.edit()
            .putString("server", inputServer.text.toString().trim())
            .putString("name", name)
            .putString("channel", channel)
            .putString("key", key)
            .putBoolean("volPtt", chkVolume.isChecked)
            .apply()

        Store.touchChannel(this, channel)
        renderRecents()
        ContextCompat.startForegroundService(this, Intent(this, PttService::class.java))
        service?.connect(url, channel, name, key, mode, pass, mySkin)
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    // ------------------------------------------------------------------ UI

    private fun render() {
        val s = service
        val st = s?.state ?: PttService.DISCONNECTED
        val disconnected = st == PttService.DISCONNECTED
        val connected = st == PttService.CONNECTED
        val tx = s?.transmitting == true
        val talker = s?.talker
        val users = s?.users ?: emptyList()

        if (connected != lastCanInvite) {
            lastCanInvite = connected
            if (::friendsAdapter.isInitialized) renderFriends()
        }

        // Chip de estado
        statusView.text = if (disconnected) getString(R.string.disconnected) else (s?.statusText ?: "")
        val dot = when (st) {
            PttService.CONNECTED -> cGreen
            PttService.CONNECTING -> cAmber
            else -> cGray
        }
        statusDot.backgroundTintList = ColorStateList.valueOf(dot)

        // Qué panel se ve
        panelConnect.visibility = if (disconnected) View.VISIBLE else View.GONE
        panelChannel.visibility = if (disconnected) View.GONE else View.VISIBLE
        pttArea.visibility = if (disconnected) View.GONE else View.VISIBLE
        btnDisconnect.visibility = if (disconnected) View.GONE else View.VISIBLE

        if (disconnected) {
            // Mensaje de error / motivo de la desconexión (p. ej. "Ese canal no existe")
            val msg = s?.statusText.orEmpty()
            if (msg.isEmpty() || msg == getString(R.string.disconnected)) {
                connectMsg.visibility = View.GONE
            } else {
                connectMsg.text = msg
                connectMsg.visibility = View.VISIBLE
            }
            ripple.stop()
            bannerBars.stop()
            return
        }
        connectMsg.visibility = View.GONE

        // Canal
        val ch = s?.channelName.orEmpty()
        channelTitle.text = if (ch.isEmpty()) getString(R.string.connecting) else "#$ch"
        channelCount.text = resources.getQuantityString(R.plurals.connected_count, users.size, users.size)

        // Quién está hablando
        when {
            tx -> {
                bannerText.text = getString(R.string.you_transmitting)
                banner.setBackgroundResource(R.drawable.bg_banner_tx)
                bannerBars.setColor(cPink)
                bannerBars.visibility = View.VISIBLE
                bannerBars.start()
            }
            talker != null -> {
                bannerText.text = getString(R.string.someone_talking, talker)
                banner.setBackgroundResource(R.drawable.bg_banner_talk)
                bannerBars.setColor(cLavender)
                bannerBars.visibility = View.VISIBLE
                bannerBars.start()
            }
            else -> {
                bannerText.text = if (connected) getString(R.string.channel_free) else getString(R.string.connecting)
                banner.setBackgroundResource(R.drawable.bg_banner_idle)
                bannerBars.stop()
                bannerBars.visibility = View.GONE
            }
        }

        adapter.submit(users, s?.myName.orEmpty(), talker, tx, s?.skins ?: emptyMap(), mySkin)
        if (connected) maybeAskBattery()

        // Botón de hablar
        val busy = !tx && talker != null
        btnPtt.setBackgroundResource(
            when {
                tx -> R.drawable.bg_ptt_tx
                connected -> R.drawable.bg_ptt_idle
                else -> R.drawable.bg_ptt_off
            }
        )
        btnPtt.alpha = if (busy) 0.55f else 1f
        pttLabel.text = when {
            tx -> getString(R.string.ptt_tx)
            !connected -> getString(R.string.ptt_connecting)
            busy -> getString(R.string.ptt_busy)
            else -> getString(R.string.ptt_hold)
        }
        if (tx) {
            ripple.setColor(cPink)
            ripple.start()
        } else {
            ripple.stop()
        }
    }

    // ------------------------------------------------------------- Pestañas

    private fun setupTabs() {
        bottomNav.setOnItemSelectedListener { item ->
            showTab(item.itemId, fromNav = true)
            true
        }
    }

    private fun tabView(id: Int): View = when (id) {
        R.id.nav_friends -> tabFriends
        R.id.nav_profile -> tabProfile
        R.id.nav_settings -> tabSettings
        else -> tabChannels
    }

    private fun tabIndex(id: Int) = when (id) {
        R.id.nav_friends -> 1
        R.id.nav_profile -> 2
        R.id.nav_settings -> 3
        else -> 0
    }

    private fun showTab(id: Int, fromNav: Boolean = false) {
        if (id != currentTab) {
            val dir = if (tabIndex(id) > tabIndex(currentTab)) 1f else -1f
            val d = resources.displayMetrics.density
            tabView(currentTab).visibility = View.GONE
            val next = tabView(id)
            next.visibility = View.VISIBLE
            next.alpha = 0f
            next.translationX = 28f * d * dir
            next.animate().alpha(1f).translationX(0f).setDuration(220).start()
            currentTab = id
            if (id == R.id.nav_settings) renderBattery()
        }
        if (!fromNav) bottomNav.selectedItemId = id
    }

    // ------------------------------------------------------ Cuenta y amigos

    private val api by lazy { AccountApi(presenceClient, android.os.Handler(mainLooper)) }
    private var registering = false
    private var presenceConnected = true
    private var incoming = listOf<Store.Friend>()
    private var outgoing = listOf<Store.Friend>()
    private var blockedPeople = listOf<Store.Friend>()
    private lateinit var requestsBox: View
    private lateinit var requestsList: LinearLayout
    private lateinit var outgoingText: TextView
    private lateinit var accountStatus: TextView
    private lateinit var blockedList: LinearLayout
    private lateinit var blockedEmpty: TextView
    private var googleEmail = ""
    private var accountEmail = ""
    private var googleOn = false   // el servidor tiene el acceso con Google activado

    // Mensajes de voz
    private data class VoiceMsg(val id: String, val from: String, val name: String, val dur: Long)
    private var voiceMsgs = listOf<VoiceMsg>()
    private lateinit var voiceBox: View
    private lateinit var voiceListView: LinearLayout
    private var recorder: VoiceMail.Recorder? = null
    private val voicePlayer = VoiceMail.Player()

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { Push.register(this) }

    private fun setupFriends() {
        requestsBox = findViewById(R.id.requestsBox)
        requestsList = findViewById(R.id.requestsList)
        voiceBox = findViewById(R.id.voiceBox)
        voiceListView = findViewById(R.id.voiceList)
        outgoingText = findViewById(R.id.outgoingText)
        accountStatus = findViewById(R.id.accountStatus)
        blockedList = findViewById(R.id.blockedList)
        blockedEmpty = findViewById(R.id.blockedEmpty)

        friends = Store.loadFriends(this)
        blockedPeople = Store.loadBlocked(this).map { Store.Friend(it, "", 0) }
        friendsAdapter = FriendsAdapter(
            { f -> friendMenu(f) }, { f -> inviteFriend(f) }, { f, down -> voiceTouch(f, down) }
        )
        friendsList.layoutManager = LinearLayoutManager(this)
        friendsList.adapter = friendsAdapter

        findViewById<View>(R.id.btnCopyCode).setOnClickListener {
            copyText(Store.friendCode(this))
            toast(getString(R.string.code_copied))
        }
        findViewById<View>(R.id.btnShareCode).setOnClickListener {
            val text = getString(R.string.share_text, Store.prettyCode(Store.friendCode(this)))
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text),
                    getString(R.string.share_code)
                )
            )
        }
        findViewById<View>(R.id.btnAddFriend).setOnClickListener { addFriend() }

        findViewById<View>(R.id.btnShowRecovery).setOnClickListener { showRecovery() }
        findViewById<View>(R.id.btnNewRecovery).setOnClickListener { newRecovery() }
        findViewById<View>(R.id.btnRecover).setOnClickListener { showRecoverDialog() }
        findViewById<View>(R.id.btnHaveAccount).setOnClickListener { showRecoverDialog() }
        findViewById<View>(R.id.btnGoogleLogin).apply {
            visibility = if (GoogleAuth.enabled()) View.VISIBLE else View.GONE
            setOnClickListener { googleLogin() }
        }
        findViewById<View>(R.id.btnGoogle).setOnClickListener { googleLinkOrUnlink() }
        findViewById<View>(R.id.btnEmailLogin).setOnClickListener { showEmailDialog(true) }
        findViewById<View>(R.id.btnEmail).setOnClickListener { showEmailDialog(false) }
        findViewById<View>(R.id.updateCard).visibility = if (Updater.available()) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnUpdate).setOnClickListener { checkUpdates() }

        renderFriends()
        renderRequests()
        renderBlocked()
        renderAccount()
    }

    private fun copyText(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(getString(R.string.app_name), text))
    }

    private fun friendMenu(f: Store.Friend) {
        AlertDialog.Builder(this)
            .setTitle(f.name.ifBlank { Store.prettyCode(f.code) })
            .setItems(
                arrayOf(getString(R.string.friend_menu_remove), getString(R.string.friend_menu_block))
            ) { _, which -> if (which == 0) removeFriend(f.code) else blockPerson(f.code) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun addFriend() {
        val code = Store.cleanCode(inputFriendCode.text.toString())
        when {
            code.length < 4 -> inputFriendCode.error = getString(R.string.code_invalid)
            code == Store.friendCode(this) -> inputFriendCode.error = getString(R.string.code_own)
            friends.any { it.code == code } -> inputFriendCode.error = getString(R.string.code_dup)
            else -> sendFriendRequest(code, true)
        }
    }

    private fun sendFriendRequest(code: String, fromForm: Boolean) {
        if (!Store.hasAccount(this)) {
            toast(getString(R.string.account_pending))
            return
        }
        api.call(this, "POST", "/api/friends/add", JSONObject().put("code", code)) { r ->
            if (r.ok) {
                if (fromForm) inputFriendCode.setText("")
                val friendsNow = r.json?.optString("state") == "friends"
                toast(getString(if (friendsNow) R.string.friend_added else R.string.request_sent))
                refreshAccount()
            } else if (r.status == 401) {
                sessionClosed()
            } else if (r.error == "not_found") {
                if (fromForm) inputFriendCode.error = getString(R.string.code_notfound)
            } else if (r.error == "blocked") {
                toast(getString(R.string.you_blocked_that))
            } else if (r.error == "full") {
                toast(getString(R.string.friends_full))
            } else if (r.error == "invalid") {
                if (fromForm) inputFriendCode.error = getString(R.string.code_invalid)
            } else {
                toast(getString(R.string.recover_offline))
            }
        }
    }

    private fun removeFriend(code: String) = simplePost("/api/friends/remove", code, R.string.friend_removed)

    private fun blockPerson(code: String) = simplePost("/api/block", code, R.string.user_blocked)

    private fun unblockPerson(code: String) = simplePost("/api/unblock", code, R.string.user_unblocked)

    private fun simplePost(path: String, code: String, msg: Int) {
        api.call(this, "POST", path, JSONObject().put("code", code)) { r ->
            if (r.ok) {
                toast(getString(msg))
                refreshAccount()
            } else if (r.status == 401) {
                sessionClosed()
            } else {
                toast(getString(R.string.recover_offline))
            }
        }
    }

    private fun respondRequest(code: String, accept: Boolean) {
        api.call(
            this, "POST", "/api/friends/respond",
            JSONObject().put("code", code).put("accept", accept)
        ) { r ->
            if (r.status == 401) {
                sessionClosed()
            } else {
                if (r.ok && accept) toast(getString(R.string.friend_added))
                refreshAccount()
            }
        }
    }

    private fun parsePeople(a: JSONArray?): List<Store.Friend> {
        if (a == null) return emptyList()
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Store.Friend(o.optString("code"), o.optString("name"), o.optInt("skin", 0))
        }
    }

    /** Descarga del servidor amigos, solicitudes y bloqueados. */
    private fun refreshAccount() {
        if (!Store.hasAccount(this)) return
        api.call(this, "GET", "/api/me") { r ->
            val j = r.json
            if (r.status == 401) {
                sessionClosed()
            } else if (r.ok && j != null) {
                friends = parsePeople(j.optJSONArray("friends")).toMutableList()
                incoming = parsePeople(j.optJSONArray("incoming"))
                outgoing = parsePeople(j.optJSONArray("outgoing"))
                blockedPeople = parsePeople(j.optJSONArray("blocked"))
                googleEmail = j.optString("google")
                accountEmail = j.optString("email")
                googleOn = j.optBoolean("googleEnabled", false)
                renderAccount()
                Store.saveFriends(this, friends)
                Store.saveBlocked(this, blockedPeople.map { it.code })
                service?.updateMuted()
                renderFriends()
                renderRequests()
                renderBlocked()
                refreshVoice()
            }
        }
    }

    private fun sessionClosed() {
        Store.clearToken(this)
        presence?.stop()
        presence = null
        renderAccount()
        toast(getString(R.string.session_closed))
    }

    /** La primera vez se crea la cuenta sola; se conserva el código que ya tenías. */
    private fun ensureAccount() {
        if (Store.hasAccount(this) || registering) return
        registering = true
        val body = JSONObject()
            .put("name", Store.name(this))
            .put("skin", mySkin)
            .put("code", Store.friendCode(this))
        api.call(this, "POST", "/api/register", body, auth = false) { r ->
            registering = false
            val j = r.json
            if (r.ok && j != null) {
                val code = j.optString("code")
                val rec = j.optString("recovery")
                Store.saveAccount(this, code, j.optString("token"), rec)
                renderAccount()
                showRecoveryDialog(rec)
                // Los amigos que tenías guardados en el teléfono pasan a ser solicitudes
                val old = Store.loadFriends(this).filter { it.code != code }
                if (old.isEmpty()) {
                    refreshAccount()
                } else {
                    var left = old.size
                    for (f in old) {
                        api.call(this, "POST", "/api/friends/add", JSONObject().put("code", f.code)) {
                            left--
                            if (left == 0) refreshAccount()
                        }
                    }
                }
                startPresence()
                askNotifications()
            } else {
                renderAccount()
            }
        }
    }

    private fun renderAccount() {
        myCode.text = Store.prettyCode(Store.friendCode(this))
        accountStatus.text = if (Store.hasAccount(this)) {
            getString(R.string.account_active, Store.prettyCode(Store.friendCode(this)))
        } else {
            getString(R.string.account_pending)
        }
        if (googleEmail.isNotEmpty()) {
            accountStatus.text = accountStatus.text.toString() + "\n" + getString(R.string.google_linked, googleEmail)
        }
        if (accountEmail.isNotEmpty()) {
            accountStatus.text = accountStatus.text.toString() + "\n" + getString(R.string.email_linked, accountEmail)
        }
        findViewById<TextView>(R.id.btnEmail).text =
            getString(if (accountEmail.isEmpty()) R.string.btn_email_set else R.string.btn_email_change)
        findViewById<TextView>(R.id.btnGoogle).apply {
            visibility = if (GoogleAuth.enabled() && googleOn && Store.hasAccount(this@MainActivity)) View.VISIBLE else View.GONE
            text = getString(if (googleEmail.isEmpty()) R.string.btn_google_link else R.string.btn_google_unlink)
        }
        val msg = when {
            !Store.hasAccount(this) -> getString(R.string.account_pending)
            !presenceConnected -> getString(R.string.friends_offline)
            else -> ""
        }
        friendsConn.visibility = if (msg.isEmpty()) View.GONE else View.VISIBLE
        friendsConn.text = msg
    }

    private fun personLabel(p: Store.Friend) = p.name.ifBlank { Store.prettyCode(p.code) }

    private fun renderFriends() {
        friendsEmpty.visibility = if (friends.isEmpty()) View.VISIBLE else View.GONE
        friendsAdapter.submit(
            friends.toList(), friendStatus, service?.state == PttService.CONNECTED,
            (service?.state ?: PttService.DISCONNECTED) == PttService.DISCONNECTED
        )
    }

    private fun renderRequests() {
        requestsBox.visibility = if (incoming.isEmpty()) View.GONE else View.VISIBLE
        requestsList.removeAllViews()
        for (q in incoming) {
            val v = layoutInflater.inflate(R.layout.item_request, requestsList, false)
            v.findViewById<WalkieView>(R.id.rAvatar).setSkin(q.skin)
            v.findViewById<TextView>(R.id.rName).text = personLabel(q)
            v.findViewById<TextView>(R.id.rSub).text = getString(R.string.request_sub, Store.prettyCode(q.code))
            v.findViewById<View>(R.id.rAccept).setOnClickListener { respondRequest(q.code, true) }
            v.findViewById<View>(R.id.rDecline).setOnClickListener { respondRequest(q.code, false) }
            v.findViewById<View>(R.id.rBlock).setOnClickListener { blockPerson(q.code) }
            requestsList.addView(v)
        }
        outgoingText.visibility = if (outgoing.isEmpty()) View.GONE else View.VISIBLE
        outgoingText.text = getString(R.string.pending_sent, outgoing.joinToString(", ") { personLabel(it) })
    }

    private fun renderBlocked() {
        blockedEmpty.visibility = if (blockedPeople.isEmpty()) View.VISIBLE else View.GONE
        blockedList.removeAllViews()
        for (p in blockedPeople) {
            val v = layoutInflater.inflate(R.layout.item_blocked, blockedList, false)
            v.findViewById<TextView>(R.id.bName).text = personLabel(p)
            v.findViewById<View>(R.id.bUnblock).setOnClickListener { unblockPerson(p.code) }
            blockedList.addView(v)
        }
    }

    private fun startPresence() {
        val url = Store.normalizeUrl(prefs.getString("server", BuildConfig.DEFAULT_SERVER) ?: "")
        if (url.isEmpty() || !Store.hasAccount(this)) return
        presence?.stop()
        presence = PresenceClient(presenceClient, android.os.Handler(mainLooper)).also { pc ->
            pc.listener = object : PresenceClient.Listener {
                override fun onStatus(list: List<PresenceClient.FriendStatus>) {
                    friendStatus = list.associateBy { it.code }
                    renderFriends()
                }

                override fun onInvite(fromCode: String, fromName: String, skin: Int, channel: String, pass: String) {
                    showInvite(fromName, channel, pass)
                }

                override fun onInviteResult(toCode: String, delivered: Boolean) {
                    toast(getString(if (delivered) R.string.invite_sent else R.string.invite_failed))
                }

                override fun onFriendsChanged() = refreshAccount()

                override fun onVoice(fromName: String) {
                    refreshVoice()
                    toast(getString(R.string.voice_notif_title, fromName.ifBlank { getString(R.string.a_friend) }))
                }

                override fun onAuthError() = sessionClosed()

                override fun onConnection(connected: Boolean) {
                    presenceConnected = connected
                    renderAccount()
                }
            }
            pc.start(
                url, prefs.getString("key", BuildConfig.DEFAULT_KEY) ?: "",
                Store.friendCode(this), Store.token(this), Store.name(this), mySkin,
                service?.state == PttService.CONNECTED
            )
        }
    }

    // ------------------------------------------------------ Recuperación de cuenta

    private fun prettyRecovery(k: String) = k.chunked(4).joinToString("-")

    private fun showRecoveryDialog(key: String) {
        AlertDialog.Builder(this)
            .setTitle(R.string.recovery_title)
            .setMessage(getString(R.string.recovery_text, prettyRecovery(key)))
            .setPositiveButton(R.string.got_it, null)
            .setNeutralButton(R.string.copy) { _, _ ->
                copyText(prettyRecovery(key))
                toast(getString(R.string.recovery_copied))
            }
            .show()
    }

    private fun showRecovery() {
        val k = Store.recoveryKey(this)
        if (k.isEmpty()) toast(getString(R.string.recovery_none)) else showRecoveryDialog(k)
    }

    private fun newRecovery() {
        if (!Store.hasAccount(this)) {
            toast(getString(R.string.account_pending))
            return
        }
        AlertDialog.Builder(this)
            .setMessage(R.string.recovery_confirm)
            .setPositiveButton(R.string.continue_) { _, _ ->
                api.call(this, "POST", "/api/recovery/new") { r ->
                    val rec = r.json?.optString("recovery").orEmpty()
                    if (r.ok && rec.isNotEmpty()) {
                        Store.saveAccount(this, Store.friendCode(this), Store.token(this), rec)
                        showRecoveryDialog(rec)
                    } else if (r.status == 401) {
                        sessionClosed()
                    } else {
                        toast(getString(R.string.recover_offline))
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showRecoverDialog() {
        val d = resources.displayMetrics.density
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding((22 * d).toInt(), (8 * d).toInt(), (22 * d).toInt(), 0)
        val codeIn = EditText(this)
        codeIn.hint = getString(R.string.recover_code_hint)
        codeIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        codeIn.setSingleLine()
        val keyIn = EditText(this)
        keyIn.hint = getString(R.string.recover_key_hint)
        keyIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        keyIn.setSingleLine()
        box.addView(codeIn)
        box.addView(keyIn)
        AlertDialog.Builder(this)
            .setTitle(R.string.recover_title)
            .setView(box)
            .setPositiveButton(R.string.continue_) { _, _ ->
                doRecover(Store.cleanCode(codeIn.text.toString()), Store.cleanCode(keyIn.text.toString()))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private var pendingUpdate: Updater.Info? = null

    private fun checkUpdates() {
        val status = findViewById<TextView>(R.id.updateStatus)
        val btn = findViewById<TextView>(R.id.btnUpdate)
        val u = pendingUpdate
        if (u != null) {
            status.text = getString(R.string.update_downloading)
            Updater.install(this, u) { err ->
                status.text = when (err) {
                    null -> getString(R.string.update_opening)
                    "permission" -> getString(R.string.update_permission)
                    else -> getString(R.string.update_failed)
                }
            }
            return
        }
        status.text = getString(R.string.update_checking)
        Updater.check { info, err ->
            when {
                err != null -> status.text = getString(R.string.update_failed)
                info == null -> status.text = getString(R.string.update_latest)
                else -> {
                    pendingUpdate = info
                    status.text = getString(R.string.update_new, info.name)
                    btn.text = getString(R.string.btn_install_update)
                }
            }
        }
    }

    private fun emailError(status: Int, err: String?) {
        toast(
            getString(
                when {
                    status == 0 -> R.string.recover_offline
                    err == "bad_email" -> R.string.email_bad
                    err == "bad_password" -> R.string.email_bad_password
                    err == "email_taken" -> R.string.email_taken
                    err == "locked" -> R.string.recover_locked
                    err == "bad_login" -> R.string.email_bad_login
                    else -> R.string.google_failed
                }
            )
        )
    }

    /**
     * Correo y contraseña. login=true (bienvenida): Entrar con una cuenta existente o Crear cuenta.
     * login=false (Perfil): asocia o cambia el correo y la contraseña de esta cuenta.
     */
    private fun showEmailDialog(login: Boolean) {
        val d = resources.displayMetrics.density
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding((22 * d).toInt(), (8 * d).toInt(), (22 * d).toInt(), 0)
        val mail = EditText(this)
        mail.hint = getString(R.string.email_hint)
        mail.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        mail.setSingleLine()
        val pass = EditText(this)
        pass.hint = getString(R.string.password_hint)
        pass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        pass.setSingleLine()
        box.addView(mail)
        box.addView(pass)
        val b = AlertDialog.Builder(this)
            .setTitle(if (login) R.string.email_login_title else R.string.email_set_title)
            .setView(box)
            .setNegativeButton(R.string.cancel, null)
        if (login) {
            b.setPositiveButton(R.string.email_enter) { _, _ ->
                emailLogin(mail.text.toString(), pass.text.toString())
            }
            b.setNeutralButton(R.string.email_create) { _, _ ->
                emailSet(mail.text.toString(), pass.text.toString(), true)
            }
        } else {
            b.setPositiveButton(R.string.continue_) { _, _ ->
                emailSet(mail.text.toString(), pass.text.toString(), false)
            }
        }
        b.show()
    }

    private fun emailSet(email: String, password: String, fromWelcome: Boolean) {
        if (!Store.hasAccount(this)) {
            toast(getString(R.string.email_wait))
            return
        }
        api.call(
            this, "POST", "/api/email/set",
            JSONObject().put("email", email.trim()).put("password", password)
        ) { r ->
            if (r.ok) {
                accountEmail = r.json?.optString("email").orEmpty()
                toast(getString(R.string.email_saved))
                renderAccount()
                if (fromWelcome && !welcomeDone) dismissWelcome(true)
            } else {
                emailError(r.status, r.error)
            }
        }
    }

    private fun emailLogin(email: String, password: String) {
        api.call(
            this, "POST", "/api/email/login",
            JSONObject().put("email", email.trim()).put("password", password), auth = false
        ) { r ->
            val j = r.json
            if (r.ok && j != null) {
                Store.saveAccount(this, j.optString("code"), j.optString("token"), null)
                val nm = j.optString("name")
                if (nm.isNotBlank()) {
                    prefs.edit().putString("name", nm).apply()
                    inputName.setText(nm)
                    inputProfileName.setText(nm)
                }
                selectSkin(j.optInt("skin", 0))
                toast(getString(R.string.recover_ok))
                renderAccount()
                refreshAccount()
                startPresence()
                Push.register(this)
                if (!welcomeDone) dismissWelcome(true)
            } else {
                emailError(r.status, r.error)
            }
        }
    }

    private fun googleError(e: String?, status: Int, err: String?) {
        toast(
            getString(
                when {
                    status == 0 -> R.string.recover_offline
                    err == "google_taken" -> R.string.google_taken
                    err == "not_linked" -> R.string.google_not_linked
                    err == "google_off" -> R.string.google_off
                    else -> R.string.google_failed
                }
            )
        )
    }

    /** Vincula (o desvincula) tu cuenta de Google: así puedes recuperar tu cuenta sin la clave. */
    private fun googleLinkOrUnlink() {
        if (googleEmail.isNotEmpty()) {
            AlertDialog.Builder(this)
                .setTitle(R.string.btn_google_unlink)
                .setMessage(R.string.google_unlink_confirm)
                .setPositiveButton(R.string.continue_) { _, _ ->
                    api.call(this, "POST", "/api/google/unlink", JSONObject()) { r ->
                        if (r.ok) googleEmail = ""
                        renderAccount()
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
            return
        }
        GoogleAuth.idToken(this) { tok, err ->
            if (tok == null) {
                if (err != null) toast(getString(R.string.google_failed))
            } else {
                api.call(this, "POST", "/api/google/link", JSONObject().put("idToken", tok)) { r ->
                    if (r.ok) {
                        googleEmail = r.json?.optString("email").orEmpty()
                        toast(getString(R.string.google_link_ok))
                        renderAccount()
                    } else {
                        googleError(null, r.status, r.error)
                    }
                }
            }
        }
    }

    /** Entrar con Google (por ejemplo tras reinstalar): recupera tu cuenta y tus amigos. */
    private fun googleLogin() {
        GoogleAuth.idToken(this) { tok, err ->
            if (tok == null) {
                if (err != null) toast(getString(R.string.google_failed))
            } else {
                api.call(this, "POST", "/api/google/login", JSONObject().put("idToken", tok), auth = false) { r ->
                    val j = r.json
                    if (r.ok && j != null) {
                        Store.saveAccount(this, j.optString("code"), j.optString("token"), null)
                        val nm = j.optString("name")
                        if (nm.isNotBlank()) {
                            prefs.edit().putString("name", nm).apply()
                            inputName.setText(nm)
                            inputProfileName.setText(nm)
                        }
                        selectSkin(j.optInt("skin", 0))
                        toast(getString(R.string.recover_ok))
                        renderAccount()
                        refreshAccount()
                        startPresence()
                        Push.register(this)
                        if (!welcomeDone) dismissWelcome(true)
                    } else {
                        googleError(null, r.status, r.error)
                    }
                }
            }
        }
    }

    private fun doRecover(code: String, key: String) {
        val body = JSONObject().put("code", code).put("recovery", key)
        api.call(this, "POST", "/api/recover", body, auth = false) { r ->
            val j = r.json
            if (r.ok && j != null) {
                Store.saveAccount(this, j.optString("code", code), j.optString("token"), key)
                val nm = j.optString("name")
                if (nm.isNotBlank()) {
                    prefs.edit().putString("name", nm).apply()
                    inputName.setText(nm)
                    inputProfileName.setText(nm)
                }
                selectSkin(j.optInt("skin", 0))
                toast(getString(R.string.recover_ok))
                renderAccount()
                refreshAccount()
                startPresence()
                if (!welcomeDone) dismissWelcome(true)
            } else if (r.status == 0) {
                toast(getString(R.string.recover_offline))
            } else if (r.error == "locked") {
                toast(getString(R.string.recover_locked))
            } else {
                toast(getString(R.string.recover_bad))
            }
        }
    }

    // ------------------------------------------- Acciones sobre participantes del canal

    private fun onParticipantClick(name: String) {
        val s = service ?: return
        if (name == s.myName || s.state != PttService.CONNECTED) return
        val code = s.codes[name].orEmpty()
        val options = mutableListOf<Pair<String, () -> Unit>>()
        if (code.isNotEmpty()) {
            if (blockedPeople.any { it.code == code }) {
                options += getString(R.string.btn_unblock) to { unblockPerson(code) }
            } else {
                if (friends.none { it.code == code } && outgoing.none { it.code == code }) {
                    options += getString(R.string.act_add_friend) to { sendFriendRequest(code, false) }
                }
                options += getString(R.string.btn_block) to { blockPerson(code) }
            }
        }
        if (s.owner.isNotEmpty() && s.owner == s.myName) {
            options += getString(R.string.act_kick) to {
                s.kick(name)
                toast(getString(R.string.kick_done, name))
            }
        }
        if (options.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(options.map { it.first }.toTypedArray()) { _, i -> options[i].second() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    /** Guarda nombre/skin en el servidor y avisa a la presencia. */
    private fun syncProfile() {
        presence?.update(Store.name(this), mySkin)
        if (Store.hasAccount(this)) {
            api.call(
                this, "POST", "/api/profile",
                JSONObject().put("name", Store.name(this)).put("skin", mySkin)
            ) { }
        }
    }

    // --------------------------------------------------------------- Perfil

    private fun setupProfile() {
        val d = resources.displayMetrics.density
        for (i in Skins.all.indices) {
            val cell = FrameLayout(this)
            val lp = LinearLayout.LayoutParams((72 * d).toInt(), (100 * d).toInt())
            lp.marginEnd = (10 * d).toInt()
            cell.layoutParams = lp
            cell.tag = i
            val w = WalkieView(this)
            w.setSkin(i)
            val wlp = FrameLayout.LayoutParams((40 * d).toInt(), (56 * d).toInt())
            wlp.gravity = android.view.Gravity.CENTER
            cell.addView(w, wlp)
            cell.setOnClickListener { selectSkin(i) }
            skinsRow.addView(cell)
        }
        findViewById<View>(R.id.btnSaveName).setOnClickListener {
            val n = inputProfileName.text.toString().trim()
            if (n.isEmpty()) {
                inputProfileName.error = getString(R.string.enter_name)
                return@setOnClickListener
            }
            prefs.edit().putString("name", n).apply()
            inputName.setText(n)
            syncProfile()
            toast(getString(R.string.name_saved))
        }
        selectSkin(mySkin, save = false)
    }

    private fun selectSkin(i: Int, save: Boolean = true) {
        mySkin = i
        if (save) {
            prefs.edit().putInt("skin", i).apply()
            syncProfile()
        }
        profileWalkie.setSkin(i)
        profileSkinName.text = resources.getStringArray(R.array.skin_names).getOrElse(i) { "" }
        for (k in 0 until skinsRow.childCount) {
            skinsRow.getChildAt(k).setBackgroundResource(
                if (k == i) R.drawable.bg_skin_selected else R.drawable.bg_skin_normal
            )
        }
        if (save && service?.state == PttService.DISCONNECTED) render()
    }

    // -------------------------------------------------------------- Ajustes

    private fun setupSettings() {
        chkVolume.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("volPtt", on).apply() }
        chkBeep.isChecked = prefs.getBoolean("beep", true)
        chkBeep.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("beep", on).apply() }
        chkHd.isChecked = prefs.getBoolean("hd", false)
        chkHd.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("hd", on).apply()
            if (on && !OpusCodec.encoderAvailable()) toast(getString(R.string.hd_unavailable))
        }
        val themeGroup = findViewById<MaterialButtonToggleGroup>(R.id.themeGroup)
        themeGroup.check(
            when (Store.themeMode(this)) {
                1 -> R.id.themeLight
                2 -> R.id.themeDark
                else -> R.id.themeSystem
            }
        )
        themeGroup.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val mode = when (id) {
                R.id.themeLight -> 1
                R.id.themeDark -> 2
                else -> 0
            }
            if (mode != Store.themeMode(this)) {
                prefs.edit().putInt("theme", mode).apply()
                AppCompatDelegate.setDefaultNightMode(Store.nightMode(this))
            }
        }
        findViewById<View>(R.id.btnBattery).setOnClickListener { openBatterySettings() }
        findViewById<View>(R.id.btnBrandGuide).setOnClickListener {
            val brand = Build.MANUFACTURER.lowercase().trim().replace(" ", "-")
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://dontkillmyapp.com/$brand")))
            } catch (e: Exception) {
                toast(getString(R.string.no_browser))
            }
        }
        renderBattery()
        findViewById<View>(R.id.btnSaveServer).setOnClickListener {
            prefs.edit()
                .putString("server", inputServer.text.toString().trim())
                .putString("key", inputKey.text.toString())
                .apply()
            ensureAccount()
            refreshAccount()
            startPresence()
            toast(getString(R.string.server_saved))
        }
        findViewById<View>(R.id.btnAddWidget).setOnClickListener {
            val mgr = AppWidgetManager.getInstance(this)
            if (mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(ComponentName(this, PttWidgetProvider::class.java), null, null)
            } else {
                toast(getString(R.string.widget_manual))
            }
        }
        val ver = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            ""
        }
        findViewById<TextView>(R.id.aboutText).text = getString(R.string.about, ver)
    }

    // ------------------------------------------------------ Batería / segundo plano

    private fun ignoringBattery(): Boolean = try {
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
    } catch (e: Exception) {
        true
    }

    private fun renderBattery() {
        val ok = ignoringBattery()
        batteryStatus.text = getString(if (ok) R.string.battery_ok else R.string.battery_restricted)
        batteryStatus.setTextColor(if (ok) cGreen else cAmber)
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            } catch (e2: Exception) {
                toast(getString(R.string.no_browser))
            }
        }
    }

    /** La primera vez que te conectas, si la batería puede cerrar Wavko, te lo avisamos. */
    private fun maybeAskBattery() {
        if (prefs.getBoolean("batteryAsked", false) || ignoringBattery()) return
        prefs.edit().putBoolean("batteryAsked", true).apply()
        AlertDialog.Builder(this)
            .setTitle(R.string.battery_dialog_title)
            .setMessage(R.string.battery_dialog_text)
            .setPositiveButton(R.string.battery_fix) { _, _ -> openBatterySettings() }
            .setNegativeButton(R.string.later, null)
            .show()
    }

    // ------------------------------------------------------ Invitaciones

    private fun inviteFriend(f: Store.Friend) {
        val s = service ?: return
        if (s.state != PttService.CONNECTED || s.channelName.isEmpty()) return
        val sent = presence?.sendInvite(f.code, s.channelName, s.channelPass) ?: false
        if (!sent) toast(getString(R.string.invite_failed))
    }

    private fun showInvite(from: String, channel: String, pass: String) {
        inviteDialog?.dismiss()
        val who = from.ifBlank { getString(R.string.a_friend) }
        inviteDialog = AlertDialog.Builder(this)
            .setTitle(getString(R.string.invite_title, who))
            .setMessage(getString(R.string.invite_text, channel))
            .setPositiveButton(R.string.join) { _, _ -> acceptInvite(channel, pass) }
            .setNegativeButton(R.string.ignore, null)
            .show()
    }

    private fun acceptInvite(channel: String, pass: String) {
        showTab(R.id.nav_channels)
        if (service?.state != PttService.DISCONNECTED) {
            toast(getString(R.string.leave_first))
            return
        }
        inputChannel.setText(channel)
        inputPass.setText(pass)
        onConnectClicked("join")
    }

    private fun handleInviteIntent(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_OPEN_VOICE, false) == true) {
            i.removeExtra(EXTRA_OPEN_VOICE)
            showTab(R.id.nav_friends)
            refreshVoice()
        }
        val invId = i?.getStringExtra(EXTRA_INVITE_ID)
        if (!invId.isNullOrEmpty()) {
            i.removeExtra(EXTRA_INVITE_ID)
            // Invitación recibida por push: se pide al servidor su contenido (de un solo uso)
            api.call(this, "GET", "/api/invite/$invId") { r ->
                val j = r.json
                if (r.ok && j != null) {
                    showInvite(j.optString("name"), j.optString("channel"), j.optString("pass"))
                } else {
                    toast(getString(R.string.invite_expired))
                }
            }
            return
        }
        val ch = i?.getStringExtra(EXTRA_INVITE_CHANNEL) ?: return
        val pass = i.getStringExtra(EXTRA_INVITE_PASS) ?: ""
        val from = i.getStringExtra(EXTRA_INVITE_FROM) ?: ""
        i.removeExtra(EXTRA_INVITE_CHANNEL)
        i.removeExtra(EXTRA_INVITE_PASS)
        i.removeExtra(EXTRA_INVITE_FROM)
        showInvite(from, ch, pass)
    }

    // ------------------------------------------------------ Mensajes de voz

    private fun refreshVoice() {
        if (!Store.hasAccount(this)) return
        api.call(this, "GET", "/api/voice") { r ->
            val arr = r.json?.optJSONArray("messages")
            if (r.ok && arr != null) {
                voiceMsgs = List(arr.length()) { i ->
                    val o = arr.getJSONObject(i)
                    VoiceMsg(o.optString("id"), o.optString("from"), o.optString("name"), o.optLong("dur", 0))
                }
                renderVoice()
            }
        }
    }

    private fun renderVoice() {
        voiceBox.visibility = if (voiceMsgs.isEmpty()) View.GONE else View.VISIBLE
        voiceListView.removeAllViews()
        for (m in voiceMsgs) {
            val v = layoutInflater.inflate(R.layout.item_voice, voiceListView, false)
            val who = friends.firstOrNull { it.code == m.from }?.name?.ifBlank { null }
                ?: m.name.ifBlank { Store.prettyCode(m.from) }
            v.findViewById<TextView>(R.id.vName).text = who
            v.findViewById<TextView>(R.id.vSub).text = getString(R.string.voice_secs, ((m.dur + 500) / 1000).toInt())
            v.findViewById<View>(R.id.vPlay).setOnClickListener { playVoice(m) }
            v.findViewById<View>(R.id.vDelete).setOnClickListener {
                voiceMsgs = voiceMsgs.filter { it.id != m.id }
                renderVoice()
                api.call(this, "DELETE", "/api/voice/${m.id}") { }
            }
            voiceListView.addView(v)
        }
    }

    private fun playVoice(m: VoiceMsg) {
        api.bytes(this, "GET", "/api/voice/${m.id}") { status, data ->
            if (status == 200 && data != null && data.isNotEmpty()) {
                voicePlayer.play(data) { }
            } else {
                toast(getString(R.string.voice_failed))
            }
        }
    }

    /** Mantener pulsado el micrófono de un amigo graba; al soltar se envía. */
    private fun voiceTouch(f: Store.Friend, down: Boolean) {
        if (!down) {
            recorder?.stop()
            return
        }
        if (recorder?.active == true) return
        if ((service?.state ?: PttService.DISCONNECTED) != PttService.DISCONNECTED) {
            toast(getString(R.string.voice_busy))
            return
        }
        if (!hasMic()) {
            permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        val rec = VoiceMail.Recorder { data, ms ->
            runOnUiThread {
                recorder = null
                if (ms < 700 || data.isEmpty()) {
                    toast(getString(R.string.voice_too_short))
                } else {
                    api.bytes(this, "POST", "/api/voice/send?to=${f.code}&dur=$ms", data) { status, _ ->
                        toast(
                            getString(
                                when (status) {
                                    200 -> R.string.voice_sent
                                    403 -> R.string.voice_not_allowed
                                    else -> R.string.voice_failed
                                }
                            )
                        )
                    }
                }
            }
        }
        if (rec.start()) {
            recorder = rec
            toast(getString(R.string.voice_recording, f.name.ifBlank { Store.prettyCode(f.code) }))
        } else {
            toast(getString(R.string.mic_needed))
        }
    }

    private fun askNotifications() {
        Push.register(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED &&
            !prefs.getBoolean("askedNotif", false)
        ) {
            prefs.edit().putBoolean("askedNotif", true).apply()
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // ------------------------------------------------------ Recientes y favoritos

    private fun setupRecents() = renderRecents()

    private fun renderRecents() {
        val list = Store.loadChannels(this).sortedByDescending { it.fav }
        recentsRow.removeAllViews()
        recentsBox.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        val d = resources.displayMetrics.density
        for (c in list) {
            val tv = TextView(this)
            tv.text = if (c.fav) "★ ${c.name}" else c.name
            tv.setTextColor(ContextCompat.getColor(this, R.color.text))
            tv.textSize = 14f
            tv.setBackgroundResource(R.drawable.bg_chip)
            tv.setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = (8 * d).toInt()
            tv.layoutParams = lp
            tv.setOnClickListener { inputChannel.setText(c.name) }
            tv.setOnLongClickListener {
                Store.toggleFavorite(this, c.name)
                renderRecents()
                true
            }
            recentsRow.addView(tv)
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
