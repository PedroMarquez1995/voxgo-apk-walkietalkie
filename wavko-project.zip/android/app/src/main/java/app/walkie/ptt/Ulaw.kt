package app.walkie.ptt

/** Códec G.711 µ-law: 16 bits -> 8 bits por muestra (mitad de ancho de banda, calidad de voz buena). */
object Ulaw {
    private const val BIAS = 0x84
    private const val CLIP = 32635

    private val decodeTable = ShortArray(256) { i ->
        val u = i.inv() and 0xFF
        val sign = u and 0x80
        val exp = (u shr 4) and 0x07
        val mant = u and 0x0F
        var s = ((mant shl 3) + BIAS) shl exp
        s -= BIAS
        (if (sign != 0) -s else s).toShort()
    }

    private fun encodeSample(sample: Short): Byte {
        var s = sample.toInt()
        var sign = 0
        if (s < 0) {
            s = -s
            sign = 0x80
        }
        if (s > CLIP) s = CLIP
        s += BIAS
        var exp = 7
        var mask = 0x4000
        while (exp > 0 && (s and mask) == 0) {
            exp--
            mask = mask shr 1
        }
        val mant = (s shr (exp + 3)) and 0x0F
        return (sign or (exp shl 4) or mant).inv().toByte()
    }

    fun encode(pcm: ShortArray, out: ByteArray, count: Int) {
        for (i in 0 until count) out[i] = encodeSample(pcm[i])
    }

    fun decode(data: ByteArray, out: ShortArray, count: Int) {
        for (i in 0 until count) out[i] = decodeTable[data[i].toInt() and 0xFF]
    }
}
