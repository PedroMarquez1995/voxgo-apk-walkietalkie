package app.walkie.ptt

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.util.UUID

/** Conversación con un amigo: mensajes de texto y de voz, estilo WhatsApp. Cada amigo tiene la suya. */
class ChatActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_NAME = "name"
        const val EXTRA_SKIN = "skin"
    }

    private lateinit var code: String
    private lateinit var list: RecyclerView
    private lateinit var input: EditText
    private lateinit var action: ImageView
    private lateinit var recHint: TextView
    private lateinit var adapter: ChatAdapter

    private val api by lazy { Push.api() }
    private val handler = Handler(Looper.getMainLooper())
    private var recorder: VoiceMail.Recorder? = null
    private val player = VoiceMail.Player()

    private val micLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok) toast(getString(R.string.mic_needed))
    }

    private val inboxListener: () -> Unit = { render() }
    private val poll = object : Runnable {
        override fun run() {
            Inbox.sync(this@ChatActivity, api)
            handler.postDelayed(this, 4000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        code = intent.getStringExtra(EXTRA_CODE).orEmpty()
        if (code.isEmpty()) {
            finish()
            return
        }
        val name = intent.getStringExtra(EXTRA_NAME).orEmpty().ifBlank { Store.prettyCode(code) }
        findViewById<TextView>(R.id.chatName).text = name
        findViewById<TextView>(R.id.chatSub).text = getString(R.string.chat_sub)
        findViewById<WalkieView>(R.id.chatAvatar).setSkin(intent.getIntExtra(EXTRA_SKIN, 0))
        findViewById<View>(R.id.chatBack).setOnClickListener { finish() }

        list = findViewById(R.id.chatList)
        input = findViewById(R.id.chatInput)
        action = findViewById(R.id.chatAction)
        recHint = findViewById(R.id.chatRecording)

        adapter = ChatAdapter(showSender = false) { b -> playBubble(b) }
        list.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        list.adapter = adapter

        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                action.setImageResource(if (s.isNullOrBlank()) R.drawable.ic_mic else R.drawable.ic_send)
                action.contentDescription =
                    getString(if (s.isNullOrBlank()) R.string.cd_voice_record else R.string.chat_send)
            }

            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) {
                sendText()
                true
            } else false
        }

        // Con texto escrito el botón envía; vacío, mantén pulsado para grabar un audio
        action.setOnTouchListener { v, ev ->
            if (!input.text.isNullOrBlank()) {
                if (ev.actionMasked == MotionEvent.ACTION_UP) sendText()
            } else {
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                        startRecording()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> stopRecording()
                }
            }
            true
        }
        render()
    }

    override fun onStart() {
        super.onStart()
        Inbox.listeners.add(inboxListener)
        handler.removeCallbacks(poll)
        handler.post(poll)
        render()
    }

    override fun onStop() {
        super.onStop()
        Inbox.listeners.remove(inboxListener)
        handler.removeCallbacks(poll)
        recorder?.stop()
        player.stop()
        recHint.visibility = View.GONE
    }

    private fun render() {
        if (!::adapter.isInitialized) return
        val msgs = Chats.load(this, code)
        adapter.submit(msgs.map { Bubble(it.id, it.mine, "", it.kind, it.text, it.dur, it.ts) })
        if (msgs.isNotEmpty()) list.scrollToPosition(msgs.size - 1)
        Chats.clearUnread(this, code)
    }

    private fun sendText() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        api.call(this, "POST", "/api/dm/send", JSONObject().put("to", code).put("text", t)) { r ->
            if (r.ok) {
                Chats.append(this, code, Chats.Msg(r.json?.optString("id").orEmpty().ifEmpty { UUID.randomUUID().toString() }, true, "text", t, 0, System.currentTimeMillis()))
                render()
            } else {
                input.setText(t)
                toast(getString(errorText(r.status, r.error)))
            }
        }
    }

    private fun errorText(status: Int, err: String?) = when {
        status == 0 -> R.string.recover_offline
        err == "not_friends" -> R.string.chat_not_friends
        else -> R.string.voice_failed
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startRecording() {
        if (recorder?.active == true) return
        if (!hasMic()) {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        player.stop()
        val rec = VoiceMail.Recorder { data, ms ->
            runOnUiThread {
                recorder = null
                recHint.visibility = View.GONE
                if (ms < 700 || data.isEmpty()) {
                    toast(getString(R.string.voice_too_short))
                } else {
                    api.bytes(this, "POST", "/api/voice/send?to=$code&dur=$ms", data) { status, _ ->
                        if (status == 200) {
                            val id = UUID.randomUUID().toString()
                            try {
                                Chats.audioFile(this, id).writeBytes(data)
                                Chats.append(this, code, Chats.Msg(id, true, "voice", "", ms, System.currentTimeMillis()))
                            } catch (e: Exception) {
                                // no se pudo guardar la copia local; el mensaje sí se envió
                            }
                            render()
                        } else {
                            toast(getString(errorText(status, if (status == 403) "not_friends" else null)))
                        }
                    }
                }
            }
        }
        if (rec.start()) {
            recorder = rec
            recHint.visibility = View.VISIBLE
        } else {
            toast(getString(R.string.mic_needed))
        }
    }

    private fun stopRecording() {
        recorder?.stop()
    }

    private fun playBubble(b: Bubble) {
        if (adapter.playingId == b.id) {
            player.stop()
            adapter.playingId = null
            return
        }
        val f = Chats.audioFile(this, b.id)
        if (!f.exists()) {
            toast(getString(R.string.voice_failed))
            return
        }
        adapter.playingId = b.id
        player.play(f.readBytes()) {
            runOnUiThread { if (adapter.playingId == b.id) adapter.playingId = null }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
