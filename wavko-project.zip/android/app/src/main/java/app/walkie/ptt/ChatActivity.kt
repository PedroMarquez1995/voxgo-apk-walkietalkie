package app.walkie.ptt

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.util.UUID

/** Conversación con un amigo: mensajes de texto y de voz, estilo WhatsApp. Cada amigo tiene la suya. */
class ChatActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_NAME = "name"
        const val EXTRA_SKIN = "skin"
    }

    private lateinit var code: String
    private lateinit var list: RecyclerView
    private lateinit var input: EditText
    private lateinit var action: ImageView
    private lateinit var recHint: TextView
    private lateinit var adapter: ChatAdapter

    private val api by lazy { Push.api() }
    private val handler = Handler(Looper.getMainLooper())
    private var recorder: VoiceMail.Recorder? = null
    private val player = VoiceMail.Player()

    private val micLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok) toast(getString(R.string.mic_needed))
    }

    private val inboxListener: () -> Unit = { render() }
    private val poll = object : Runnable {
        override fun run() {
            Inbox.sync(this@ChatActivity, api)
            handler.postDelayed(this, 4000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        code = intent.getStringExtra(EXTRA_CODE).orEmpty()
        if (code.isEmpty()) {
            finish()
            return
        }
        val name = intent.getStringExtra(EXTRA_NAME).orEmpty().ifBlank { Store.prettyCode(code) }
        findViewById<TextView>(R.id.chatName).text = name
        findViewById<TextView>(R.id.chatSub).text = getString(R.string.chat_sub)
        findViewById<WalkieView>(R.id.chatAvatar).setSkin(intent.getIntExtra(EXTRA_SKIN, 0))
        findViewById<View>(R.id.chatBack).setOnClickListener { finish() }

        list = findViewById(R.id.chatList)
        input = findViewById(R.id.chatInput)
        action = findViewById(R.id.chatAction)
        recHint = findViewById(R.id.chatRecording)

        Emojis.setup(this, findViewById(R.id.chatEmoji), findViewById(R.id.chatEmojiPanel), input)
        adapter = ChatAdapter(showSender = false, onLong = { b -> askDelete(b) }, onPlay = { b -> playBubble(b) })
        list.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        list.adapter = adapter

        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                action.setImageResource(if (s.isNullOrBlank()) R.drawable.ic_mic else R.drawable.ic_send)
                action.contentDescription =
                    getString(if (s.isNullOrBlank()) R.string.cd_voice_record else R.string.chat_send)
            }

            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) {
                sendText()
                true
            } else false
        }

        // Con texto escrito el botón envía; vacío, mantén pulsado para grabar un audio
        action.setOnTouchListener { v, ev ->
            if (!input.text.isNullOrBlank()) {
                if (ev.actionMasked == MotionEvent.ACTION_UP) sendText()
            } else {
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                        pressStart()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> pressEnd()
                }
            }
            true
        }
        render()
    }

    override fun onStart() {
        super.onStart()
        Inbox.listeners.add(inboxListener)
        handler.removeCallbacks(poll)
        handler.post(poll)
        render()
    }

    override fun onStop() {
        super.onStop()
        Inbox.listeners.remove(inboxListener)
        handler.removeCallbacks(poll)
        pressEnd()
        recorder?.stop()
        player.stop()
        recHint.visibility = View.GONE
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            tone?.release()
        } catch (e: Exception) {
        }
        tone = null
    }

    private fun render() {
        if (!::adapter.isInitialized) return
        val msgs = Chats.load(this, code)
        adapter.submit(msgs.map { Bubble(it.id, it.mine, "", it.kind, it.text, it.dur, it.ts) })
        if (msgs.isNotEmpty()) list.scrollToPosition(msgs.size - 1)
        Chats.clearUnread(this, code)
    }

    private fun sendText() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        api.call(this, "POST", "/api/dm/send", JSONObject().put("to", code).put("text", t)) { r ->
            if (r.ok) {
                Chats.append(this, code, Chats.Msg(r.json?.optString("id").orEmpty().ifEmpty { UUID.randomUUID().toString() }, true, "text", t, 0, System.currentTimeMillis()))
                render()
            } else {
                input.setText(t)
                toast(getString(errorText(r.status, r.error)))
            }
        }
    }

    /** Mantén pulsado un mensaje: eliminar para mí o (si es tuyo) para todos. */
    private fun askDelete(b: Bubble) {
        val opts = mutableListOf(getString(R.string.delete_for_me))
        if (b.mine) opts += getString(R.string.delete_for_all)
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.delete_msg_title)
            .setItems(opts.toTypedArray()) { _, which ->
                if (which == 0) {
                    removeLocal(b)
                } else {
                    api.call(this, "POST", "/api/dm/delete", JSONObject().put("to", code).put("id", b.id)) { r ->
                        if (r.ok) removeLocal(b) else toast(getString(R.string.delete_failed))
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun removeLocal(b: Bubble) {
        if (adapter.playingId == b.id) {
            player.stop()
            adapter.playingId = null
        }
        Chats.delete(this, code, b.id)
        render()
    }

    private fun errorText(status: Int, err: String?) = when {
        status == 0 -> R.string.recover_offline
        err == "not_friends" -> R.string.chat_not_friends
        else -> R.string.voice_failed
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startRecording() {
        if (recorder?.active == true) return
        if (!hasMic()) {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        player.stop()
        val rec = VoiceMail.Recorder { data, ms ->
            runOnUiThread {
                recorder = null
                recHint.visibility = View.GONE
                if (ms < 700 || data.isEmpty()) {
                    toast(getString(R.string.voice_too_short))
                } else {
                    api.bytes(this, "POST", "/api/voice/send?to=$code&dur=$ms", data) { status, resp ->
                        if (status == 200) {
                            val sid = try {
                                JSONObject(String(resp ?: ByteArray(0))).optString("id")
                            } catch (e: Exception) {
                                ""
                            }
                            val id = sid.ifEmpty { UUID.randomUUID().toString() }
                            try {
                                Chats.audioFile(this, id).writeBytes(data)
                                Chats.append(this, code, Chats.Msg(id, true, "voice", "", ms, System.currentTimeMillis()))
                            } catch (e: Exception) {
                                // no se pudo guardar la copia local; el mensaje sí se envió
                            }
                            render()
                        } else {
                            toast(getString(errorText(status, if (status == 403) "not_friends" else null)))
                        }
                    }
                }
            }
        }
        if (rec.start()) {
            recorder = rec
            recHint.visibility = View.VISIBLE
        } else {
            toast(getString(R.string.mic_needed))
        }
    }

    private fun stopRecording() {
        recorder?.stop()
    }

    // ---- Efecto al grabar (como WhatsApp): sonido, vibración, botón que crece y temporizador

    private var pressing = false
    private var pulse: android.animation.ObjectAnimator? = null
    private var recStart = 0L
    private var tone: android.media.ToneGenerator? = null
    private val startRec = Runnable { if (pressing) startRecording() }
    private val tick = object : Runnable {
        override fun run() {
            val sec = ((System.currentTimeMillis() - recStart) / 1000).toInt()
            val dot = if ((System.currentTimeMillis() / 500) % 2 == 0L) "●" else "○"
            recHint.text = String.format("%s %d:%02d  %s", dot, sec / 60, sec % 60, getString(R.string.chat_recording))
            handler.postDelayed(this, 250)
        }
    }

    private fun beep(kind: Int) {
        try {
            if (tone == null) tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 70)
            tone?.startTone(kind, 90)
        } catch (e: Exception) {
            // sin sonido
        }
    }

    private fun buzz(ms: Long) {
        try {
            @Suppress("DEPRECATION")
            val vib = getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                vib.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(ms)
            }
        } catch (e: Exception) {
            // sin vibración
        }
    }

    private fun pressStart() {
        if (pressing) return
        pressing = true
        buzz(25)
        beep(android.media.ToneGenerator.TONE_PROP_BEEP)
        action.animate().cancel()
        action.animate().scaleX(1.5f).scaleY(1.5f).setDuration(160).withEndAction {
            if (pressing) {
                pulse = android.animation.ObjectAnimator.ofPropertyValuesHolder(
                    action,
                    android.animation.PropertyValuesHolder.ofFloat("scaleX", 1.5f, 1.75f),
                    android.animation.PropertyValuesHolder.ofFloat("scaleY", 1.5f, 1.75f)
                ).apply {
                    duration = 550
                    repeatCount = android.animation.ValueAnimator.INFINITE
                    repeatMode = android.animation.ValueAnimator.REVERSE
                    start()
                }
            }
        }.start()
        recStart = System.currentTimeMillis()
        recHint.visibility = View.VISIBLE
        handler.removeCallbacks(tick)
        handler.post(tick)
        // El micrófono arranca tras el pitido para que no quede grabado
        handler.postDelayed(startRec, 200)
    }

    private fun pressEnd() {
        if (!pressing) return
        pressing = false
        handler.removeCallbacks(startRec)
        handler.removeCallbacks(tick)
        pulse?.cancel()
        pulse = null
        action.animate().cancel()
        action.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        buzz(15)
        stopRecording()
        if (recorder == null) recHint.visibility = View.GONE
        handler.postDelayed({ beep(android.media.ToneGenerator.TONE_PROP_ACK) }, 150)
    }

    private fun playBubble(b: Bubble) {
        if (adapter.playingId == b.id) {
            player.stop()
            adapter.playingId = null
            return
        }
        val f = Chats.audioFile(this, b.id)
        if (!f.exists()) {
            toast(getString(R.string.voice_failed))
            return
        }
        adapter.playingId = b.id
        player.play(f.readBytes()) {
            runOnUiThread { if (adapter.playingId == b.id) adapter.playingId = null }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
