package app.walkie.ptt

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Taller Wavko: se ve el personaje en grande, se cambia cada pieza por separado (skin, sombrero, antena,
 * rostro, ropa, accesorio y calzado) y se guardan combinaciones en "Mis personajes".
 */
class TallerActivity : AppCompatActivity() {

    // Zona de cada miniatura (espacio de diseño del personaje, 200 x 350)
    private val regions = arrayOf(
        floatArrayOf(14f, 20f, 186f, 262f),   // skin
        floatArrayOf(30f, 14f, 170f, 124f),   // sombrero
        floatArrayOf(40f, 0f, 190f, 130f),    // antena
        floatArrayOf(46f, 104f, 154f, 190f),  // rostro
        floatArrayOf(30f, 164f, 170f, 284f),  // ropa
        floatArrayOf(10f, 60f, 190f, 270f),   // accesorios
        floatArrayOf(30f, 262f, 170f, 332f)   // calzado
    )

    private lateinit var preview: WalkieView
    private lateinit var tabs: LinearLayout
    private lateinit var optionsView: RecyclerView
    private lateinit var charsView: RecyclerView
    private lateinit var current: TextView
    private lateinit var nameLabel: TextView
    private lateinit var btnRename: View
    private lateinit var btnDelete: View
    private lateinit var note: View

    private var work = Avatar.DEFAULT       // lo que se ve en la vista previa
    private var hero: Hero = Hero("", "Wavko", Avatar.DEFAULT, false)  // personaje en uso
    private var part = Avatar.SKIN
    private var dirty = false

    private lateinit var optionsAdapter: OptionsAdapter
    private lateinit var charsAdapter: CharsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_taller)

        preview = findViewById(R.id.tallerPreview)
        tabs = findViewById(R.id.tallerTabs)
        optionsView = findViewById(R.id.tallerOptions)
        charsView = findViewById(R.id.tallerChars)
        current = findViewById(R.id.tallerCurrent)
        nameLabel = findViewById(R.id.tallerName)
        btnRename = findViewById(R.id.btnTallerRename)
        btnDelete = findViewById(R.id.btnTallerDelete)
        note = findViewById(R.id.tallerNote)

        preview.full = true
        preview.animated = true
        preview.turnable = true

        hero = Characters.selected(this)
        work = hero.avatar

        optionsAdapter = OptionsAdapter()
        optionsView.layoutManager = GridLayoutManager(this, 4)
        optionsView.adapter = optionsAdapter

        charsAdapter = CharsAdapter()
        charsView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        charsView.adapter = charsAdapter

        buildTabs()

        findViewById<View>(R.id.tallerBack).setOnClickListener { leave() }
        findViewById<View>(R.id.btnTallerReset).setOnClickListener {
            work = hero.avatar
            dirty = false
            refresh()
        }
        findViewById<View>(R.id.btnTallerSave).setOnClickListener { save() }
        btnRename.setOnClickListener { askName(hero.name) { n -> rename(n) } }
        btnDelete.setOnClickListener { confirmDelete() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = leave()
        })
        refresh()
    }

    // ---------------------------------------------------------------- Categorías y piezas

    private fun buildTabs() {
        val d = resources.displayMetrics.density
        for (p in 0 until Avatar.PARTS) {
            val t = TextView(this)
            t.text = getString(AvatarCatalog.CAT_TITLES[p])
            t.textSize = 14f
            t.setTextColor(0xFFFFFFFF.toInt())
            t.typeface = android.graphics.Typeface.DEFAULT_BOLD
            t.gravity = android.view.Gravity.CENTER
            t.setPadding((16 * d).toInt(), 0, (16 * d).toInt(), 0)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (42 * d).toInt())
            lp.marginEnd = (8 * d).toInt()
            t.layoutParams = lp
            t.setOnClickListener {
                part = p
                refresh()
            }
            tabs.addView(t)
        }
    }

    private fun refresh() {
        preview.setAvatar(work)
        for (p in 0 until tabs.childCount) {
            tabs.getChildAt(p).setBackgroundResource(if (p == part) R.drawable.bg_tab_sel else R.drawable.bg_tab)
        }
        val chosen = Avatar.get(work, part)
        current.text = getString(AvatarCatalog.CAT_TITLES[part]) + " · " + getString(AvatarCatalog.NAMES[part][chosen])
        nameLabel.text = hero.name
        val own = hero.id.isNotEmpty() && !hero.preset
        btnRename.visibility = if (own) View.VISIBLE else View.GONE
        btnDelete.visibility = if (own) View.VISIBLE else View.GONE
        note.visibility = if (hero.preset) View.VISIBLE else View.GONE
        optionsAdapter.notifyDataSetChanged()
        charsAdapter.reload()
    }

    private inner class OptionsAdapter : RecyclerView.Adapter<OptionsAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val thumb: WalkieView = v.findViewById(R.id.optThumb)
            val name: TextView = v.findViewById(R.id.optName)
            val check: View = v.findViewById(R.id.optCheck)
            val lock: View = v.findViewById(R.id.optLock)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_taller_option, parent, false))

        override fun getItemCount() = Avatar.COUNTS[part]

        override fun onBindViewHolder(h: VH, i: Int) {
            val r = regions[part]
            h.thumb.setRegion(r[0], r[1], r[2], r[3])
            h.thumb.setAvatar(Avatar.set(work, part, i))
            h.name.text = getString(AvatarCatalog.NAMES[part][i])
            val sel = Avatar.get(work, part) == i
            h.check.visibility = if (sel) View.VISIBLE else View.GONE
            h.itemView.setBackgroundResource(if (sel) R.drawable.bg_panel_sel else R.drawable.bg_panel)
            val open = Unlocks.isUnlocked(this@TallerActivity, part, i)
            h.lock.visibility = if (open) View.GONE else View.VISIBLE
            h.itemView.alpha = if (open) 1f else 0.55f
            h.itemView.setOnClickListener {
                if (!open) {
                    Toast.makeText(this@TallerActivity, R.string.char_locked, Toast.LENGTH_SHORT).show()
                } else {
                    work = Avatar.set(work, part, i)
                    dirty = work != hero.avatar
                    refresh()
                }
            }
        }
    }

    // ---------------------------------------------------------------- Mis personajes

    private inner class CharsAdapter : RecyclerView.Adapter<CharsAdapter.VH>() {
        private var items: List<Hero> = emptyList()

        fun reload() {
            items = Characters.all(this@TallerActivity)
            notifyDataSetChanged()
        }

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val thumb: WalkieView = v.findViewById(R.id.chThumb)
            val plus: View = v.findViewById(R.id.chPlus)
            val name: TextView = v.findViewById(R.id.chName)
            val check: View = v.findViewById(R.id.chCheck)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_taller_char, parent, false))

        override fun getItemCount() = items.size + 1

        override fun onBindViewHolder(h: VH, i: Int) {
            if (i == items.size) {
                h.thumb.visibility = View.GONE
                h.plus.visibility = View.VISIBLE
                h.check.visibility = View.GONE
                h.name.text = getString(R.string.btn_new_char)
                h.itemView.setBackgroundResource(R.drawable.bg_panel)
                h.itemView.setOnClickListener { createNew() }
                return
            }
            val c = items[i]
            h.thumb.visibility = View.VISIBLE
            h.plus.visibility = View.GONE
            h.thumb.setAvatar(c.avatar)
            h.name.text = c.name
            val sel = c.id == hero.id
            h.check.visibility = if (sel) View.VISIBLE else View.GONE
            h.itemView.setBackgroundResource(if (sel) R.drawable.bg_panel_sel else R.drawable.bg_panel)
            h.itemView.setOnClickListener { use(c) }
        }
    }

    /** Cambia de personaje: pasa a ser el que ven tus amigos y el canal. */
    private fun use(c: Hero) {
        hero = c
        work = c.avatar
        dirty = false
        Characters.select(this, c)
        setResult(RESULT_OK)
        refresh()
    }

    private fun createNew() {
        if (Characters.custom(this).size >= Characters.MAX_CUSTOM) {
            Toast.makeText(this, R.string.char_limit, Toast.LENGTH_LONG).show()
            return
        }
        askName("") { n ->
            val h = Characters.add(this, n, Avatar.DEFAULT)
            if (h != null) use(h)
        }
    }

    private fun save() {
        if (hero.id.isNotEmpty() && !hero.preset) {
            val h = Characters.update(this, hero.id, work)
            if (h != null) {
                hero = h
                Characters.select(this, h)
                finishSave()
                return
            }
        }
        // Personaje de la colección (o sin guardar aún): se crea una copia propia
        if (Characters.custom(this).size >= Characters.MAX_CUSTOM) {
            Toast.makeText(this, R.string.char_limit, Toast.LENGTH_LONG).show()
            return
        }
        askName(if (hero.preset) hero.name + " 2" else "") { n ->
            val h = Characters.add(this, n, work)
            if (h != null) {
                hero = h
                Characters.select(this, h)
                finishSave()
            }
        }
    }

    private fun finishSave() {
        dirty = false
        work = hero.avatar
        setResult(RESULT_OK)
        Toast.makeText(this, R.string.char_saved, Toast.LENGTH_SHORT).show()
        refresh()
    }

    private fun rename(n: String) {
        Characters.rename(this, hero.id, n)
        hero = Characters.all(this).firstOrNull { it.id == hero.id } ?: hero
        refresh()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_delete_char)
            .setMessage(R.string.char_delete_msg)
            .setPositiveButton(R.string.btn_delete_char) { _, _ ->
                Characters.delete(this, hero.id)
                hero = Characters.selected(this)
                work = hero.avatar
                dirty = false
                setResult(RESULT_OK)
                refresh()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun askName(initial: String, onOk: (String) -> Unit) {
        val input = EditText(this)
        input.setText(initial)
        input.hint = getString(R.string.char_name_hint)
        input.setSingleLine()
        input.filters = arrayOf(android.text.InputFilter.LengthFilter(20))
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = android.widget.FrameLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle(R.string.char_name_title)
            .setView(box)
            .setPositiveButton(R.string.btn_accept) { _, _ -> onOk(input.text.toString()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun leave() {
        if (!dirty) {
            finish()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.char_unsaved_title)
            .setMessage(R.string.char_unsaved_msg)
            .setPositiveButton(R.string.btn_save_char) { _, _ -> save() }
            .setNegativeButton(R.string.btn_discard) { _, _ -> finish() }
            .setNeutralButton(R.string.cancel, null)
            .show()
    }
}
