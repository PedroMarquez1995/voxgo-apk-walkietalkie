package app.walkie.ptt

import android.graphics.Color

/** Colores de un walkie-talkie. El número de skin (posición en [Skins.all]) es lo que se guarda y se comparte. */
data class Skin(
    val body: Int,
    val bodyDark: Int,
    val accent: Int,
    val screen: Int,
    val detail: Int
)

object Skins {
    private fun c(s: String) = Color.parseColor(s)

    val all: List<Skin> = listOf(
        Skin(c("#8B5CF6"), c("#5B21B6"), c("#F5D0FE"), c("#1E1B4B"), c("#3B0764")),
        Skin(c("#334155"), c("#0F172A"), c("#22D3EE"), c("#020617"), c("#475569")),
        Skin(c("#65A30D"), c("#365314"), c("#ECFCCB"), c("#1A2E05"), c("#3F6212")),
        Skin(c("#FDE68A"), c("#F59E0B"), c("#DC2626"), c("#78350F"), c("#B45309")),
        Skin(c("#0EA5E9"), c("#0369A1"), c("#FFFFFF"), c("#082F49"), c("#075985")),
        Skin(c("#F43F5E"), c("#9F1239"), c("#FED7AA"), c("#4C0519"), c("#BE123C")),
        Skin(c("#F9A8D4"), c("#DB2777"), c("#FFFFFF"), c("#500724"), c("#BE185D")),
        Skin(c("#27272A"), c("#09090B"), c("#A78BFA"), c("#000000"), c("#3F3F46")),
        Skin(c("#2DD4BF"), c("#0F766E"), c("#F0FDFA"), c("#042F2E"), c("#115E59")),
        Skin(c("#FACC15"), c("#A16207"), c("#422006"), c("#1C1917"), c("#CA8A04")),
        Skin(c("#BAE6FD"), c("#38BDF8"), c("#0C4A6E"), c("#082F49"), c("#7DD3FC")),
        Skin(c("#FB923C"), c("#C2410C"), c("#FEF3C7"), c("#431407"), c("#EA580C")),
        Skin(c("#4C1D95"), c("#1E1B4B"), c("#F0ABFC"), c("#0B0720"), c("#6D28D9")),
        Skin(c("#A3E635"), c("#4D7C0F"), c("#1A2E05"), c("#1A2E05"), c("#65A30D")),
        Skin(c("#CBD5E1"), c("#64748B"), c("#0F172A"), c("#0F172A"), c("#94A3B8")),
        Skin(c("#1D4ED8"), c("#1E3A8A"), c("#FDE047"), c("#0B1437"), c("#2563EB"))
    )

    fun get(id: Int): Skin = all[if (id in all.indices) id else 0]
}
