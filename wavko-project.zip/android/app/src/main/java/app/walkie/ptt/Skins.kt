package app.walkie.ptt

import android.graphics.Color

/** Colores de un walkie-talkie. El número de skin (posición en [Skins.all]) es lo que se guarda y se comparte. */
data class Skin(
    val name: String,
    val body: Int,
    val bodyDark: Int,
    val accent: Int,
    val screen: Int,
    val detail: Int
)

object Skins {
    private fun c(s: String) = Color.parseColor(s)

    val all: List<Skin> = listOf(
        Skin("Violeta", c("#8B5CF6"), c("#5B21B6"), c("#F5D0FE"), c("#1E1B4B"), c("#3B0764")),
        Skin("Neón", c("#334155"), c("#0F172A"), c("#22D3EE"), c("#020617"), c("#475569")),
        Skin("Militar", c("#65A30D"), c("#365314"), c("#ECFCCB"), c("#1A2E05"), c("#3F6212")),
        Skin("Retro", c("#FDE68A"), c("#F59E0B"), c("#DC2626"), c("#78350F"), c("#B45309")),
        Skin("Océano", c("#0EA5E9"), c("#0369A1"), c("#FFFFFF"), c("#082F49"), c("#075985")),
        Skin("Fuego", c("#F43F5E"), c("#9F1239"), c("#FED7AA"), c("#4C0519"), c("#BE123C")),
        Skin("Rosa", c("#F9A8D4"), c("#DB2777"), c("#FFFFFF"), c("#500724"), c("#BE185D")),
        Skin("Noche", c("#27272A"), c("#09090B"), c("#A78BFA"), c("#000000"), c("#3F3F46"))
    )

    fun get(id: Int): Skin = all[if (id in all.indices) id else 0]
}
