plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Notificaciones push (opcional): solo se activan si existe app/google-services.json
// (el workflow lo crea desde el secret GOOGLE_SERVICES_JSON). Sin él la app compila igual.
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
}

// Valores por defecto de la app. Se pueden cambiar al compilar con las variables de
// entorno WAVKO_SERVER y WAVKO_KEY (en GitHub: variable WAVKO_SERVER y secret ACCESS_KEY).
fun buildString(v: String) = "\"" + v.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
val defaultServer = (System.getenv("WAVKO_SERVER") ?: System.getenv("VOXGO_SERVER"))?.trim()?.takeIf { it.isNotEmpty() }
    ?: "wss://voxgo.pedroxhile.workers.dev"
val defaultKey = System.getenv("WAVKO_KEY") ?: System.getenv("VOXGO_KEY") ?: ""

android {
    namespace = "app.walkie.ptt"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.wavko"
        minSdk = 26
        targetSdk = 34
        versionCode = 13
        versionName = "3.1"

        buildConfigField("String", "DEFAULT_SERVER", buildString(defaultServer))
        buildConfigField("String", "DEFAULT_KEY", buildString(defaultKey))
        buildConfigField("String", "UPDATE_REPO", buildString((System.getenv("GITHUB_REPOSITORY") ?: "").trim()))
        buildConfigField("String", "GOOGLE_CLIENT_ID", buildString((System.getenv("GOOGLE_CLIENT_ID") ?: "").trim()))
    }

    buildFeatures {
        buildConfig = true
    }

    // Firma fija: si existe app/wavko.keystore (el workflow lo crea desde secretos) se usa SIEMPRE la misma
    // clave, requisito para actualizar encima de una versión anterior y para el acceso con Google.
    val ks = file("wavko.keystore")
    if (ks.exists()) {
        signingConfigs {
            getByName("debug") {
                storeFile = ks
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS") ?: "wavko"
                keyPassword = System.getenv("KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    implementation("com.google.firebase:firebase-messaging")
}
