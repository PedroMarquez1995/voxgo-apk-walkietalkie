/**
 * Wavko - Comunicación por voz en movimiento (Cloudflare Workers + Durable Objects).
 *
 * - El Worker recibe la conexión WebSocket en  wss://<tu-worker>/?channel=<canal>
 *   y la envía al Durable Object de ese canal (uno por canal).
 * - El Durable Object usa la API de hibernación: si el canal está en silencio,
 *   no consume tiempo de cómputo y las conexiones siguen abiertas.
 * - Un solo hablante por canal a la vez (control de turno).
 * - Un canal existe mientras tenga al menos una persona dentro. Quien lo crea puede
 *   ponerle clave; cuando sale la última persona, el canal y su clave desaparecen.
 *
 * Protocolo (texto JSON):
 *  cliente -> servidor: {type:"join", mode:"create"|"join"|"resume", name, key, pass, skin}
 *                       {type:"ptt", on:true|false}
 *  servidor -> cliente: {type:"joined", channel, users:[...], skins:{nombre:n}, you, created}
 *                       {type:"users", users:[...], skins:{nombre:n}}
 *                       {type:"granted"} | {type:"busy", by}
 *                       {type:"talking", name|null}
 *                       {type:"released"}   (tiempo máximo de turno)
 *                       {type:"error", code, message}
 *                         code: bad_key | not_found | exists | bad_pass
 * Binario: chunks de audio G.711 µ-law, 16 kHz, mono (640 bytes = 40 ms).
 *
 * mode "resume" (reconexiones y clientes antiguos sin mode): si el canal existe se une
 * (con la clave dada); si no existe, lo crea con esa clave.
 *
 * Amigos / presencia: wss://<tu-worker>/presence  (un único Durable Object global)
 *  cliente -> servidor: {type:"hello", code, name, skin, inChannel, watch:[codigos], key}
 *  servidor -> cliente: {type:"status", friends:[{code, online, name?, skin?, inChannel?}]}
 * Quien conozca el código de otra persona puede ver si está en línea (como un nombre de usuario).
 */
import { DurableObject } from "cloudflare:workers";

const MAX_TALK_MS = 60_000; // tiempo máximo por turno
const STALE_MS = 3_000; // si el hablante no manda audio en este tiempo, otro puede tomar el turno

function cleanChannel(v) {
  return String(v || "").toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 32) || "general";
}

function cleanName(v) {
  return String(v || "").replace(/[\u0000-\u001f]/g, "").trim().slice(0, 24) || "Anonimo";
}

function cleanSkin(v) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) && n >= 0 && n <= 15 ? n : 0;
}

function cleanCode(v) {
  const c = String(v || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  return c.length >= 4 && c.length <= 12 ? c : "";
}

function cleanPass(v) {
  return String(v ?? "").slice(0, 64);
}

function sendJson(ws, obj) {
  try {
    ws.send(JSON.stringify(obj));
  } catch (e) {
    // socket ya cerrado
  }
}

function toHex(buf) {
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function hashPass(pass, salt) {
  const data = new TextEncoder().encode(salt + ":" + pass);
  return toHex(await crypto.subtle.digest("SHA-256", data));
}

async function makeAuth(pass) {
  const salt = toHex(crypto.getRandomValues(new Uint8Array(16)));
  return { salt, hash: await hashPass(pass, salt) };
}

function sameStr(a, b) {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/health") return new Response("ok");

    if (url.pathname === "/presence") {
      if (request.headers.get("Upgrade") !== "websocket") {
        return new Response("Expected WebSocket", { status: 426 });
      }
      return env.PRESENCE.get(env.PRESENCE.idFromName("global")).fetch(request);
    }

    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("Wavko server\n", {
        headers: { "content-type": "text/plain; charset=utf-8" },
      });
    }

    const channel = cleanChannel(url.searchParams.get("channel"));
    const stub = env.CHANNEL.get(env.CHANNEL.idFromName(channel));
    return stub.fetch(request);
  },
};

export class Channel extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    // Estado del turno. Solo vive mientras el objeto está en memoria; si hibernó
    // es porque nadie estaba hablando, así que empezar en null es correcto.
    this.talkerId = null;
    this.talkerName = null;
    this.talkStart = 0;
    this.lastAudio = 0;
  }

  async fetch(request) {
    const url = new URL(request.url);
    const [client, server] = Object.values(new WebSocketPair());
    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({
      id: crypto.randomUUID(),
      name: "Anonimo",
      skin: 0,
      joined: false,
      channel: cleanChannel(url.searchParams.get("channel")),
    });
    return new Response(null, { status: 101, webSocket: client });
  }

  // ------------------------------------------------------------ helpers

  /** Sockets que ya entraron al canal (excepto el de id `exceptId`). */
  _members(exceptId) {
    const out = [];
    for (const ws of this.ctx.getWebSockets()) {
      const a = ws.deserializeAttachment();
      if (a && a.joined && a.id !== exceptId) out.push({ ws, a });
    }
    return out;
  }

  _users(exceptId) {
    return this._members(exceptId).map((m) => m.a.name);
  }

  /** {nombre: skin} de los miembros (excepto `exceptId`). */
  _skins(exceptId) {
    const out = {};
    for (const m of this._members(exceptId)) out[m.a.name] = m.a.skin || 0;
    return out;
  }

  _find(id) {
    for (const ws of this.ctx.getWebSockets()) {
      const a = ws.deserializeAttachment();
      if (a && a.id === id) return ws;
    }
    return null;
  }

  /** Si el nombre ya está en uso en el canal, añade (2), (3)... */
  _uniqueName(base) {
    const taken = new Set(this._users(null));
    if (!taken.has(base)) return base;
    let i = 2;
    while (taken.has(`${base} (${i})`)) i++;
    return `${base} (${i})`;
  }

  _release(id) {
    if (this.talkerId !== id) return;
    this.talkerId = null;
    this.talkerName = null;
    for (const m of this._members(id)) sendJson(m.ws, { type: "talking", name: null });
  }

  _deny(ws, code, message) {
    sendJson(ws, { type: "error", code, message });
    try {
      ws.close(4003, code);
    } catch (e) {
      // ya cerrado
    }
  }

  async _gone(ws) {
    const me = ws.deserializeAttachment();
    if (!me) return;
    this._release(me.id);
    if (!me.joined) return;
    const others = this._members(me.id);
    if (others.length === 0) {
      // Salió la última persona: el canal deja de existir (se borra también su clave)
      this.talkerId = null;
      this.talkerName = null;
      try {
        await this.ctx.storage.deleteAll();
      } catch (e) {
        // sin almacenamiento que borrar
      }
      return;
    }
    const msg = { type: "users", users: this._users(me.id), skins: this._skins(me.id) };
    for (const m of others) sendJson(m.ws, msg);
  }

  async _join(ws, me, msg) {
    if (me.joined) return;

    const key = this.env.ACCESS_KEY;
    if (key && msg.key !== key) {
      return this._deny(ws, "bad_key", "Clave del servidor incorrecta");
    }

    const name = cleanName(msg.name);
    const pass = cleanPass(msg.pass);
    const mode = msg.mode === "create" || msg.mode === "join" ? msg.mode : "resume";
    const exists = this._members(null).length > 0;

    let created = false;
    let authRec = null;

    if (mode === "create" || (mode === "resume" && !exists)) {
      if (exists) {
        return this._deny(ws, "exists", "Ese canal ya existe. Elige otro nombre o usa «Unirme a canal»");
      }
      if (pass) authRec = await makeAuth(pass); // asíncrono: puede intercalarse otra conexión
      // Sección síncrona: comprobar de nuevo y reclamar el canal sin ceder el turno
      if (this._members(null).length > 0) {
        return this._deny(ws, "exists", "Ese canal ya existe. Elige otro nombre o usa «Unirme a canal»");
      }
      created = true;
    } else {
      if (!exists) {
        return this._deny(ws, "not_found", "Ese canal no existe. Revisa el nombre o crea uno nuevo");
      }
      const auth = await this.ctx.storage.get("auth");
      if (auth && auth.hash) {
        const ok = pass !== "" && sameStr(await hashPass(pass, auth.salt), auth.hash);
        if (!ok) return this._deny(ws, "bad_pass", "Clave del canal incorrecta");
      }
      if (this._members(null).length === 0) {
        // el canal se vació mientras comprobábamos la clave
        return this._deny(ws, "not_found", "Ese canal no existe. Revisa el nombre o crea uno nuevo");
      }
    }

    me.name = this._uniqueName(name);
    me.skin = cleanSkin(msg.skin);
    me.joined = true;
    ws.serializeAttachment(me);

    if (created) {
      if (authRec) await this.ctx.storage.put("auth", authRec);
      else await this.ctx.storage.delete("auth");
    }

    const users = this._users(null);
    const skins = this._skins(null);
    sendJson(ws, { type: "joined", channel: me.channel, users, skins, you: me.name, created });
    for (const m of this._members(me.id)) sendJson(m.ws, { type: "users", users, skins });
    if (this.talkerId && this.talkerId !== me.id) {
      sendJson(ws, { type: "talking", name: this.talkerName });
    }
  }

  // ----------------------------------------------------------- mensajes

  async webSocketMessage(ws, message) {
    const me = ws.deserializeAttachment();
    if (!me) return;

    // --- Audio (binario) ---
    if (typeof message !== "string") {
      if (!me.joined || this.talkerId !== me.id) return; // solo el que tiene el turno
      const now = Date.now();
      if (now - this.talkStart > MAX_TALK_MS) {
        this._release(me.id);
        sendJson(ws, { type: "released" });
        return;
      }
      this.lastAudio = now;
      for (const m of this._members(me.id)) {
        try {
          m.ws.send(message);
        } catch (e) {
          // el receptor se cayó; su evento de cierre lo limpiará
        }
      }
      return;
    }

    // --- Control (JSON) ---
    let msg;
    try {
      msg = JSON.parse(message);
    } catch (e) {
      return;
    }
    if (!msg || typeof msg !== "object") return;

    if (msg.type === "join") {
      await this._join(ws, me, msg);
      return;
    }

    if (msg.type === "ptt" && me.joined) {
      if (!msg.on) {
        this._release(me.id);
        return;
      }
      const now = Date.now();
      if (this.talkerId && this.talkerId !== me.id) {
        const last = Math.max(this.talkStart, this.lastAudio);
        if (now - last < STALE_MS) {
          sendJson(ws, { type: "busy", by: this.talkerName });
          return;
        }
        // El hablante anterior quedó colgado: le quitamos el turno
        const oldId = this.talkerId;
        this._release(oldId);
        const old = this._find(oldId);
        if (old) sendJson(old, { type: "released" });
      }
      if (this.talkerId === me.id) {
        sendJson(ws, { type: "granted" });
        return;
      }
      this.talkerId = me.id;
      this.talkerName = me.name;
      this.talkStart = now;
      this.lastAudio = now;
      sendJson(ws, { type: "granted" });
      for (const m of this._members(me.id)) sendJson(m.ws, { type: "talking", name: me.name });
    }
  }

  async webSocketClose(ws, code, reason, wasClean) {
    await this._gone(ws);
    try {
      // 1005/1006/1015 no se pueden enviar en un frame de cierre
      ws.close(code === 1005 || code === 1006 || code === 1015 ? 1000 : code, "bye");
    } catch (e) {
      // ya cerrado
    }
  }

  async webSocketError(ws, error) {
    await this._gone(ws);
  }
}

/**
 * Presencia global para la lista de amigos. Cada cliente abre un WebSocket y manda "hello"
 * con su código, nombre, skin y la lista de códigos que quiere vigilar. El servidor responde con
 * el estado de esos códigos y avisa cuando cambian. No guarda nada: todo vive en las conexiones.
 */
export class Presence extends DurableObject {
  async fetch(request) {
    const [client, server] = Object.values(new WebSocketPair());
    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({ hello: false, code: "", name: "", skin: 0, inChannel: false, watch: [] });
    return new Response(null, { status: 101, webSocket: client });
  }

  /** Estado de un código; `except` es un socket que se está cerrando y no debe contar. */
  _entry(code, except) {
    let found = null;
    let inChannel = false;
    for (const ws of this.ctx.getWebSockets()) {
      if (ws === except) continue;
      const a = ws.deserializeAttachment();
      if (a && a.hello && a.code === code) {
        found = a;
        if (a.inChannel) inChannel = true;
      }
    }
    return found
      ? { code, online: true, name: found.name, skin: found.skin, inChannel }
      : { code, online: false };
  }

  _notify(code, except) {
    const entry = this._entry(code, except);
    for (const ws of this.ctx.getWebSockets()) {
      if (ws === except) continue;
      const a = ws.deserializeAttachment();
      if (a && a.hello && a.watch.includes(code)) sendJson(ws, { type: "status", friends: [entry] });
    }
  }

  /** Invitación a un canal: solo llega a quien tiene al remitente en su lista de amigos. */
  _invite(ws, msg) {
    const me = ws.deserializeAttachment();
    if (!me || !me.hello) return;
    const to = cleanCode(msg.to);
    const channel = typeof msg.channel === "string" ? msg.channel.trim().slice(0, 64) : "";
    if (!to || to === me.code || !channel) return;
    const pass = typeof msg.pass === "string" ? msg.pass.slice(0, 64) : "";
    let delivered = 0;
    for (const other of this.ctx.getWebSockets()) {
      const a = other.deserializeAttachment();
      if (a && a.hello && a.code === to && a.watch.includes(me.code)) {
        sendJson(other, { type: "invite", from: me.code, name: me.name, skin: me.skin, channel, pass });
        delivered++;
      }
    }
    sendJson(ws, { type: "invite_result", to, delivered });
  }

  async webSocketMessage(ws, message) {
    if (typeof message !== "string") return;
    let msg;
    try {
      msg = JSON.parse(message);
    } catch (e) {
      return;
    }
    if (!msg) return;
    if (msg.type === "invite") {
      this._invite(ws, msg);
      return;
    }
    if (msg.type !== "hello") return;

    const key = this.env.ACCESS_KEY;
    if (key && msg.key !== key) {
      sendJson(ws, { type: "error", code: "bad_key", message: "Clave del servidor incorrecta" });
      try {
        ws.close(4003, "bad_key");
      } catch (e) {
        // ya cerrado
      }
      return;
    }

    const code = cleanCode(msg.code);
    if (!code) return;
    const watch = (Array.isArray(msg.watch) ? msg.watch : [])
      .map(cleanCode)
      .filter((c) => c && c !== code)
      .slice(0, 60);
    ws.serializeAttachment({
      hello: true,
      code,
      name: cleanName(msg.name),
      skin: cleanSkin(msg.skin),
      inChannel: !!msg.inChannel,
      watch,
    });

    sendJson(ws, { type: "status", friends: watch.map((c) => this._entry(c, null)) });
    this._notify(code, null);
  }

  async webSocketClose(ws, code, reason, wasClean) {
    const a = ws.deserializeAttachment();
    if (a && a.hello) this._notify(a.code, ws);
    try {
      ws.close(code === 1005 || code === 1006 || code === 1015 ? 1000 : code, "bye");
    } catch (e) {
      // ya cerrado
    }
  }

  async webSocketError(ws, error) {
    const a = ws.deserializeAttachment();
    if (a && a.hello) this._notify(a.code, ws);
  }
}
