/**
 * Wavko - Comunicación por voz en movimiento (Cloudflare Workers + Durable Objects).
 *
 * - El Worker recibe la conexión WebSocket en  wss://<tu-worker>/?channel=<canal>
 *   y la envía al Durable Object de ese canal (uno por canal).
 * - El Durable Object usa la API de hibernación: si el canal está en silencio,
 *   no consume tiempo de cómputo y las conexiones siguen abiertas.
 * - Un solo hablante por canal a la vez (control de turno).
 * - Un canal existe mientras tenga al menos una persona dentro. Quien lo crea puede
 *   ponerle clave; cuando sale la última persona, el canal y su clave desaparecen.
 *
 * Protocolo (texto JSON):
 *  cliente -> servidor: {type:"join", mode:"create"|"join"|"resume", name, key, pass, skin}
 *                       {type:"ptt", on:true|false}
 *  servidor -> cliente: {type:"joined", channel, users:[...], skins:{nombre:n}, you, created}
 *                       {type:"users", users:[...], skins:{nombre:n}}
 *                       {type:"granted"} | {type:"busy", by}
 *                       {type:"talking", name|null}
 *                       {type:"released"}   (tiempo máximo de turno)
 *                       {type:"error", code, message}
 *                         code: bad_key | not_found | exists | bad_pass
 * Binario: chunks de audio G.711 µ-law, 16 kHz, mono (640 bytes = 40 ms).
 *
 * mode "resume" (reconexiones y clientes antiguos sin mode): si el canal existe se une
 * (con la clave dada); si no existe, lo crea con esa clave.
 *
 * Cuentas (HTTP, JSON) — un Durable Object `Account` por cuenta:
 *  POST /api/register {name, skin, code?}        -> {code, token, recovery}
 *  POST /api/recover  {code, recovery}           -> {token, name, skin}
 *  (con "Authorization: Bearer CODIGO.TOKEN")
 *  GET  /api/me                                  -> perfil, amigos, solicitudes y bloqueados
 *  POST /api/profile {name, skin}
 *  POST /api/friends/add {code} | /respond {code, accept} | /remove {code}
 *  POST /api/block {code} | /unblock {code}
 *  POST /api/google/login {idToken} -> {code, token, name, skin} | POST /api/google/link {idToken} | /unlink
 *     (opcional: requiere la variable GOOGLE_CLIENT_ID en el Worker = ID de cliente "Web" de Google)
 *  POST /api/email/login {email, password} -> {code, token, name, skin} | POST /api/email/set {email, password} | /remove
 *  POST /api/recovery/new                        -> {recovery}  (genera otra clave de recuperación)
 *  POST /api/push {token}                        -> registra el token FCM de este teléfono
 *  GET  /api/invite/<id>                         -> {from, name, channel, pass} (invitación recibida por push)
 *  POST /api/voice/send?to=CODIGO&dur=ms         (cuerpo: audio µ-law 16 kHz, máx. 20 s) -> mensaje de voz a un amigo
 *  GET  /api/voice -> {messages:[{id,from,name,dur,ts}]} | GET /api/voice/<id> -> audio | DELETE /api/voice/<id>
 * Push (FCM) es opcional: solo se envía si el Worker tiene el secret FCM_SERVICE_ACCOUNT.
 *
 * Amigos / presencia: wss://<tu-worker>/presence  (un único Durable Object global)
 *  cliente -> servidor: {type:"hello", code, token, name, skin, inChannel, key}
 *  servidor -> cliente: {type:"status", friends:[{code, online, name?, skin?, inChannel?}]}
 *                       {type:"friends_changed"}  (cambió tu lista, tus solicitudes o tus bloqueos)
 * Solo se ve el estado de los amigos que aceptaron (la amistad es mutua y la valida el servidor).
 *
 * Canal: join acepta además {code, token} (identidad verificada); el primero en entrar es el
 * dueño y puede {type:"kick", name}. El servidor responde también con owner y codes.
 * La "pass" que llega al servidor es una prueba derivada de la clave (PBKDF2): la clave real y
 * la clave de cifrado del audio nunca salen del teléfono.
 */
import { DurableObject } from "cloudflare:workers";

const MAX_TALK_MS = 60_000; // tiempo máximo por turno
const STALE_MS = 3_000; // si el hablante no manda audio en este tiempo, otro puede tomar el turno

function cleanChannel(v) {
  return String(v || "").toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 32) || "general";
}

function cleanName(v) {
  return String(v || "").replace(/[\u0000-\u001f]/g, "").trim().slice(0, 24) || "Anonimo";
}

function cleanSkin(v) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) && n >= 0 && n <= 15 ? n : 0;
}

function cleanCode(v) {
  const c = String(v || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  return c.length >= 4 && c.length <= 12 ? c : "";
}

function cleanPass(v) {
  return String(v ?? "").slice(0, 64);
}

function sendJson(ws, obj) {
  try {
    ws.send(JSON.stringify(obj));
  } catch (e) {
    // socket ya cerrado
  }
}

function toHex(buf) {
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function hashPass(pass, salt) {
  const data = new TextEncoder().encode(salt + ":" + pass);
  return toHex(await crypto.subtle.digest("SHA-256", data));
}

async function makeAuth(pass) {
  const salt = toHex(crypto.getRandomValues(new Uint8Array(16)));
  return { salt, hash: await hashPass(pass, salt) };
}

function sameStr(a, b) {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

const CODE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
const MAX_FRIENDS = 100;
const MAX_INCOMING = 50;
const MAX_BLOCKED = 200;
const MAX_FAILS = 5; // intentos fallidos de clave antes de bloquear
const LOCK_MS = 5 * 60_000;

function randomFrom(alphabet, n) {
  const b = crypto.getRandomValues(new Uint8Array(n));
  let out = "";
  for (const x of b) out += alphabet[x % alphabet.length];
  return out;
}

async function sha256hex(text) {
  return toHex(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)));
}

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

function header(request, name) {
  const h = request.headers;
  return h && typeof h.get === "function" ? h.get(name) || "" : "";
}

function accountStub(env, code) {
  return env.ACCOUNT.get(env.ACCOUNT.idFromName(code));
}

const VOICE_MAX_BYTES = 330_000; // ~20 s de µ-law a 16 kHz
const VOICE_CHUNK = 100_000; // cada valor del almacenamiento admite hasta 128 KiB
const VOICE_TTL_MS = 7 * 24 * 3600_000;
const VOICE_MAX_MSGS = 30;
const INVITE_TTL_MS = 15 * 60_000;
const ID_RE = /^[0-9a-f]{8,32}$/;

// ---------------------------------------------------------------- Push (FCM v1)

let fcmCache = { token: "", exp: 0 };

function b64url(data) {
  const bytes = typeof data === "string" ? new TextEncoder().encode(data) : new Uint8Array(data);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function fcmAccessToken(sa) {
  const now = Math.floor(Date.now() / 1000);
  if (fcmCache.token && fcmCache.exp - 60 > now) return fcmCache.token;
  const pem = String(sa.private_key || "").replace(/-----[A-Z ]+-----/g, "").replace(/\s+/g, "");
  const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey(
    "pkcs8",
    der,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const head = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claims = b64url(
    JSON.stringify({
      iss: sa.client_email,
      scope: "https://www.googleapis.com/auth/firebase.messaging",
      aud: "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3600,
    })
  );
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(`${head}.${claims}`));
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: `grant_type=${encodeURIComponent("urn:ietf:params:oauth:grant-type:jwt-bearer")}&assertion=${head}.${claims}.${b64url(sig)}`,
  });
  if (!res.ok) throw new Error("fcm token " + res.status);
  const j = await res.json();
  fcmCache = { token: j.access_token, exp: now + (j.expires_in || 3600) };
  return fcmCache.token;
}

/** "ok" | "invalid" (el token ya no existe) | "error" */
async function sendFcm(env, token, data) {
  let sa;
  try {
    sa = JSON.parse(env.FCM_SERVICE_ACCOUNT);
  } catch (e) {
    return "error";
  }
  try {
    const at = await fcmAccessToken(sa);
    const flat = {};
    for (const [k, v] of Object.entries(data)) flat[k] = String(v);
    const res = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
      method: "POST",
      headers: { authorization: `Bearer ${at}`, "content-type": "application/json" },
      body: JSON.stringify({ message: { token, data: flat, android: { priority: "HIGH" } } }),
    });
    if (res.ok) return "ok";
    if (res.status === 404 && /UNREGISTERED/.test(await res.text())) return "invalid";
    return "error";
  } catch (e) {
    return "error";
  }
}

/** Envía un push a todos los teléfonos de una cuenta; devuelve cuántos aceptaron el mensaje. */
async function pushTo(env, code, data) {
  if (!env.FCM_SERVICE_ACCOUNT) return 0;
  const acc = accountStub(env, code);
  let sent = 0;
  for (const t of await acc.pushTokens()) {
    const r = await sendFcm(env, t, data);
    if (r === "ok") sent++;
    else if (r === "invalid") await acc.removePush(t);
  }
  return sent;
}

/** Rutas HTTP de cuentas. Devuelve null si la ruta no es de /api. */
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@.]{2,24}$/;
const cleanEmail = (e) => String(e || "").trim().toLowerCase().slice(0, 120);

async function pbkdf2hex(password, saltHex) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const salt = new Uint8Array(saltHex.match(/../g).map((h) => parseInt(h, 16)));
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations: 100000 }, key, 256);
  return toHex(new Uint8Array(bits));
}

/** Verifica un ID token de Google (Sign-In). Devuelve {sub, email} o null. Requiere GOOGLE_CLIENT_ID en el Worker. */
async function verifyGoogle(env, idToken) {
  if (!env.GOOGLE_CLIENT_ID || typeof idToken !== "string" || idToken.length < 100 || idToken.length > 4000) return null;
  try {
    const r = await fetch("https://oauth2.googleapis.com/tokeninfo?id_token=" + encodeURIComponent(idToken));
    if (!r.ok) return null;
    const t = await r.json();
    const ok =
      t.aud === env.GOOGLE_CLIENT_ID &&
      (t.iss === "accounts.google.com" || t.iss === "https://accounts.google.com") &&
      String(t.email_verified) === "true" &&
      Number(t.exp) * 1000 > Date.now() &&
      t.sub;
    return ok ? { sub: String(t.sub), email: String(t.email || "") } : null;
  } catch (e) {
    return null;
  }
}

async function handleApi(request, env, url) {
  if (env.ACCESS_KEY && header(request, "X-Wavko-Key") !== env.ACCESS_KEY) {
    return json({ error: "bad_key" }, 401);
  }
  const path = url.pathname;
  let body = {};
  if (request.method === "POST" && path !== "/api/voice/send") {
    try {
      body = (await request.json()) || {};
    } catch (e) {
      body = {};
    }
  }

  if (path === "/api/register" && request.method === "POST") {
    const name = cleanName(body.name);
    const skin = cleanSkin(body.skin);
    const tries = [];
    const wanted = cleanCode(body.code);
    if (wanted) tries.push(wanted);
    for (let i = 0; i < 5; i++) tries.push(randomFrom(CODE_ALPHABET, 6));
    for (const code of tries) {
      const r = await accountStub(env, code).init(code, name, skin);
      if (r.ok) return json({ code, token: r.token, recovery: r.recovery });
    }
    return json({ error: "busy" }, 503);
  }

  if (path === "/api/recover" && request.method === "POST") {
    const code = cleanCode(body.code);
    if (!code) return json({ error: "not_found" }, 404);
    const r = await accountStub(env, code).recover(String(body.recovery || ""));
    if (!r.ok) return json(r, r.error === "locked" ? 429 : r.error === "not_found" ? 404 : 403);
    return json({ code, token: r.token, name: r.name, skin: r.skin });
  }

  // Entrar con Google: si esa cuenta de Google ya está vinculada, devuelve un token nuevo
  if (path === "/api/google/login" && request.method === "POST") {
    if (!env.GOOGLE_CLIENT_ID) return json({ error: "google_off" }, 501);
    const g = await verifyGoogle(env, body.idToken);
    if (!g) return json({ error: "bad_google" }, 401);
    const h = await sha256hex("google:" + g.sub);
    const code = await env.PRESENCE.get(env.PRESENCE.idFromName("global")).googleGet(h);
    if (!code) return json({ error: "not_linked" }, 404);
    const r = await accountStub(env, code).googleLogin(h);
    if (!r.ok) return json({ error: "not_linked" }, 404);
    return json({ code, token: r.token, name: r.name, skin: r.skin });
  }

  // Entrar con correo y contraseña
  if (path === "/api/email/login" && request.method === "POST") {
    const email = cleanEmail(body.email);
    if (!EMAIL_RE.test(email) || typeof body.password !== "string") return json({ error: "bad_login" }, 401);
    const eh = await sha256hex("email:" + email);
    const code = await env.PRESENCE.get(env.PRESENCE.idFromName("global")).emailGet(eh);
    if (!code) return json({ error: "bad_login" }, 401);
    const r = await accountStub(env, code).emailLogin(eh, body.password.slice(0, 200));
    if (!r.ok) return json({ error: r.error || "bad_login", retry: r.retry }, r.error === "locked" ? 429 : 401);
    return json({ code, token: r.token, name: r.name, skin: r.skin });
  }

  if (!path.startsWith("/api/")) return null;

  // Todo lo demás exige "Authorization: Bearer CODIGO.TOKEN"
  const bearer = header(request, "Authorization").replace(/^Bearer\s+/i, "");
  const dot = bearer.indexOf(".");
  const me = dot > 0 ? cleanCode(bearer.slice(0, dot)) : "";
  const token = dot > 0 ? bearer.slice(dot + 1) : "";
  if (!me) return json({ error: "auth" }, 401);
  const acc = accountStub(env, me);
  if (!(await acc.auth(token))) return json({ error: "auth" }, 401);

  // Asocia (o cambia) el correo y la contraseña de esta cuenta
  if (path === "/api/email/set" && request.method === "POST") {
    const email = cleanEmail(body.email);
    const pw = typeof body.password === "string" ? body.password : "";
    if (!EMAIL_RE.test(email)) return json({ error: "bad_email" }, 400);
    if (pw.length < 8 || pw.length > 100) return json({ error: "bad_password" }, 400);
    const eh = await sha256hex("email:" + email);
    const pres = env.PRESENCE.get(env.PRESENCE.idFromName("global"));
    const owner = await pres.emailGet(eh);
    if (owner && owner !== me) return json({ error: "email_taken" }, 409);
    const prev = await acc.setEmail(eh, email, pw);
    if (prev && prev !== eh) await pres.emailDel(prev);
    await pres.emailSet(eh, me);
    return json({ ok: true, email });
  }
  if (path === "/api/email/remove" && request.method === "POST") {
    const prev = await acc.clearEmail();
    if (prev) await env.PRESENCE.get(env.PRESENCE.idFromName("global")).emailDel(prev);
    return json({ ok: true });
  }

  if (path === "/api/google/link" && request.method === "POST") {
    if (!env.GOOGLE_CLIENT_ID) return json({ error: "google_off" }, 501);
    const g = await verifyGoogle(env, body.idToken);
    if (!g) return json({ error: "bad_google" }, 401);
    const h = await sha256hex("google:" + g.sub);
    const pres = env.PRESENCE.get(env.PRESENCE.idFromName("global"));
    const owner = await pres.googleGet(h);
    if (owner && owner !== me) return json({ error: "google_taken" }, 409);
    const prev = await acc.setGoogle(h, g.email);
    if (prev && prev !== h) await pres.googleDel(prev);
    await pres.googleSet(h, me);
    return json({ ok: true, email: g.email });
  }
  if (path === "/api/google/unlink" && request.method === "POST") {
    const prev = await acc.clearGoogle();
    if (prev) await env.PRESENCE.get(env.PRESENCE.idFromName("global")).googleDel(prev);
    return json({ ok: true });
  }

  if (path === "/api/me" && request.method === "GET") {
    const st = await acc.state();
    const info = async (codes) =>
      (
        await Promise.all(
          codes.map(async (c) => {
            const p = await accountStub(env, c).profile();
            return p ? { code: c, name: p.name, skin: p.skin } : { code: c, name: "", skin: 0 };
          })
        )
      );
    return json({
      code: st.code,
      name: st.name,
      skin: st.skin,
      friends: await info(st.friends),
      incoming: st.incoming.map((r) => ({ code: r.code, name: r.name, skin: r.skin })),
      outgoing: await info(st.outgoing),
      blocked: await info(st.blocked),
      google: st.google || "",
      email: st.email || "",
      googleEnabled: !!env.GOOGLE_CLIENT_ID,
    });
  }
  // --- mensajes de voz e invitaciones guardadas
  if (path === "/api/voice" && request.method === "GET") return json({ messages: await acc.voiceList() });
  if (path.startsWith("/api/voice/") && path !== "/api/voice/send" && (request.method === "GET" || request.method === "DELETE")) {
    const id = path.slice("/api/voice/".length);
    if (!ID_RE.test(id)) return json({ error: "not_found" }, 404);
    if (request.method === "DELETE") return json(await acc.voiceDelete(id));
    const bytes = await acc.voiceGet(id);
    if (!bytes) return json({ error: "not_found" }, 404);
    return new Response(bytes, { headers: { "content-type": "application/octet-stream" } });
  }
  if (path.startsWith("/api/invite/") && request.method === "GET") {
    const id = path.slice("/api/invite/".length);
    const inv = ID_RE.test(id) ? await acc.takeInvite(id) : null;
    return inv ? json(inv) : json({ error: "not_found" }, 404);
  }
  if (path === "/api/voice/send" && request.method === "POST") {
    const to = cleanCode(url.searchParams.get("to"));
    const dur = parseInt(url.searchParams.get("dur") || "0", 10);
    const bytes = await request.arrayBuffer();
    if (!to || bytes.byteLength < 1 || bytes.byteLength > VOICE_MAX_BYTES) return json({ error: "invalid" }, 400);
    const st = await acc.state();
    if (!st.friends.includes(to)) return json({ error: "not_friends" }, 403);
    const r = await accountStub(env, to).deliver(me, st.name, dur, bytes);
    if (!r.ok) return json({ error: r.error }, 403);
    // Aviso en vivo si está conectado; si no, push
    const live = await env.PRESENCE.get(env.PRESENCE.idFromName("global")).voice(to, {
      type: "voice",
      id: r.id,
      from: me,
      name: st.name,
      dur: r.dur,
    });
    if (live === 0) await pushTo(env, to, { type: "voice", name: st.name });
    return json({ ok: true, live: live > 0 });
  }

  if (request.method !== "POST") return json({ error: "not_found" }, 404);

  if (path === "/api/push") return json(await acc.addPush(String(body.token || "")));
  if (path === "/api/profile") return json(await acc.setProfile(body.name, body.skin));
  if (path === "/api/friends/add") return json(await acc.addFriend(body.code));
  if (path === "/api/friends/respond") return json(await acc.respond(body.code, !!body.accept));
  if (path === "/api/friends/remove") return json(await acc.removeFriend(body.code));
  if (path === "/api/block") return json(await acc.block(body.code));
  if (path === "/api/unblock") return json(await acc.unblock(body.code));
  if (path === "/api/recovery/new") return json(await acc.newRecovery());
  return json({ error: "not_found" }, 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/health") return new Response("ok");

    if (url.pathname.startsWith("/api/")) {
      const r = await handleApi(request, env, url);
      return r || json({ error: "not_found" }, 404);
    }

    if (url.pathname === "/presence") {
      if (request.headers.get("Upgrade") !== "websocket") {
        return new Response("Expected WebSocket", { status: 426 });
      }
      return env.PRESENCE.get(env.PRESENCE.idFromName("global")).fetch(request);
    }

    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("Wavko server\n", {
        headers: { "content-type": "text/plain; charset=utf-8" },
      });
    }

    const channel = cleanChannel(url.searchParams.get("channel"));
    const stub = env.CHANNEL.get(env.CHANNEL.idFromName(channel));
    return stub.fetch(request);
  },
};

export class Channel extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    // Estado del turno. Solo vive mientras el objeto está en memoria; si hibernó
    // es porque nadie estaba hablando, así que empezar en null es correcto.
    this.talkerId = null;
    this.talkerName = null;
    this.talkStart = 0;
    this.lastAudio = 0;
  }

  async fetch(request) {
    const url = new URL(request.url);
    const [client, server] = Object.values(new WebSocketPair());
    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({
      id: crypto.randomUUID(),
      name: "Anonimo",
      skin: 0,
      code: "",
      owner: false,
      t: 0,
      ip: header(request, "CF-Connecting-IP").slice(0, 45),
      joined: false,
      channel: cleanChannel(url.searchParams.get("channel")),
    });
    return new Response(null, { status: 101, webSocket: client });
  }

  // ------------------------------------------------------------ helpers

  /** Sockets que ya entraron al canal (excepto el de id `exceptId`). */
  _members(exceptId) {
    const out = [];
    for (const ws of this.ctx.getWebSockets()) {
      const a = ws.deserializeAttachment();
      if (a && a.joined && a.id !== exceptId) out.push({ ws, a });
    }
    return out;
  }

  _users(exceptId) {
    return this._members(exceptId).map((m) => m.a.name);
  }

  /** {nombre: skin} de los miembros (excepto `exceptId`). */
  _skins(exceptId) {
    const out = {};
    for (const m of this._members(exceptId)) out[m.a.name] = m.a.skin || 0;
    return out;
  }

  /** {nombre: código} de los miembros con identidad verificada. */
  _codes(exceptId) {
    const out = {};
    for (const m of this._members(exceptId)) if (m.a.code) out[m.a.name] = m.a.code;
    return out;
  }

  _owner() {
    for (const m of this._members(null)) if (m.a.owner) return m.a.name;
    return "";
  }

  /** Estado completo que se manda a todos cuando cambia la lista. */
  _roster() {
    return { users: this._users(null), skins: this._skins(null), codes: this._codes(null), owner: this._owner() };
  }

  _find(id) {
    for (const ws of this.ctx.getWebSockets()) {
      const a = ws.deserializeAttachment();
      if (a && a.id === id) return ws;
    }
    return null;
  }

  /** Si el nombre ya está en uso en el canal, añade (2), (3)... */
  _uniqueName(base) {
    const taken = new Set(this._users(null));
    if (!taken.has(base)) return base;
    let i = 2;
    while (taken.has(`${base} (${i})`)) i++;
    return `${base} (${i})`;
  }

  _release(id) {
    if (this.talkerId !== id) return;
    this.talkerId = null;
    this.talkerName = null;
    for (const m of this._members(id)) sendJson(m.ws, { type: "talking", name: null });
  }

  _deny(ws, code, message) {
    sendJson(ws, { type: "error", code, message });
    try {
      ws.close(4003, code);
    } catch (e) {
      // ya cerrado
    }
  }

  async _gone(ws) {
    const me = ws.deserializeAttachment();
    if (!me) return;
    this._release(me.id);
    if (!me.joined) return;
    const others = this._members(me.id);
    if (others.length === 0) {
      // Salió la última persona: el canal deja de existir (se borra también su clave)
      this.talkerId = null;
      this.talkerName = null;
      try {
        await this.ctx.storage.deleteAll();
      } catch (e) {
        // sin almacenamiento que borrar
      }
      return;
    }
    if (me.owner && !others.some((m) => m.a.owner)) {
      // El dueño se fue: el miembro más antiguo pasa a ser dueño
      others.sort((x, y) => (x.a.t || 0) - (y.a.t || 0));
      const heir = others[0];
      heir.a.owner = true;
      heir.ws.serializeAttachment(heir.a);
    }
    const msg = {
      type: "users",
      users: this._users(me.id),
      skins: this._skins(me.id),
      codes: this._codes(me.id),
      owner: (others.find((m) => m.a.owner) || { a: { name: "" } }).a.name,
    };
    for (const m of others) sendJson(m.ws, msg);
  }

  /** Cuenta intentos fallidos de clave por IP/cuenta y bloquea tras varios. */
  async _failKey(me) {
    return me.code || me.ip || "?";
  }

  async _lockedFor(me) {
    const fails = (await this.ctx.storage.get("fails")) || {};
    const rec = fails[await this._failKey(me)];
    const now = Date.now();
    return rec && rec.until > now ? Math.ceil((rec.until - now) / 1000) : 0;
  }

  async _registerFail(me) {
    const fails = (await this.ctx.storage.get("fails")) || {};
    const now = Date.now();
    for (const k of Object.keys(fails)) if (fails[k].until && fails[k].until < now) delete fails[k];
    const k = await this._failKey(me);
    const rec = fails[k] || { n: 0, until: 0 };
    rec.n += 1;
    if (rec.n >= MAX_FAILS) {
      rec.n = 0;
      rec.until = now + LOCK_MS;
    }
    fails[k] = rec;
    if (Object.keys(fails).length > 200) delete fails[Object.keys(fails)[0]];
    await this.ctx.storage.put("fails", fails);
  }

  async _clearFails(me) {
    const fails = (await this.ctx.storage.get("fails")) || {};
    const k = await this._failKey(me);
    if (fails[k]) {
      delete fails[k];
      await this.ctx.storage.put("fails", fails);
    }
  }

  async _kick(ws, me, msg) {
    if (!me.joined || !me.owner) return;
    const target = this._members(me.id).find((m) => m.a.name === String(msg.name || ""));
    if (!target) return;
    const bans = (await this.ctx.storage.get("bans")) || [];
    bans.push({ code: target.a.code || "", ip: target.a.code ? "" : target.a.ip || "" });
    await this.ctx.storage.put("bans", bans.slice(-100));
    sendJson(target.ws, { type: "kicked" });
    await this._gone(target.ws); // avisa a los demás y libera el turno
    target.a.joined = false;
    target.ws.serializeAttachment(target.a);
    try {
      target.ws.close(4004, "kicked");
    } catch (e) {
      // ya cerrado
    }
  }

  async _join(ws, me, msg) {
    if (me.joined) return;

    const key = this.env.ACCESS_KEY;
    if (key && msg.key !== key) {
      return this._deny(ws, "bad_key", "Clave del servidor incorrecta");
    }

    // Identidad verificada (opcional): permite expulsar/bloquear sin depender de la IP
    if (msg.code && msg.token) {
      const code = cleanCode(msg.code);
      let ok = false;
      try {
        ok = !!code && (await this.env.ACCOUNT.get(this.env.ACCOUNT.idFromName(code)).auth(String(msg.token)));
      } catch (e) {
        ok = false;
      }
      me.code = ok ? code : "";
    }

    const name = cleanName(msg.name);
    const pass = cleanPass(msg.pass);
    const mode = msg.mode === "create" || msg.mode === "join" ? msg.mode : "resume";
    const exists = this._members(null).length > 0;

    let created = false;
    let authRec = null;

    if (mode === "create" || (mode === "resume" && !exists)) {
      if (exists) {
        return this._deny(ws, "exists", "Ese canal ya existe. Elige otro nombre o usa «Unirme a canal»");
      }
      if (pass) authRec = await makeAuth(pass); // asíncrono: puede intercalarse otra conexión
      // Sección síncrona: comprobar de nuevo y reclamar el canal sin ceder el turno
      if (this._members(null).length > 0) {
        return this._deny(ws, "exists", "Ese canal ya existe. Elige otro nombre o usa «Unirme a canal»");
      }
      created = true;
    } else {
      if (!exists) {
        return this._deny(ws, "not_found", "Ese canal no existe. Revisa el nombre o crea uno nuevo");
      }
      const bans = (await this.ctx.storage.get("bans")) || [];
      if (bans.some((b) => (b.code && b.code === me.code) || (b.ip && b.ip === me.ip))) {
        return this._deny(ws, "banned", "Te expulsaron de este canal");
      }
      const auth = await this.ctx.storage.get("auth");
      if (auth && auth.hash) {
        const wait = await this._lockedFor(me);
        if (wait > 0) {
          return this._deny(ws, "locked", `Demasiados intentos. Espera ${Math.ceil(wait / 60)} min`);
        }
        const ok = pass !== "" && sameStr(await hashPass(pass, auth.salt), auth.hash);
        if (!ok) {
          await this._registerFail(me);
          return this._deny(ws, "bad_pass", "Clave del canal incorrecta");
        }
        await this._clearFails(me);
      }
      if (this._members(null).length === 0) {
        // el canal se vació mientras comprobábamos la clave
        return this._deny(ws, "not_found", "Ese canal no existe. Revisa el nombre o crea uno nuevo");
      }
    }

    me.name = this._uniqueName(name);
    me.skin = cleanSkin(msg.skin);
    me.joined = true;
    me.owner = created;
    me.t = Date.now();
    ws.serializeAttachment(me);

    if (created) {
      if (authRec) await this.ctx.storage.put("auth", authRec);
      else await this.ctx.storage.delete("auth");
    }

    const roster = this._roster();
    sendJson(ws, { type: "joined", channel: me.channel, ...roster, you: me.name, created });
    for (const m of this._members(me.id)) sendJson(m.ws, { type: "users", ...roster });
    if (this.talkerId && this.talkerId !== me.id) {
      sendJson(ws, { type: "talking", name: this.talkerName });
    }
  }

  // ----------------------------------------------------------- mensajes

  async webSocketMessage(ws, message) {
    const me = ws.deserializeAttachment();
    if (!me) return;

    // --- Audio (binario) ---
    if (typeof message !== "string") {
      if (!me.joined || this.talkerId !== me.id) return; // solo el que tiene el turno
      const now = Date.now();
      if (now - this.talkStart > MAX_TALK_MS) {
        this._release(me.id);
        sendJson(ws, { type: "released" });
        return;
      }
      this.lastAudio = now;
      for (const m of this._members(me.id)) {
        try {
          m.ws.send(message);
        } catch (e) {
          // el receptor se cayó; su evento de cierre lo limpiará
        }
      }
      return;
    }

    // --- Control (JSON) ---
    let msg;
    try {
      msg = JSON.parse(message);
    } catch (e) {
      return;
    }
    if (!msg || typeof msg !== "object") return;

    if (msg.type === "join") {
      await this._join(ws, me, msg);
      return;
    }

    if (msg.type === "kick") {
      await this._kick(ws, me, msg);
      return;
    }

    // Chat de texto del canal. Con clave el texto llega cifrado (el servidor solo lo reenvía).
    if (msg.type === "chat" && me.joined) {
      const text = typeof msg.text === "string" ? msg.text : "";
      if (!text || text.length > 1500) return;
      this.chatAt = this.chatAt || new Map();
      const now = Date.now();
      if (now - (this.chatAt.get(me.id) || 0) < 500) return; // anti-spam
      this.chatAt.set(me.id, now);
      const out = JSON.stringify({ type: "chat", name: me.name, code: me.code || "", text, ts: now });
      for (const m of this._members(me.id)) {
        try {
          m.ws.send(out);
        } catch (e) {
          // se limpiará al cerrar
        }
      }
      return;
    }

    if (msg.type === "ptt" && me.joined) {
      if (!msg.on) {
        this._release(me.id);
        return;
      }
      const now = Date.now();
      if (this.talkerId && this.talkerId !== me.id) {
        const last = Math.max(this.talkStart, this.lastAudio);
        if (now - last < STALE_MS) {
          sendJson(ws, { type: "busy", by: this.talkerName });
          return;
        }
        // El hablante anterior quedó colgado: le quitamos el turno
        const oldId = this.talkerId;
        this._release(oldId);
        const old = this._find(oldId);
        if (old) sendJson(old, { type: "released" });
      }
      if (this.talkerId === me.id) {
        sendJson(ws, { type: "granted" });
        return;
      }
      this.talkerId = me.id;
      this.talkerName = me.name;
      this.talkStart = now;
      this.lastAudio = now;
      sendJson(ws, { type: "granted" });
      for (const m of this._members(me.id)) sendJson(m.ws, { type: "talking", name: me.name });
    }
  }

  async webSocketClose(ws, code, reason, wasClean) {
    await this._gone(ws);
    try {
      // 1005/1006/1015 no se pueden enviar en un frame de cierre
      ws.close(code === 1005 || code === 1006 || code === 1015 ? 1000 : code, "bye");
    } catch (e) {
      // ya cerrado
    }
  }

  async webSocketError(ws, error) {
    await this._gone(ws);
  }
}

/**
 * Cuenta de una persona (un Durable Object por código). Guarda el hash del token, el hash de la
 * clave de recuperación, el perfil, la lista de amigos, las solicitudes y los bloqueos.
 */
export class Account extends DurableObject {
  async _load() {
    return (await this.ctx.storage.get("a")) || null;
  }

  async _save(a) {
    await this.ctx.storage.put("a", a);
  }

  _peer(code) {
    return this.env.ACCOUNT.get(this.env.ACCOUNT.idFromName(code));
  }

  /** Avisa a la presencia de que cambió la lista de amigos (y refresca las pantallas abiertas). */
  async _changed(a) {
    try {
      await this.env.PRESENCE.get(this.env.PRESENCE.idFromName("global")).changed(a.code, a.friends);
    } catch (e) {
      // la presencia se pondrá al día cuando el cliente vuelva a conectar
    }
  }

  async init(code, name, skin) {
    if (await this._load()) return { ok: false };
    const token = toHex(crypto.getRandomValues(new Uint8Array(24)));
    const recovery = randomFrom(CODE_ALPHABET, 20);
    await this._save({
      code,
      tokenHash: await sha256hex(token),
      recHash: await sha256hex(code + ":" + recovery),
      name: cleanName(name),
      skin: cleanSkin(skin),
      friends: [],
      incoming: [],
      outgoing: [],
      blocked: [],
      fails: { n: 0, until: 0 },
      created: Date.now(),
    });
    return { ok: true, token, recovery };
  }

  async auth(token) {
    const a = await this._load();
    if (!a || typeof token !== "string" || token.length < 8 || token.length > 128) return false;
    return sameStr(await sha256hex(token), a.tokenHash);
  }

  /** Recupera la cuenta con la clave de recuperación (genera un token nuevo: cierra sesión en los demás). */
  async recover(key) {
    const a = await this._load();
    if (!a) return { ok: false, error: "not_found" };
    const now = Date.now();
    if (a.fails.until > now) {
      return { ok: false, error: "locked", retry: Math.ceil((a.fails.until - now) / 1000) };
    }
    const k = String(key || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (!sameStr(await sha256hex(a.code + ":" + k), a.recHash)) {
      a.fails.n += 1;
      if (a.fails.n >= MAX_FAILS) a.fails = { n: 0, until: now + 3 * LOCK_MS };
      await this._save(a);
      return { ok: false, error: "bad_recovery" };
    }
    const token = toHex(crypto.getRandomValues(new Uint8Array(24)));
    a.tokenHash = await sha256hex(token);
    a.fails = { n: 0, until: 0 };
    await this._save(a);
    return { ok: true, token, name: a.name, skin: a.skin };
  }

  async setEmail(hash, email, password) {
    const a = await this._load();
    if (!a) return "";
    const prev = a.emailHash || "";
    const salt = toHex(crypto.getRandomValues(new Uint8Array(16)));
    a.emailHash = hash;
    a.email = email;
    a.pw = { salt, hash: await pbkdf2hex(password, salt) };
    await this._save(a);
    return prev;
  }

  async clearEmail() {
    const a = await this._load();
    if (!a) return "";
    const prev = a.emailHash || "";
    delete a.emailHash;
    delete a.email;
    delete a.pw;
    await this._save(a);
    return prev;
  }

  /** Entrar con correo y contraseña (con bloqueo tras 5 fallos). */
  async emailLogin(hash, password) {
    const a = await this._load();
    if (!a || !a.pw || !a.emailHash || !sameStr(a.emailHash, hash)) return { ok: false, error: "bad_login" };
    const now = Date.now();
    if (a.fails.until > now) return { ok: false, error: "locked", retry: Math.ceil((a.fails.until - now) / 1000) };
    if (!sameStr(await pbkdf2hex(password, a.pw.salt), a.pw.hash)) {
      a.fails.n += 1;
      if (a.fails.n >= MAX_FAILS) a.fails = { n: 0, until: now + 3 * LOCK_MS };
      await this._save(a);
      return { ok: false, error: "bad_login" };
    }
    const token = toHex(crypto.getRandomValues(new Uint8Array(24)));
    a.tokenHash = await sha256hex(token);
    a.fails = { n: 0, until: 0 };
    await this._save(a);
    return { ok: true, token, name: a.name, skin: a.skin };
  }

  /** Vincula una cuenta de Google. Devuelve el hash anterior (si lo había). */
  async setGoogle(hash, email) {
    const a = await this._load();
    if (!a) return "";
    const prev = a.googleHash || "";
    a.googleHash = hash;
    a.googleEmail = String(email || "").slice(0, 120);
    await this._save(a);
    return prev;
  }

  async clearGoogle() {
    const a = await this._load();
    if (!a) return "";
    const prev = a.googleHash || "";
    delete a.googleHash;
    delete a.googleEmail;
    await this._save(a);
    return prev;
  }

  /** Entrar con Google: nuevo token (invalida los anteriores). */
  async googleLogin(hash) {
    const a = await this._load();
    if (!a || !a.googleHash || !sameStr(a.googleHash, hash)) return { ok: false };
    const token = toHex(crypto.getRandomValues(new Uint8Array(24)));
    a.tokenHash = await sha256hex(token);
    await this._save(a);
    return { ok: true, token, name: a.name, skin: a.skin };
  }

  async newRecovery() {
    const a = await this._load();
    if (!a) return { ok: false };
    const recovery = randomFrom(CODE_ALPHABET, 20);
    a.recHash = await sha256hex(a.code + ":" + recovery);
    await this._save(a);
    return { ok: true, recovery };
  }

  async profile() {
    const a = await this._load();
    return a ? { name: a.name, skin: a.skin } : null;
  }

  async state() {
    const a = await this._load();
    return a
      ? { code: a.code, name: a.name, skin: a.skin, friends: a.friends, incoming: a.incoming, outgoing: a.outgoing, blocked: a.blocked, google: a.googleEmail || "", email: a.email || "" }
      : null;
  }

  async setProfile(name, skin) {
    const a = await this._load();
    if (!a) return { ok: false };
    a.name = cleanName(name);
    a.skin = cleanSkin(skin);
    await this._save(a);
    return { ok: true, name: a.name, skin: a.skin };
  }

  // ---------------------------------------------------------------- amistades

  /** Yo (esta cuenta) envío una solicitud a `to`. Si él ya me la había enviado, quedamos como amigos. */
  async addFriend(to) {
    const a = await this._load();
    if (!a) return { ok: false, error: "auth" };
    to = cleanCode(to);
    if (!to || to === a.code) return { ok: false, error: "invalid" };
    if (a.friends.includes(to)) return { ok: true, state: "friends" };
    if (a.blocked.includes(to)) return { ok: false, error: "blocked" };
    if (a.friends.length >= MAX_FRIENDS) return { ok: false, error: "full" };
    const r = await this._peer(to).incoming(a.code, a.name, a.skin);
    if (!r.ok) return r;
    const b = await this._load(); // volver a leer: pudo cambiar mientras esperábamos
    if (r.state === "friends") {
      if (!b.friends.includes(to)) b.friends.push(to);
      b.outgoing = b.outgoing.filter((c) => c !== to);
      b.incoming = b.incoming.filter((q) => q.code !== to);
    } else if (!b.outgoing.includes(to)) {
      b.outgoing.push(to);
    }
    await this._save(b);
    await this._changed(b);
    return { ok: true, state: r.state };
  }

  /** Llega una solicitud de `from`. */
  async incoming(from, name, skin) {
    const b = await this._load();
    if (!b) return { ok: false, error: "not_found" };
    if (b.blocked.includes(from)) return { ok: true, state: "pending" }; // no se le dice que está bloqueado
    if (b.friends.includes(from)) return { ok: true, state: "friends" };
    if (b.outgoing.includes(from) && b.friends.length < MAX_FRIENDS) {
      b.outgoing = b.outgoing.filter((c) => c !== from);
      b.incoming = b.incoming.filter((q) => q.code !== from);
      b.friends.push(from);
      await this._save(b);
      await this._changed(b);
      return { ok: true, state: "friends" };
    }
    if (!b.incoming.some((q) => q.code === from)) {
      if (b.incoming.length >= MAX_INCOMING) b.incoming.shift();
      b.incoming.push({ code: from, name: cleanName(name), skin: cleanSkin(skin), ts: Date.now() });
    }
    await this._save(b);
    await this._changed(b);
    return { ok: true, state: "pending" };
  }

  /** Acepto o rechazo la solicitud que me envió `code`. */
  async respond(code, accept) {
    const a = await this._load();
    if (!a) return { ok: false, error: "auth" };
    code = cleanCode(code);
    if (!a.incoming.some((q) => q.code === code)) return { ok: false, error: "no_request" };
    a.incoming = a.incoming.filter((q) => q.code !== code);
    if (accept) {
      if (a.friends.length >= MAX_FRIENDS) return { ok: false, error: "full" };
      if (!a.friends.includes(code)) a.friends.push(code);
    }
    await this._save(a);
    await this._peer(code).answered(a.code, !!accept);
    await this._changed(a);
    return { ok: true, state: accept ? "friends" : "rejected" };
  }

  /** `from` respondió a mi solicitud. */
  async answered(from, accepted) {
    const b = await this._load();
    if (!b || !b.outgoing.includes(from)) return;
    b.outgoing = b.outgoing.filter((c) => c !== from);
    if (accepted && !b.friends.includes(from) && b.friends.length < MAX_FRIENDS) b.friends.push(from);
    await this._save(b);
    await this._changed(b);
  }

  /** La otra persona me quitó o me bloqueó. */
  async dropped(from) {
    const b = await this._load();
    if (!b) return;
    const had = b.friends.includes(from) || b.outgoing.includes(from) || b.incoming.some((q) => q.code === from);
    if (!had) return;
    b.friends = b.friends.filter((c) => c !== from);
    b.outgoing = b.outgoing.filter((c) => c !== from);
    b.incoming = b.incoming.filter((q) => q.code !== from);
    await this._save(b);
    await this._changed(b);
  }

  async removeFriend(code) {
    const a = await this._load();
    if (!a) return { ok: false, error: "auth" };
    code = cleanCode(code);
    a.friends = a.friends.filter((c) => c !== code);
    await this._save(a);
    await this._peer(code).dropped(a.code);
    await this._changed(a);
    return { ok: true };
  }

  async block(code) {
    const a = await this._load();
    if (!a) return { ok: false, error: "auth" };
    code = cleanCode(code);
    if (!code || code === a.code) return { ok: false, error: "invalid" };
    if (!a.blocked.includes(code)) {
      if (a.blocked.length >= MAX_BLOCKED) a.blocked.shift();
      a.blocked.push(code);
    }
    a.friends = a.friends.filter((c) => c !== code);
    a.outgoing = a.outgoing.filter((c) => c !== code);
    a.incoming = a.incoming.filter((q) => q.code !== code);
    await this._save(a);
    await this._peer(code).dropped(a.code);
    await this._changed(a);
    return { ok: true };
  }

  // ------------------------------------------------------------------ push / invitaciones

  async pushTokens() {
    const a = await this._load();
    return a ? a.push || [] : [];
  }

  async addPush(token) {
    const a = await this._load();
    if (!a || token.length < 20 || token.length > 4096) return { ok: false };
    a.push = [token, ...(a.push || []).filter((t) => t !== token)].slice(0, 5);
    await this._save(a);
    return { ok: true };
  }

  async removePush(token) {
    const a = await this._load();
    if (!a) return;
    a.push = (a.push || []).filter((t) => t !== token);
    await this._save(a);
  }

  /** Guarda una invitación (15 min) para entregarla cuando el teléfono abra el aviso push. */
  async addInvite(inv) {
    const a = await this._load();
    if (!a) return "";
    const now = Date.now();
    const id = toHex(crypto.getRandomValues(new Uint8Array(8)));
    a.invites = [...(a.invites || []).filter((i) => now - i.ts < INVITE_TTL_MS), { id, ts: now, ...inv }].slice(-10);
    await this._save(a);
    return id;
  }

  async takeInvite(id) {
    const a = await this._load();
    if (!a) return null;
    const now = Date.now();
    const inv = (a.invites || []).find((i) => i.id === id && now - i.ts < INVITE_TTL_MS);
    if (!inv) return null;
    a.invites = a.invites.filter((i) => i.id !== id);
    await this._save(a);
    return { from: inv.from, name: inv.name, skin: inv.skin, channel: inv.channel, pass: inv.pass };
  }

  // ------------------------------------------------------------ mensajes de voz

  async _dropVoice(meta) {
    const keys = [];
    for (let i = 0; i < meta.parts; i++) keys.push(`v:${meta.id}:${i}`);
    await this.ctx.storage.delete(keys);
  }

  async _inbox() {
    const now = Date.now();
    const all = (await this.ctx.storage.get("inbox")) || [];
    const keep = [];
    for (const m of all) {
      if (now - m.ts > VOICE_TTL_MS) await this._dropVoice(m);
      else keep.push(m);
    }
    if (keep.length !== all.length) await this.ctx.storage.put("inbox", keep);
    return keep;
  }

  /** Recibe un mensaje de voz de `from` (solo si son amigos y no está bloqueado). */
  async deliver(from, name, dur, bytes) {
    const b = await this._load();
    if (!b) return { ok: false, error: "not_found" };
    if (!b.friends.includes(from) || b.blocked.includes(from)) return { ok: false, error: "not_friends" };
    const buf = new Uint8Array(bytes);
    if (buf.length < 1 || buf.length > VOICE_MAX_BYTES) return { ok: false, error: "too_big" };
    const id = toHex(crypto.getRandomValues(new Uint8Array(8)));
    const parts = Math.ceil(buf.length / VOICE_CHUNK);
    for (let i = 0; i < parts; i++) {
      await this.ctx.storage.put(`v:${id}:${i}`, buf.slice(i * VOICE_CHUNK, (i + 1) * VOICE_CHUNK));
    }
    const inbox = await this._inbox();
    const d = Math.max(0, Math.min(25_000, Number.isFinite(dur) ? Math.floor(dur) : 0));
    inbox.push({ id, from, name: cleanName(name), dur: d, ts: Date.now(), size: buf.length, parts });
    while (inbox.length > VOICE_MAX_MSGS) await this._dropVoice(inbox.shift());
    await this.ctx.storage.put("inbox", inbox);
    return { ok: true, id, dur: d };
  }

  async voiceList() {
    return (await this._inbox()).map(({ id, from, name, dur, ts }) => ({ id, from, name, dur, ts }));
  }

  async voiceGet(id) {
    const meta = (await this._inbox()).find((m) => m.id === id);
    if (!meta) return null;
    const out = new Uint8Array(meta.size);
    let off = 0;
    for (let i = 0; i < meta.parts; i++) {
      const part = await this.ctx.storage.get(`v:${id}:${i}`);
      if (!part) return null;
      out.set(part, off);
      off += part.length;
    }
    return out;
  }

  async voiceDelete(id) {
    const inbox = await this._inbox();
    const meta = inbox.find((m) => m.id === id);
    if (!meta) return { ok: true };
    await this._dropVoice(meta);
    await this.ctx.storage.put("inbox", inbox.filter((m) => m.id !== id));
    return { ok: true };
  }

  async unblock(code) {
    const a = await this._load();
    if (!a) return { ok: false, error: "auth" };
    a.blocked = a.blocked.filter((c) => c !== cleanCode(code));
    await this._save(a);
    await this._changed(a);
    return { ok: true };
  }
}

/**
 * Presencia global. Cada cliente abre un WebSocket y manda "hello" con su código y su token. El
 * servidor comprueba el token, carga su lista de amigos (aceptados) y le responde con el estado
 * de esos amigos; avisa cuando cambian. No guarda nada: todo vive en las conexiones.
 */
export class Presence extends DurableObject {
  async fetch(request) {
    const [client, server] = Object.values(new WebSocketPair());
    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({ hello: false, code: "", name: "", skin: 0, inChannel: false, watch: [] });
    return new Response(null, { status: 101, webSocket: client });
  }

  /** Avisa en vivo a los sockets de `code`; devuelve a cuántos llegó (0 = sin conexión). */
  async voice(code, payload) {
    let n = 0;
    for (const ws of this.ctx.getWebSockets()) {
      const a = ws.deserializeAttachment();
      if (a && a.hello && a.code === code) {
        sendJson(ws, payload);
        n++;
      }
    }
    return n;
  }

  /** Lo llama la cuenta cuando cambia su lista de amigos: actualiza sus sockets y les avisa. */
  async emailGet(h) {
    return (await this.ctx.storage.get("e:" + h)) || "";
  }
  async emailSet(h, code) {
    await this.ctx.storage.put("e:" + h, code);
  }
  async emailDel(h) {
    await this.ctx.storage.delete("e:" + h);
  }

  // Índice Google -> código de cuenta (hash de "google:<sub>")
  async googleGet(h) {
    return (await this.ctx.storage.get("g:" + h)) || "";
  }
  async googleSet(h, code) {
    await this.ctx.storage.put("g:" + h, code);
  }
  async googleDel(h) {
    await this.ctx.storage.delete("g:" + h);
  }

  async changed(code, friends) {
    for (const ws of this.ctx.getWebSockets()) {
      const a = ws.deserializeAttachment();
      if (a && a.hello && a.code === code) {
        a.watch = friends.slice(0, MAX_FRIENDS);
        ws.serializeAttachment(a);
        sendJson(ws, { type: "friends_changed" });
        sendJson(ws, { type: "status", friends: a.watch.map((c) => this._entry(c, null)) });
      }
    }
  }

  /** Estado de un código; `except` es un socket que se está cerrando y no debe contar. */
  _entry(code, except) {
    let found = null;
    let inChannel = false;
    for (const ws of this.ctx.getWebSockets()) {
      if (ws === except) continue;
      const a = ws.deserializeAttachment();
      if (a && a.hello && a.code === code) {
        found = a;
        if (a.inChannel) inChannel = true;
      }
    }
    return found
      ? { code, online: true, name: found.name, skin: found.skin, inChannel }
      : { code, online: false };
  }

  _notify(code, except) {
    const entry = this._entry(code, except);
    for (const ws of this.ctx.getWebSockets()) {
      if (ws === except) continue;
      const a = ws.deserializeAttachment();
      if (a && a.hello && a.watch.includes(code)) sendJson(ws, { type: "status", friends: [entry] });
    }
  }

  /** Invitación a un canal: solo llega a quien tiene al remitente en su lista de amigos. */
  async _invite(ws, msg) {
    const me = ws.deserializeAttachment();
    if (!me || !me.hello) return;
    const to = cleanCode(msg.to);
    const channel = typeof msg.channel === "string" ? msg.channel.trim().slice(0, 64) : "";
    if (!to || to === me.code || !channel || !me.watch.includes(to)) return;
    const pass = typeof msg.pass === "string" ? msg.pass.slice(0, 64) : "";
    let delivered = 0;
    for (const other of this.ctx.getWebSockets()) {
      const a = other.deserializeAttachment();
      if (a && a.hello && a.code === to && a.watch.includes(me.code)) {
        sendJson(other, { type: "invite", from: me.code, name: me.name, skin: me.skin, channel, pass });
        delivered++;
      }
    }
    // Si no está conectado y tiene push, se guarda la invitación y se avisa por FCM
    let pushed = false;
    if (delivered === 0 && this.env.FCM_SERVICE_ACCOUNT) {
      try {
        const toAcc = accountStub(this.env, to);
        if ((await toAcc.pushTokens()).length) {
          const id = await toAcc.addInvite({ from: me.code, name: me.name, skin: me.skin, channel, pass });
          pushed = (await pushTo(this.env, to, { type: "invite", id, name: me.name, channel })) > 0;
        }
      } catch (e) {
        pushed = false;
      }
    }
    sendJson(ws, { type: "invite_result", to, delivered, pushed });
  }

  async webSocketMessage(ws, message) {
    if (typeof message !== "string") return;
    let msg;
    try {
      msg = JSON.parse(message);
    } catch (e) {
      return;
    }
    if (!msg) return;
    if (msg.type === "invite") {
      await this._invite(ws, msg);
      return;
    }
    if (msg.type !== "hello") return;

    const key = this.env.ACCESS_KEY;
    if (key && msg.key !== key) {
      sendJson(ws, { type: "error", code: "bad_key", message: "Clave del servidor incorrecta" });
      try {
        ws.close(4003, "bad_key");
      } catch (e) {
        // ya cerrado
      }
      return;
    }

    const code = cleanCode(msg.code);
    if (!code) return;
    let watch = null;
    try {
      const acc = this.env.ACCOUNT.get(this.env.ACCOUNT.idFromName(code));
      if (await acc.auth(String(msg.token || ""))) {
        const st = await acc.state();
        watch = st.friends.slice(0, MAX_FRIENDS);
      }
    } catch (e) {
      watch = null;
    }
    if (watch === null) {
      sendJson(ws, { type: "error", code: "auth", message: "Sesión no válida" });
      try {
        ws.close(4001, "auth");
      } catch (e) {
        // ya cerrado
      }
      return;
    }
    ws.serializeAttachment({
      hello: true,
      code,
      name: cleanName(msg.name),
      skin: cleanSkin(msg.skin),
      inChannel: !!msg.inChannel,
      watch,
    });

    sendJson(ws, { type: "status", friends: watch.map((c) => this._entry(c, null)) });
    this._notify(code, null);
  }

  async webSocketClose(ws, code, reason, wasClean) {
    const a = ws.deserializeAttachment();
    if (a && a.hello) this._notify(a.code, ws);
    try {
      ws.close(code === 1005 || code === 1006 || code === 1015 ? 1000 : code, "bye");
    } catch (e) {
      // ya cerrado
    }
  }

  async webSocketError(ws, error) {
    const a = ws.deserializeAttachment();
    if (a && a.hello) this._notify(a.code, ws);
  }
}
