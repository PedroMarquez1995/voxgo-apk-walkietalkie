# Wavko

**Comunicación por voz en movimiento.**

App tipo Zello (push-to-talk): mantén pulsado para hablar, los demás en el canal te escuchan en vivo.

```
wavko/
├── cloudflare/                  Servidor en Cloudflare Workers + Durable Objects (recomendado)
├── android/                     App Android (Kotlin)
└── .github/workflows/
    ├── build-apk.yml            Compila el APK
    └── deploy-cloudflare.yml    Despliega el servidor en Cloudflare
```

## Novedades de Wavko 4.0 — Taller Wavko

- Los walkies pasan a ser **personajes** (mascota con brazos, piernas, antena, rostro y símbolo W), dibujados por capas en código (`AvatarArt.kt`): cuerpo, antena, rostro, sombrero, ropa, brazos/manos, piernas/calzado y accesorios se combinan sin imágenes.
- **Taller Wavko** (Perfil > "Personalizar mi Wavko"): 10 skins, 6 sombreros, 8 antenas, 10 rostros, 7 prendas, 8 accesorios y 4 calzados; vista previa grande que respira, se gira arrastrando y da una vuelta al tocarla.
- **Mis personajes**: 6 de la colección (WAVKO Cyber, Golden, Tactical, Neon, Space, Red Storm) y hasta 12 propios; guardar, crear, renombrar, eliminar y cambiar de personaje.
- El personaje viaja en el mismo número de "skin" que ya compartía la app (bit 24 = personaje nuevo), así que se ve en perfil, amigos, solicitudes, participantes del canal y chats sin tocar la voz. Las skins antiguas (0-15) se muestran como el personaje base.
- Preparado para desbloqueos (`Unlocks`, `AvatarCatalog.TIERS`: gratis, logro, premium, edición limitada). Por ahora `ENFORCE = false`: todo está abierto.

## Novedades de Wavko 3.2

- Desbloquear a alguien que era amigo lo devuelve a la lista de amigos (de ambos).
- Grabar audio en el chat privado: pitido, vibración, botón que crece y pulsa, y temporizador.

## Novedades de Wavko 3.1

- Voz más fuerte (ganancia al grabar y al reproducir + refuerzo del sistema).
- Tema claro: texto legible en "Estás transmitiendo" y menú inferior con más contraste.
- "Expulsar" siempre visible al tocar un participante (solo funciona para quien creó el canal).
- "Desconectar" junto al botón Chat.

## Novedades de Wavko 3.0

- Chat del canal a pantalla completa: la caja de mensaje siempre abajo y visible con el teclado.
- Botón de emojis en los chats.

## Novedades de Wavko 2.9

- Cerrar sesión conserva chats, amigos y canales; "Eliminar cuenta" lo borra todo.
- Borrar mensajes (para mí / para todos) en chats con amigos y en el chat del canal.
- Pantalla de inicio sin botones encimados; chat del canal a pantalla casi completa con X roja.

## 1. Subir el proyecto a GitHub (sin descomprimir)

1. Crea un repositorio y sube el `.zip` tal cual (Add file → Upload files).
2. Crea dos archivos con **Add file → Create new file**, pegando el contenido de los `.yml` que vienen aparte:
   - `.github/workflows/build-apk.yml`
   - `.github/workflows/deploy-cloudflare.yml`
3. Los workflows descomprimen el zip solos. Si prefieres, también puedes subir las carpetas ya descomprimidas.

## 2. Servidor en Cloudflare

Una sola vez, en tu cuenta de Cloudflare:

1. Entra a **Workers & Pages** en el dashboard y, si te lo pide, elige tu subdominio `workers.dev`.
2. Crea un **API Token**: *My Profile → API Tokens → Create Token → plantilla "Edit Cloudflare Workers"*.
3. Copia tu **Account ID** (en la página principal de Workers & Pages, barra lateral derecha).

En tu repo de GitHub, *Settings → Secrets and variables → Actions → New repository secret*:

| Secret | Valor |
|---|---|
| `CLOUDFLARE_API_TOKEN` | el token del paso 2 |
| `CLOUDFLARE_ACCOUNT_ID` | el Account ID del paso 3 |
| `ACCESS_KEY` *(opcional, recomendado)* | una clave; la app deberá enviarla |

Luego ejecuta **Actions → Deploy Cloudflare Worker → Run workflow** (también corre en cada push a `main`).
Tu servidor quedará en `wss://voxgo.<tu-subdominio>.workers.dev`; ese es el valor del campo "Servidor" de la app.

Cómo funciona: un Durable Object por canal, con la API de hibernación. Con el canal en silencio no gasta cómputo y las conexiones siguen abiertas. Los mensajes WebSocket entrantes se cuentan 20:1 como requests; consulta los límites vigentes del plan gratis en la documentación de Cloudflare.

Probarlo en tu PC: `cd cloudflare && npm install && npx wrangler dev` y en la app `ws://IP-DE-TU-PC:8787`.

## 3. Compilar el APK

1. Al hacer commit en `main`, entra en **Actions → Build APK** → abajo, en **Artifacts**, descarga `wavko-apk` (zip con `wavko.apk`).
2. También puedes lanzarlo a mano con **Run workflow**.
3. Si subes un tag (`git tag v1.0 && git push --tags`), el APK queda en **Releases**, útil para bajarlo directo desde el celular.
4. Instálalo en el teléfono (permite "instalar apps desconocidas"). Es un APK *debug*, firmado automáticamente, suficiente para uso propio.

La app ya viene con el servidor `wss://voxgo.pedroxhile.workers.dev` por defecto (se puede cambiar en el campo "Servidor"). Solo falta elegir un canal (ej. `general`) y tu nombre.

Opcional, al compilar: si en GitHub creas la variable `WAVKO_SERVER` (*Settings → Secrets and variables → Actions → Variables*) el APK usa esa dirección en vez de la de arriba; y si existe el secret `ACCESS_KEY`, la clave también queda precargada. Ojo: una clave precargada va dentro del APK, así que no compartas ese APK con quien no deba tenerla.

## Canales y claves

- **Crear canal:** eliges un nombre libre y, si quieres, una clave. Quedas dentro como primera persona.
- **Unirme a canal:** escribes el nombre del canal y la clave que te dieron. Si el canal no existe o la clave es incorrecta, la app te lo avisa.
- Para invitar a alguien, pásale por otro medio (WhatsApp, por ejemplo) el nombre del canal y la clave.
- Un canal existe mientras haya alguien dentro. Cuando sale la última persona, el canal y su clave desaparecen; para volver a usarlo hay que crearlo de nuevo.
- Si dos personas entran con el mismo nombre, el servidor añade `(2)`, `(3)`… para distinguirlas.
- **Desconectar** te saca del canal.
- Al abrir la app aparece una pantalla de bienvenida con el botón **Seguir** (se salta si ya estás dentro de un canal).

Estas funciones viven en el Worker de Cloudflare: después de actualizarlo hay que ejecutar **Deploy Cloudflare Worker** y luego **Build APK**.

## Cómo funciona

- Audio: PCM 16 kHz mono comprimido con G.711 µ-law (≈128 kbps), en paquetes de 40 ms.
- Un solo hablante por canal a la vez: si alguien habla, tu botón suena "ocupado". Turno máximo de 60 s; si el hablante queda colgado (sin audio 3 s) otro puede tomar el turno.
- Servicio en primer plano: sigue conectado con la pantalla apagada (se ve una notificación fija).
- Reconexión automática si se cae la red.
- Tecla Volumen − como PTT: opcional, funciona solo con la app abierta.

## Siguientes mejoras posibles

- Códec Opus (menos datos móviles).
- Cuentas y canales privados.
- PTT con la pantalla apagada vía auricular Bluetooth / servicio de accesibilidad.
- Mensajes de voz grabados e historial.


## Novedades de Wavko 2.8 (inicio con Google, canales, chats y amigos)

- **Inicio**: solo *Crear cuenta con Google* y *Ya tengo cuenta*. *Seguir* está deshabilitado (difuminado) hasta entrar con Google; después aparece «¡Bienvenido, <nombre>!» y *Seguir* se activa. Solo pueden entrar los correos que añadas como usuarios de prueba en Google Cloud (o cualquiera, si publicas la app).
- **Perfil**: se quitaron la clave de recuperación, el correo con contraseña y «Recuperar cuenta». *Cambiar correo Gmail vinculado* sustituye a «Desvincular Google».
- **Ajustes**: *Cerrar sesión* (la cuenta sigue en el servidor) y *Eliminar cuenta* (permanente, con advertencia).
- **Canales**: lista *Mis canales* (favoritos y recientes; creados por ti e invitaciones) con estado **Activo/Inactivo** (según haya gente dentro), botón *Unirme a canal* y *Eliminar* de tu lista. Para unirte a otro canal sal primero del actual.
- **Chat del canal** con burbujas tipo WhatsApp (cada persona con su nombre y color).
- **Conversaciones por amigo** (toca un amigo): texto y mensajes de voz en burbujas, cada amigo con su propio chat. El historial se guarda solo en tu teléfono; el servidor solo guarda lo pendiente de entregar (7 días).
- **Amigos**: el cuadro sirve para buscar (nombre o código, filtra al escribir) y para añadir. En cada resultado: bloquear/desbloquear y eliminar.
- Solo hay que ejecutar *Deploy Cloudflare Worker* y luego *Build APK* (no cambian los workflows).

## Novedades de Wavko 2.6 (cuenta con correo y contraseña)

- **Perfil → Añadir correo y contraseña**: asocia un correo y una contraseña (mínimo 8 caracteres) a tu cuenta actual.
- **Bienvenida → Entrar o crear cuenta con correo**: *Entrar* recupera tu cuenta y amigos en un teléfono nuevo; *Crear cuenta* crea la cuenta nueva con ese correo.
- No hace falta ningún servicio extra. El correo **no se verifica** (no se envía ningún email) y no hay "olvidé mi contraseña" por correo: si la olvidas, usa la clave de recuperación o Google. Tras 5 intentos fallidos la cuenta se bloquea unos minutos. La contraseña se guarda en el servidor solo como hash (PBKDF2).
- Solo hay que ejecutar *Deploy Cloudflare Worker* y luego *Build APK*.

## Novedades de Wavko 2.5 (actualizaciones desde la app)

- En **Ajustes → Actualizaciones → Verificar actualizaciones** la app busca una versión nueva y, si la hay, la descarga y abre el instalador de Android (la primera vez pide "Permitir de esta fuente").
- Cada vez que subes cambios a `main`/`master`, el workflow *Build APK* publica un **Release** `v<versionCode>` con el APK. La app compara ese número con el suyo, así que **sube `versionCode` en `android/app/build.gradle.kts` en cada versión nueva**.
- Requiere que el repositorio sea **público** y que todos los APK usen la misma firma (ver 2.4). Si publicas en Google Play, quita este botón (Play prohíbe que una app se actualice por su cuenta).

## Novedades de Wavko 2.4 (firma fija y acceso con Google)

- **Firma fija**: todos los APK se firman con la misma clave (`wavko.keystore`). Es imprescindible para actualizar la app encima de la anterior y para el acceso con Google. **Guarda una copia del keystore y su contraseña: si la pierdes, nadie podrá actualizar la app.** La primera vez hay que desinstalar la versión anterior (tenía otra firma); tu cuenta y tus amigos no se pierden porque están en el servidor.
- **Entrar con Google**: en Perfil → *Vincular con Google*. Si reinstalas o cambias de teléfono, en la pantalla de bienvenida pulsa *Entrar con Google* y recuperas tu cuenta y tus amigos. La clave de recuperación sigue funcionando.

### Configuración (una sola vez)

1. En GitHub → Settings → Secrets and variables → Actions → **Secrets**: crea `KEYSTORE_BASE64` (contenido de `keystore_base64.txt`) y `KEYSTORE_PASSWORD`.
2. En https://console.cloud.google.com abre el mismo proyecto que usas en Firebase → *APIs y servicios* → *Pantalla de consentimiento de OAuth* (tipo Externo, nombre Wavko, tu correo; publícala en producción).
3. *Credenciales* → *Crear credenciales* → *ID de cliente de OAuth* → **Android**: paquete `app.wavko` y la huella SHA-1 de tu keystore (`keytool -list -v -keystore wavko.keystore`).
4. Crea otro ID de cliente de tipo **Aplicación web**. Copia su ID (termina en `.apps.googleusercontent.com`).
5. En GitHub → pestaña **Variables**: crea `GOOGLE_CLIENT_ID` con ese ID web.
6. (Push) En Firebase → Configuración del proyecto → tu app Android → añade la misma huella SHA-1.
7. Ejecuta **Deploy Cloudflare Worker** y después **Build APK**.

## Novedades de Wavko 2.3 (mensajes de voz, push y chat)

- **Mensajes de voz**: en *Amigos*, mantén pulsado el micrófono de un amigo (máx. 20 s) y suelta para enviar. Le llega a su bandeja "Mensajes de voz" (se guardan 7 días, máx. 30) aunque esté sin conexión. Solo entre amigos y respetando los bloqueos. No se puede grabar mientras estás dentro de un canal.
- **Chat de texto** dentro del canal (botón *Chat* arriba a la derecha). En canales con clave el texto va cifrado igual que el audio. No se guarda: se borra al salir.
- **Notificaciones push** (opcionales, con Firebase): avisan de una invitación o de un mensaje de voz con la app cerrada. Sin Firebase todo lo demás funciona; solo se avisa a los amigos que están en línea.

### Activar las notificaciones push (opcional, una sola vez)

1. En https://console.firebase.google.com crea un proyecto (gratis) y añade una app Android con el nombre de paquete `app.wavko`.
2. Descarga `google-services.json` y pega todo su contenido en un secret de GitHub llamado `GOOGLE_SERVICES_JSON`.
3. En Firebase: Configuración del proyecto → Cuentas de servicio → *Generar nueva clave privada*. Pega el JSON completo en un secret de GitHub llamado `FCM_SERVICE_ACCOUNT`.
4. Ejecuta **Deploy Cloudflare Worker** y después **Build APK**.

### Orden para actualizar
Primero *Deploy Cloudflare Worker* y luego *Build APK*. Todos deben actualizar la app (el cifrado de 2.2 no es compatible con versiones anteriores).

## Novedades de Wavko 2.2 (seguridad y cuentas)

- **Cuenta real**: al abrir la app por primera vez se crea una cuenta en tu servidor (conserva el código de amigo que ya tenías). Te muestra una **clave de recuperación** de 20 caracteres: guárdala. Si cambias de teléfono o reinstalas, en la pantalla de bienvenida o en Perfil → *Recuperar otra cuenta* entras con tu código + esa clave. Recuperar la cuenta cierra la sesión de los demás teléfonos.
- **Solicitudes de amistad**: añadir un código envía una solicitud; la otra persona la acepta, la rechaza o la bloquea. Solo los amigos aceptados ven tu estado ("en línea" / "en un canal") y pueden invitarte. Si ambos se envían solicitud, quedan como amigos al instante. Tus amigos anteriores se envían como solicitudes automáticamente.
- **Bloquear**: desde Amigos, desde una solicitud o tocando a alguien en un canal. Quien bloqueas no puede enviarte solicitudes ni invitaciones y no oyes su voz en los canales. Lista de bloqueados y botón *Desbloquear* en Ajustes.
- **Expulsar**: el que crea el canal es el dueño; toca a un participante → *Expulsar del canal*. Queda vetado (por cuenta, o por IP si no tenía cuenta) hasta que el canal se vacíe. Si el dueño se va, el participante más antiguo hereda el cargo.
- **Límite de intentos de clave**: 5 claves de canal incorrectas seguidas bloquean 5 minutos a esa IP/cuenta en ese canal.
- **Cifrado de extremo a extremo en canales con clave**: del texto de la clave se derivan dos valores distintos (PBKDF2): una *prueba* que se manda al servidor y una clave AES-256-GCM con la que se cifra el audio, que nunca sale del teléfono. El servidor puede comprobar la clave pero no puede escuchar el canal. Un canal sin clave no se cifra. Límite: si invitas a un amigo desde la app, la clave pasa por tu servidor dentro de la invitación; si necesitas privacidad estricta, compártela por otro medio.

### Orden para actualizar
1. Actions → **Deploy Cloudflare Worker** (crea las cuentas: migración v3) y espera a que termine.
2. Actions → **Build APK**. Todos los del canal deben tener esta versión (los cambios del cifrado no son compatibles con la anterior).

## Novedades de Wavko 2.1

- **Invitar amigos a tu canal**: en Amigos, el botón *Invitar* aparece junto a cada amigo en línea cuando estás en un canal. Le llega un aviso (en pantalla, o como notificación si estás en un canal con la app en segundo plano). Solo se entrega si el amigo también te tiene en su lista. La invitación lleva la clave del canal.
- **Segundo plano**: aviso (una sola vez) y sección en Ajustes para quitar la optimización de batería, con enlace a la guía de tu marca (dontkillmyapp.com).
- **Audio HD (Opus, experimental)**: Ajustes → Audio HD. Usa el códec Opus del sistema (Android 10+). Desactivado por defecto; si el teléfono no lo soporta se usa el audio normal. Todos los del canal deben tener esta versión: una versión antigua oiría ruido.
- **Tema claro / oscuro / del sistema**, **16 skins**, animación al cambiar de pestaña.
- **Canales recientes y favoritos** en la pestaña Canales (mantén pulsado para marcar ★).
- **Español e inglés** (según el idioma del teléfono).
- Se eliminó el servidor Node.js alternativo: solo se mantiene el de Cloudflare.

## Novedades de Wavko 2.0

- **Pestañas**: Canales, Amigos, Perfil y Ajustes (menú inferior).
- **Amigos**: cada instalación tiene un código de 6 caracteres; al añadirse ven si el otro está *en línea* o *en un canal*. Quien tenga tu código puede ver tu estado.
- **Perfil**: nombre y avatar de walkie-talkie con skins; se ven en las listas de participantes y de amigos.
- **Ajustes**: servidor, clave del servidor y "Volumen − como PTT (app abierta)".
- **Widget "Toca para hablar"**: un toque empieza a transmitir y otro termina (Android no permite "mantener pulsado" en widgets). En la pantalla de bloqueo depende del teléfono; la notificación trae el botón *Hablar / Parar*.

### Orden para actualizar
1. Actions → **Deploy Cloudflare Worker** (añade las invitaciones).
2. Actions → **Build APK** e instala `wavko.apk` (misma app `app.wavko`: se actualiza encima).

Nota: el Worker sigue llamándose `voxgo` para no cambiar la dirección del servidor.
