# Wavko

**Comunicación por voz en movimiento.**

App tipo Zello (push-to-talk): mantén pulsado para hablar, los demás en el canal te escuchan en vivo.

```
wavko/
├── cloudflare/                  Servidor en Cloudflare Workers + Durable Objects (recomendado)
├── server/                      Servidor alternativo en Node.js (VPS / local)
├── android/                     App Android (Kotlin)
└── .github/workflows/
    ├── build-apk.yml            Compila el APK
    └── deploy-cloudflare.yml    Despliega el servidor en Cloudflare
```

## 1. Subir el proyecto a GitHub (sin descomprimir)

1. Crea un repositorio y sube el `.zip` tal cual (Add file → Upload files).
2. Crea dos archivos con **Add file → Create new file**, pegando el contenido de los `.yml` que vienen aparte:
   - `.github/workflows/build-apk.yml`
   - `.github/workflows/deploy-cloudflare.yml`
3. Los workflows descomprimen el zip solos. Si prefieres, también puedes subir las carpetas ya descomprimidas.

## 2. Servidor en Cloudflare

Una sola vez, en tu cuenta de Cloudflare:

1. Entra a **Workers & Pages** en el dashboard y, si te lo pide, elige tu subdominio `workers.dev`.
2. Crea un **API Token**: *My Profile → API Tokens → Create Token → plantilla "Edit Cloudflare Workers"*.
3. Copia tu **Account ID** (en la página principal de Workers & Pages, barra lateral derecha).

En tu repo de GitHub, *Settings → Secrets and variables → Actions → New repository secret*:

| Secret | Valor |
|---|---|
| `CLOUDFLARE_API_TOKEN` | el token del paso 2 |
| `CLOUDFLARE_ACCOUNT_ID` | el Account ID del paso 3 |
| `ACCESS_KEY` *(opcional, recomendado)* | una clave; la app deberá enviarla |

Luego ejecuta **Actions → Deploy Cloudflare Worker → Run workflow** (también corre en cada push a `main`).
Tu servidor quedará en `wss://voxgo.<tu-subdominio>.workers.dev`; ese es el valor del campo "Servidor" de la app.

Cómo funciona: un Durable Object por canal, con la API de hibernación. Con el canal en silencio no gasta cómputo y las conexiones siguen abiertas. Los mensajes WebSocket entrantes se cuentan 20:1 como requests; consulta los límites vigentes del plan gratis en la documentación de Cloudflare.

Probarlo en tu PC: `cd cloudflare && npm install && npx wrangler dev` y en la app `ws://IP-DE-TU-PC:8787`.

## 3. Compilar el APK

1. Al hacer commit en `main`, entra en **Actions → Build APK** → abajo, en **Artifacts**, descarga `wavko-apk` (zip con `wavko.apk`).
2. También puedes lanzarlo a mano con **Run workflow**.
3. Si subes un tag (`git tag v1.0 && git push --tags`), el APK queda en **Releases**, útil para bajarlo directo desde el celular.
4. Instálalo en el teléfono (permite "instalar apps desconocidas"). Es un APK *debug*, firmado automáticamente, suficiente para uso propio.

La app ya viene con el servidor `wss://voxgo.pedroxhile.workers.dev` por defecto (se puede cambiar en el campo "Servidor"). Solo falta elegir un canal (ej. `general`) y tu nombre.

Opcional, al compilar: si en GitHub creas la variable `WAVKO_SERVER` (*Settings → Secrets and variables → Actions → Variables*) el APK usa esa dirección en vez de la de arriba; y si existe el secret `ACCESS_KEY`, la clave también queda precargada. Ojo: una clave precargada va dentro del APK, así que no compartas ese APK con quien no deba tenerla.

## Canales y claves

- **Crear canal:** eliges un nombre libre y, si quieres, una clave. Quedas dentro como primera persona.
- **Unirme a canal:** escribes el nombre del canal y la clave que te dieron. Si el canal no existe o la clave es incorrecta, la app te lo avisa.
- Para invitar a alguien, pásale por otro medio (WhatsApp, por ejemplo) el nombre del canal y la clave.
- Un canal existe mientras haya alguien dentro. Cuando sale la última persona, el canal y su clave desaparecen; para volver a usarlo hay que crearlo de nuevo.
- Si dos personas entran con el mismo nombre, el servidor añade `(2)`, `(3)`… para distinguirlas.
- **Desconectar** te saca del canal.
- Al abrir la app aparece una pantalla de bienvenida con el botón **Seguir** (se salta si ya estás dentro de un canal).

Estas funciones viven en el Worker de Cloudflare: después de actualizarlo hay que ejecutar **Deploy Cloudflare Worker** y luego **Build APK**. El servidor Node.js de `server/` no las incluye (ni claves por canal ni lista con el nombre confirmado).

## Alternativa: servidor Node.js propio

```bash
cd server
npm install
npm start            # escucha en :8080
```

En la app: `ws://IP-DE-TU-PC:8080`. Variables: `PORT`, `ACCESS_KEY`, `MAX_TALK_MS`. Para internet, ponle HTTPS delante (`server/Dockerfile` incluido) y usa `wss://`.

## Cómo funciona

- Audio: PCM 16 kHz mono comprimido con G.711 µ-law (≈128 kbps), en paquetes de 40 ms.
- Un solo hablante por canal a la vez: si alguien habla, tu botón suena "ocupado". Turno máximo de 60 s; si el hablante queda colgado (sin audio 3 s) otro puede tomar el turno.
- Servicio en primer plano: sigue conectado con la pantalla apagada (se ve una notificación fija).
- Reconexión automática si se cae la red.
- Tecla Volumen − como PTT: opcional, funciona solo con la app abierta.

## Siguientes mejoras posibles

- Códec Opus (menos datos móviles).
- Cuentas y canales privados.
- PTT con la pantalla apagada vía auricular Bluetooth / servicio de accesibilidad.
- Mensajes de voz grabados e historial.


## Novedades de Wavko 2.0

- **Pestañas**: Canales, Amigos, Perfil y Ajustes (menú inferior).
- **Amigos**: cada instalación tiene un código de 6 caracteres. Pásalo a un amigo; cuando ambos se añaden ven si el otro está *en línea* o *en un canal*. Quien tenga tu código puede ver tu estado.
- **Perfil**: nombre y avatar de walkie-talkie con 8 skins; se ven en la lista de participantes y de amigos.
- **Ajustes**: servidor, clave del servidor y "Volumen − como PTT (app abierta)".
- **Widget "Toca para hablar"**: un toque empieza a transmitir y otro termina (Android no permite "mantener pulsado" en widgets). Se añade desde Ajustes o desde el menú de widgets del sistema; en la pantalla de bloqueo depende del teléfono y la versión de Android. La notificación de Wavko trae el mismo botón *Hablar / Parar* y se ve con el teléfono bloqueado.

### Orden para actualizar
1. Actions → **Deploy Cloudflare Worker** (añade presencia de amigos y skins).
2. Actions → **Build APK** e instala `wavko.apk`. El identificador cambió a `app.wavko`, así que se instala como app nueva; puedes desinstalar VoxGo.

Nota: el Worker sigue llamándose `voxgo` para no cambiar la dirección del servidor. El servidor Node.js alternativo (`server/`) no incluye claves de canal, skins ni presencia.
