/**
 * VoxGo - Comunicación por voz en movimiento (Cloudflare Workers + Durable Objects).
 *
 * - El Worker recibe la conexión WebSocket en  wss://<tu-worker>/?channel=<canal>
 *   y la envía al Durable Object de ese canal (uno por canal).
 * - El Durable Object usa la API de hibernación: si el canal está en silencio,
 *   no consume tiempo de cómputo y las conexiones siguen abiertas.
 * - Un solo hablante por canal a la vez (control de turno).
 *
 * Protocolo (texto JSON), igual que el servidor Node.js:
 *  cliente -> servidor: {type:"join", channel, name, key}
 *                       {type:"ptt", on:true|false}
 *  servidor -> cliente: {type:"joined", channel, users:[...]}
 *                       {type:"users", users:[...]}
 *                       {type:"granted"} | {type:"busy", by}
 *                       {type:"talking", name|null}
 *                       {type:"released"}   (tiempo máximo de turno)
 *                       {type:"error", message}
 * Binario: chunks de audio G.711 µ-law, 16 kHz, mono (640 bytes = 40 ms).
 */
import { DurableObject } from "cloudflare:workers";

const MAX_TALK_MS = 60_000; // tiempo máximo por turno
const STALE_MS = 3_000; // si el hablante no manda audio en este tiempo, otro puede tomar el turno

function cleanChannel(v) {
  return String(v || "").toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 32) || "general";
}

function cleanName(v) {
  return String(v || "").replace(/[\u0000-\u001f]/g, "").trim().slice(0, 24) || "Anonimo";
}

function sendJson(ws, obj) {
  try {
    ws.send(JSON.stringify(obj));
  } catch (e) {
    // socket ya cerrado
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/health") return new Response("ok");

    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("VoxGo server\n", {
        headers: { "content-type": "text/plain; charset=utf-8" },
      });
    }

    const channel = cleanChannel(url.searchParams.get("channel"));
    const stub = env.CHANNEL.get(env.CHANNEL.idFromName(channel));
    return stub.fetch(request);
  },
};

export class Channel extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    // Estado del turno. Solo vive mientras el objeto está en memoria; si hibernó
    // es porque nadie estaba hablando, así que empezar en null es correcto.
    this.talkerId = null;
    this.talkerName = null;
    this.talkStart = 0;
    this.lastAudio = 0;
  }

  async fetch(request) {
    const url = new URL(request.url);
    const [client, server] = Object.values(new WebSocketPair());
    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({
      id: crypto.randomUUID(),
      name: "Anonimo",
      joined: false,
      channel: cleanChannel(url.searchParams.get("channel")),
    });
    return new Response(null, { status: 101, webSocket: client });
  }

  // ------------------------------------------------------------ helpers

  /** Sockets que ya hicieron "join" (excepto el de id `exceptId`). */
  _members(exceptId) {
    const out = [];
    for (const ws of this.ctx.getWebSockets()) {
      const a = ws.deserializeAttachment();
      if (a && a.joined && a.id !== exceptId) out.push({ ws, a });
    }
    return out;
  }

  _users(exceptId) {
    return this._members(exceptId).map((m) => m.a.name);
  }

  _find(id) {
    for (const ws of this.ctx.getWebSockets()) {
      const a = ws.deserializeAttachment();
      if (a && a.id === id) return ws;
    }
    return null;
  }

  _release(id) {
    if (this.talkerId !== id) return;
    this.talkerId = null;
    this.talkerName = null;
    for (const m of this._members(id)) sendJson(m.ws, { type: "talking", name: null });
  }

  _gone(ws) {
    const me = ws.deserializeAttachment();
    if (!me) return;
    this._release(me.id);
    if (me.joined) {
      const msg = { type: "users", users: this._users(me.id) };
      for (const m of this._members(me.id)) sendJson(m.ws, msg);
    }
  }

  // ----------------------------------------------------------- mensajes

  async webSocketMessage(ws, message) {
    const me = ws.deserializeAttachment();
    if (!me) return;

    // --- Audio (binario) ---
    if (typeof message !== "string") {
      if (!me.joined || this.talkerId !== me.id) return; // solo el que tiene el turno
      const now = Date.now();
      if (now - this.talkStart > MAX_TALK_MS) {
        this._release(me.id);
        sendJson(ws, { type: "released" });
        return;
      }
      this.lastAudio = now;
      for (const m of this._members(me.id)) {
        try {
          m.ws.send(message);
        } catch (e) {
          // el receptor se cayó; su evento de cierre lo limpiará
        }
      }
      return;
    }

    // --- Control (JSON) ---
    let msg;
    try {
      msg = JSON.parse(message);
    } catch (e) {
      return;
    }
    if (!msg || typeof msg !== "object") return;

    if (msg.type === "join") {
      const key = this.env.ACCESS_KEY;
      if (key && msg.key !== key) {
        sendJson(ws, { type: "error", message: "Clave incorrecta" });
        ws.close(4001, "bad key");
        return;
      }
      me.name = cleanName(msg.name);
      me.joined = true;
      ws.serializeAttachment(me);

      sendJson(ws, { type: "joined", channel: me.channel, users: this._users(null) });
      const usersMsg = { type: "users", users: this._users(null) };
      for (const m of this._members(me.id)) sendJson(m.ws, usersMsg);
      if (this.talkerId && this.talkerId !== me.id) {
        sendJson(ws, { type: "talking", name: this.talkerName });
      }
      return;
    }

    if (msg.type === "ptt" && me.joined) {
      if (!msg.on) {
        this._release(me.id);
        return;
      }
      const now = Date.now();
      if (this.talkerId && this.talkerId !== me.id) {
        const last = Math.max(this.talkStart, this.lastAudio);
        if (now - last < STALE_MS) {
          sendJson(ws, { type: "busy", by: this.talkerName });
          return;
        }
        // El hablante anterior quedó colgado: le quitamos el turno
        const oldId = this.talkerId;
        this._release(oldId);
        const old = this._find(oldId);
        if (old) sendJson(old, { type: "released" });
      }
      if (this.talkerId === me.id) {
        sendJson(ws, { type: "granted" });
        return;
      }
      this.talkerId = me.id;
      this.talkerName = me.name;
      this.talkStart = now;
      this.lastAudio = now;
      sendJson(ws, { type: "granted" });
      for (const m of this._members(me.id)) sendJson(m.ws, { type: "talking", name: me.name });
    }
  }

  async webSocketClose(ws, code, reason, wasClean) {
    this._gone(ws);
    try {
      // 1005/1006/1015 no se pueden enviar en un frame de cierre
      ws.close(code === 1005 || code === 1006 || code === 1015 ? 1000 : code, "bye");
    } catch (e) {
      // ya cerrado
    }
  }

  async webSocketError(ws, error) {
    this._gone(ws);
  }
}
