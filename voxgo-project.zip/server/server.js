'use strict';
/**
 * VoxGo server - Comunicación por voz en movimiento
 * - WebSocket, canales por nombre.
 * - Un solo hablante por canal a la vez (control de turno).
 * - El audio (binario) se reenvía a los demás miembros del canal.
 *
 * Protocolo (texto JSON):
 *  cliente -> servidor: {type:"join", channel, name, key}
 *                       {type:"ptt", on:true|false}
 *  servidor -> cliente: {type:"joined", channel, users:[...]}
 *                       {type:"users", users:[...]}
 *                       {type:"granted"} | {type:"busy", by}
 *                       {type:"talking", name|null}
 *                       {type:"released"}   (se acabó el tiempo máximo)
 *                       {type:"error", message}
 * Binario: chunks de audio G.711 µ-law, 16 kHz, mono (640 bytes = 40 ms).
 */
const http = require('http');
const WebSocket = require('ws');
const { WebSocketServer } = WebSocket;

const PORT = parseInt(process.env.PORT, 10) || 8080;
const ACCESS_KEY = process.env.ACCESS_KEY || ''; // si se define, los clientes deben enviarla
const MAX_TALK_MS = parseInt(process.env.MAX_TALK_MS, 10) || 60000;

// name -> { clients: Set<WebSocket>, talker: WebSocket|null, timer: Timeout|null }
const channels = new Map();

const server = http.createServer((req, res) => {
  if (req.url === '/health') {
    res.writeHead(200);
    return res.end('ok');
  }
  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('VoxGo server\n');
});

const wss = new WebSocketServer({ server, maxPayload: 64 * 1024 });

function sendJson(ws, obj) {
  if (ws.readyState === 1) ws.send(JSON.stringify(obj));
}

function cleanChannel(v) {
  return String(v || '').toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 32) || 'general';
}

function cleanName(v) {
  return String(v || '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 24) || 'Anonimo';
}

function userList(ch) {
  return [...ch.clients].map((c) => c.meta.name);
}

function releaseFloor(ch, ws) {
  if (ch.talker !== ws) return;
  ch.talker = null;
  clearTimeout(ch.timer);
  ch.timer = null;
  for (const c of ch.clients) {
    if (c !== ws) sendJson(c, { type: 'talking', name: null });
  }
}

function leaveChannel(ws) {
  const chName = ws.meta.channel;
  if (!chName) return;
  ws.meta.channel = null;
  const ch = channels.get(chName);
  if (!ch) return;
  releaseFloor(ch, ws);
  ch.clients.delete(ws);
  if (ch.clients.size === 0) {
    channels.delete(chName);
  } else {
    for (const c of ch.clients) sendJson(c, { type: 'users', users: userList(ch) });
  }
}

wss.on('connection', (ws) => {
  ws.meta = { name: 'Anonimo', channel: null };
  ws.isAlive = true;
  ws.on('pong', () => {
    ws.isAlive = true;
  });

  ws.on('message', (data, isBinary) => {
    // --- Audio ---
    if (isBinary) {
      const ch = channels.get(ws.meta.channel);
      if (!ch || ch.talker !== ws) return; // solo el que tiene el turno
      for (const c of ch.clients) {
        // si un cliente va lento (bufferedAmount alto) se le descarta audio en vez de acumular retraso
        if (c !== ws && c.readyState === 1 && c.bufferedAmount < 256 * 1024) {
          c.send(data, { binary: true });
        }
      }
      return;
    }

    // --- Control ---
    let msg;
    try {
      msg = JSON.parse(data.toString());
    } catch (e) {
      return;
    }
    if (!msg || typeof msg !== 'object') return;

    if (msg.type === 'join') {
      if (ACCESS_KEY && msg.key !== ACCESS_KEY) {
        sendJson(ws, { type: 'error', message: 'Clave incorrecta' });
        ws.close(4001, 'bad key');
        return;
      }
      leaveChannel(ws);
      ws.meta.name = cleanName(msg.name);
      const chName = cleanChannel(msg.channel);
      let ch = channels.get(chName);
      if (!ch) {
        ch = { clients: new Set(), talker: null, timer: null };
        channels.set(chName, ch);
      }
      ch.clients.add(ws);
      ws.meta.channel = chName;
      sendJson(ws, { type: 'joined', channel: chName, users: userList(ch) });
      for (const c of ch.clients) {
        if (c !== ws) sendJson(c, { type: 'users', users: userList(ch) });
      }
      if (ch.talker) sendJson(ws, { type: 'talking', name: ch.talker.meta.name });
      return;
    }

    if (msg.type === 'ptt') {
      const ch = channels.get(ws.meta.channel);
      if (!ch) return;
      if (msg.on) {
        if (ch.talker === ws) return sendJson(ws, { type: 'granted' });
        if (ch.talker) return sendJson(ws, { type: 'busy', by: ch.talker.meta.name });
        ch.talker = ws;
        ch.timer = setTimeout(() => {
          if (ch.talker === ws) {
            releaseFloor(ch, ws);
            sendJson(ws, { type: 'released' });
          }
        }, MAX_TALK_MS);
        sendJson(ws, { type: 'granted' });
        for (const c of ch.clients) {
          if (c !== ws) sendJson(c, { type: 'talking', name: ws.meta.name });
        }
      } else {
        releaseFloor(ch, ws);
      }
    }
  });

  ws.on('close', () => leaveChannel(ws));
  ws.on('error', () => {});
});

// Detecta conexiones muertas
const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) {
      ws.terminate();
      continue;
    }
    ws.isAlive = false;
    ws.ping();
  }
}, 30000);
wss.on('close', () => clearInterval(heartbeat));

server.listen(PORT, () => {
  console.log(`VoxGo server escuchando en :${PORT}` + (ACCESS_KEY ? ' (con clave)' : ' (sin clave)'));
});
