plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Valores por defecto de la app. Se pueden cambiar al compilar con las variables de
// entorno VOXGO_SERVER y VOXGO_KEY (en GitHub: variable VOXGO_SERVER y secret ACCESS_KEY).
fun buildString(v: String) = "\"" + v.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
val defaultServer = System.getenv("VOXGO_SERVER")?.trim()?.takeIf { it.isNotEmpty() }
    ?: "wss://voxgo.pedroxhile.workers.dev"
val defaultKey = System.getenv("VOXGO_KEY") ?: ""

android {
    namespace = "app.walkie.ptt"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.voxgo"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        buildConfigField("String", "DEFAULT_SERVER", buildString(defaultServer))
        buildConfigField("String", "DEFAULT_KEY", buildString(defaultKey))
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
