package app.walkie.ptt

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity(), PttService.Listener {

    private var service: PttService? = null
    private var pendingMode: String? = null
    private var welcomeDone = false

    // Bienvenida
    private lateinit var welcome: View
    private lateinit var welcomeRipple: RippleView
    private lateinit var welcomeLogo: View
    private lateinit var welcomeTitle: View
    private lateinit var welcomeTagline: View
    private lateinit var btnWelcome: Button

    // Cabecera
    private lateinit var statusDot: View
    private lateinit var statusView: TextView

    // Panel para crear / unirse
    private lateinit var panelConnect: View
    private lateinit var inputName: TextInputEditText
    private lateinit var inputChannel: TextInputEditText
    private lateinit var inputPass: TextInputEditText
    private lateinit var inputServer: TextInputEditText
    private lateinit var inputKey: TextInputEditText
    private lateinit var chkVolume: CheckBox
    private lateinit var advToggle: TextView
    private lateinit var advBox: View
    private lateinit var btnJoin: Button
    private lateinit var btnCreate: Button
    private lateinit var connectMsg: TextView

    // Panel del canal
    private lateinit var panelChannel: View
    private lateinit var channelTitle: TextView
    private lateinit var channelCount: TextView
    private lateinit var banner: View
    private lateinit var bannerBars: BarsView
    private lateinit var bannerText: TextView
    private lateinit var list: RecyclerView
    private val adapter = ParticipantAdapter()

    // Botón de hablar
    private lateinit var pttArea: View
    private lateinit var ripple: RippleView
    private lateinit var btnPtt: View
    private lateinit var pttLabel: TextView
    private lateinit var btnDisconnect: Button

    private val prefs by lazy { getSharedPreferences("voxgo", Context.MODE_PRIVATE) }

    private val cGreen = Color.parseColor("#22C55E")
    private val cAmber = Color.parseColor("#F59E0B")
    private val cGray = Color.parseColor("#6B6280")
    private val cPink = Color.parseColor("#EC4899")
    private val cLavender = Color.parseColor("#E9D5FF")
    private val cPrimary = Color.parseColor("#8B5CF6")

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = (binder as PttService.LocalBinder).service
            service?.listener = this@MainActivity
            // Si ya estabas dentro de un canal, no hace falta pasar otra vez por la bienvenida
            if (service?.state != PttService.DISCONNECTED) dismissWelcome(false)
            render()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            render()
        }
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val mode = pendingMode
            pendingMode = null
            if (mode != null) {
                if (hasMic()) {
                    doConnect(mode)
                } else {
                    toast("Se necesita el permiso de micrófono para hablar")
                }
            }
        }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        welcome = findViewById(R.id.welcome)
        welcomeRipple = findViewById(R.id.welcomeRipple)
        welcomeLogo = findViewById(R.id.welcomeLogo)
        welcomeTitle = findViewById(R.id.welcomeTitle)
        welcomeTagline = findViewById(R.id.welcomeTagline)
        btnWelcome = findViewById(R.id.btnWelcome)

        statusDot = findViewById(R.id.statusDot)
        statusView = findViewById(R.id.status)

        panelConnect = findViewById(R.id.panelConnect)
        inputName = findViewById(R.id.inputName)
        inputChannel = findViewById(R.id.inputChannel)
        inputPass = findViewById(R.id.inputPass)
        inputServer = findViewById(R.id.inputServer)
        inputKey = findViewById(R.id.inputKey)
        chkVolume = findViewById(R.id.chkVolume)
        advToggle = findViewById(R.id.advToggle)
        advBox = findViewById(R.id.advBox)
        btnJoin = findViewById(R.id.btnJoin)
        btnCreate = findViewById(R.id.btnCreate)
        connectMsg = findViewById(R.id.connectMsg)

        panelChannel = findViewById(R.id.panelChannel)
        channelTitle = findViewById(R.id.channelTitle)
        channelCount = findViewById(R.id.channelCount)
        banner = findViewById(R.id.banner)
        bannerBars = findViewById(R.id.bannerBars)
        bannerText = findViewById(R.id.bannerText)
        list = findViewById(R.id.list)

        pttArea = findViewById(R.id.pttArea)
        ripple = findViewById(R.id.ripple)
        btnPtt = findViewById(R.id.btnPtt)
        pttLabel = findViewById(R.id.pttLabel)
        btnDisconnect = findViewById(R.id.btnDisconnect)

        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        ripple.baseRadiusDp = 75f
        welcomeRipple.baseRadiusDp = 62f

        // Valores guardados (el canal y la clave del canal no se recuerdan a propósito)
        inputServer.setText(prefs.getString("server", BuildConfig.DEFAULT_SERVER))
        inputName.setText(prefs.getString("name", Build.MODEL))
        inputChannel.setText(prefs.getString("channel", ""))
        inputKey.setText(prefs.getString("key", BuildConfig.DEFAULT_KEY))
        chkVolume.isChecked = prefs.getBoolean("volPtt", false)

        advToggle.setOnClickListener {
            val show = advBox.visibility != View.VISIBLE
            advBox.visibility = if (show) View.VISIBLE else View.GONE
            advToggle.text = if (show) "Ajustes avanzados ▴" else "Ajustes avanzados ▾"
        }
        btnJoin.setOnClickListener { onConnectClicked("join") }
        btnCreate.setOnClickListener { onConnectClicked("create") }
        btnDisconnect.setOnClickListener { service?.disconnect() }
        btnWelcome.setOnClickListener { dismissWelcome(true) }

        btnPtt.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                    service?.startTalking()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    service?.stopTalking()
                }
            }
            true
        }

        welcomeDone = savedInstanceState?.getBoolean("welcomeDone") == true
        if (welcomeDone) {
            welcome.visibility = View.GONE
        } else {
            playWelcome()
        }
        render()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("welcomeDone", welcomeDone)
    }

    override fun onStart() {
        super.onStart()
        bindService(Intent(this, PttService::class.java), conn, Context.BIND_AUTO_CREATE)
    }

    override fun onStop() {
        service?.listener = null
        try {
            unbindService(conn)
        } catch (e: IllegalArgumentException) {
        }
        service = null
        super.onStop()
    }

    override fun onChanged() = render()

    // ------------------------------------------------------------ Bienvenida

    private fun playWelcome() {
        welcomeRipple.start()
        val d = resources.displayMetrics.density
        listOf(welcomeLogo, welcomeTitle, welcomeTagline, btnWelcome).forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = 28f * d
            v.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(150L + i * 140L)
                .setDuration(600)
                .start()
        }
        welcomeLogo.scaleX = 0.75f
        welcomeLogo.scaleY = 0.75f
        welcomeLogo.animate().scaleX(1f).scaleY(1f).setStartDelay(150).setDuration(700).start()
    }

    private fun dismissWelcome(animated: Boolean) {
        if (welcomeDone) return
        welcomeDone = true
        if (animated) {
            welcome.animate().alpha(0f).setDuration(350).withEndAction {
                welcome.visibility = View.GONE
                welcomeRipple.stop()
            }.start()
        } else {
            welcome.visibility = View.GONE
            welcomeRipple.stop()
        }
    }

    // ---------------------------------------------------------------- Teclas

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (welcomeDone && chkVolume.isChecked && keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event?.repeatCount == 0) service?.startTalking()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (welcomeDone && chkVolume.isChecked && keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            service?.stopTalking()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    // ------------------------------------------------------------ Conexión

    private fun onConnectClicked(mode: String) {
        val s = service
        if (s == null) {
            toast("El servicio aún no está listo, intenta de nuevo")
            return
        }
        if (s.state != PttService.DISCONNECTED) return
        if (inputChannel.text.isNullOrBlank()) {
            inputChannel.error = "Escribe el nombre del canal"
            return
        }
        if (inputServer.text.isNullOrBlank()) {
            advBox.visibility = View.VISIBLE
            advToggle.text = "Ajustes avanzados ▴"
            inputServer.error = "Escribe la dirección del servidor"
            return
        }
        val perms = mutableListOf<String>()
        if (!hasMic()) perms += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            perms += Manifest.permission.POST_NOTIFICATIONS
        }
        if (perms.isNotEmpty()) {
            pendingMode = mode
            permLauncher.launch(perms.toTypedArray())
        } else {
            doConnect(mode)
        }
    }

    private fun doConnect(mode: String) {
        var url = inputServer.text.toString().trim()
        if (!Regex("^(ws|wss|http|https)://", RegexOption.IGNORE_CASE).containsMatchIn(url)) {
            url = "ws://$url"
        }
        val channel = inputChannel.text.toString().trim()
        val name = inputName.text.toString().trim().ifEmpty { Build.MODEL }
        val key = inputKey.text.toString()
        val pass = inputPass.text.toString()

        prefs.edit()
            .putString("server", inputServer.text.toString().trim())
            .putString("name", name)
            .putString("channel", channel)
            .putString("key", key)
            .putBoolean("volPtt", chkVolume.isChecked)
            .apply()

        ContextCompat.startForegroundService(this, Intent(this, PttService::class.java))
        service?.connect(url, channel, name, key, mode, pass)
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    // ------------------------------------------------------------------ UI

    private fun render() {
        val s = service
        val st = s?.state ?: PttService.DISCONNECTED
        val disconnected = st == PttService.DISCONNECTED
        val connected = st == PttService.CONNECTED
        val tx = s?.transmitting == true
        val talker = s?.talker
        val users = s?.users ?: emptyList()

        // Chip de estado
        statusView.text = if (disconnected) "Desconectado" else (s?.statusText ?: "")
        val dot = when (st) {
            PttService.CONNECTED -> cGreen
            PttService.CONNECTING -> cAmber
            else -> cGray
        }
        statusDot.backgroundTintList = ColorStateList.valueOf(dot)

        // Qué panel se ve
        panelConnect.visibility = if (disconnected) View.VISIBLE else View.GONE
        panelChannel.visibility = if (disconnected) View.GONE else View.VISIBLE
        pttArea.visibility = if (disconnected) View.GONE else View.VISIBLE
        btnDisconnect.visibility = if (disconnected) View.GONE else View.VISIBLE

        if (disconnected) {
            // Mensaje de error / motivo de la desconexión (p. ej. "Ese canal no existe")
            val msg = s?.statusText.orEmpty()
            if (msg.isEmpty() || msg == "Desconectado") {
                connectMsg.visibility = View.GONE
            } else {
                connectMsg.text = msg
                connectMsg.visibility = View.VISIBLE
            }
            ripple.stop()
            bannerBars.stop()
            return
        }
        connectMsg.visibility = View.GONE

        // Canal
        val ch = s?.channelName.orEmpty()
        channelTitle.text = if (ch.isEmpty()) "Conectando…" else "#$ch"
        channelCount.text = if (users.size == 1) "1 conectado" else "${users.size} conectados"

        // Quién está hablando
        when {
            tx -> {
                bannerText.text = "Estás transmitiendo"
                banner.setBackgroundResource(R.drawable.bg_banner_tx)
                bannerBars.setColor(cPink)
                bannerBars.visibility = View.VISIBLE
                bannerBars.start()
            }
            talker != null -> {
                bannerText.text = "$talker está hablando"
                banner.setBackgroundResource(R.drawable.bg_banner_talk)
                bannerBars.setColor(cLavender)
                bannerBars.visibility = View.VISIBLE
                bannerBars.start()
            }
            else -> {
                bannerText.text = if (connected) "Canal libre" else "Conectando…"
                banner.setBackgroundResource(R.drawable.bg_banner_idle)
                bannerBars.stop()
                bannerBars.visibility = View.GONE
            }
        }

        adapter.submit(users, s?.myName.orEmpty(), talker, tx)

        // Botón de hablar
        val busy = !tx && talker != null
        btnPtt.setBackgroundResource(
            when {
                tx -> R.drawable.bg_ptt_tx
                connected -> R.drawable.bg_ptt_idle
                else -> R.drawable.bg_ptt_off
            }
        )
        btnPtt.alpha = if (busy) 0.55f else 1f
        pttLabel.text = when {
            tx -> "TRANSMITIENDO"
            !connected -> "CONECTANDO…"
            busy -> "CANAL OCUPADO"
            else -> "MANTÉN PARA\nHABLAR"
        }
        if (tx) {
            ripple.setColor(cPink)
            ripple.start()
        } else {
            ripple.stop()
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
