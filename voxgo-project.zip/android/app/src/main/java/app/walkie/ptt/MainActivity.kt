package app.walkie.ptt

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity(), PttService.Listener {

    private var service: PttService? = null
    private var pendingConnect = false

    private lateinit var settingsBox: View
    private lateinit var inputServer: TextInputEditText
    private lateinit var inputChannel: TextInputEditText
    private lateinit var inputName: TextInputEditText
    private lateinit var inputKey: TextInputEditText
    private lateinit var chkVolume: CheckBox
    private lateinit var statusView: TextView
    private lateinit var talkerView: TextView
    private lateinit var usersView: TextView
    private lateinit var btnConnect: Button
    private lateinit var btnPtt: TextView

    private val prefs by lazy { getSharedPreferences("voxgo", Context.MODE_PRIVATE) }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = (binder as PttService.LocalBinder).service
            service?.listener = this@MainActivity
            render()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            render()
        }
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (pendingConnect) {
                pendingConnect = false
                if (hasMic()) {
                    doConnect()
                } else {
                    toast("Se necesita el permiso de micrófono para hablar")
                }
            }
        }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        settingsBox = findViewById(R.id.settingsBox)
        inputServer = findViewById(R.id.inputServer)
        inputChannel = findViewById(R.id.inputChannel)
        inputName = findViewById(R.id.inputName)
        inputKey = findViewById(R.id.inputKey)
        chkVolume = findViewById(R.id.chkVolume)
        statusView = findViewById(R.id.status)
        talkerView = findViewById(R.id.talker)
        usersView = findViewById(R.id.users)
        btnConnect = findViewById(R.id.btnConnect)
        btnPtt = findViewById(R.id.btnPtt)

        inputServer.setText(prefs.getString("server", BuildConfig.DEFAULT_SERVER))
        inputChannel.setText(prefs.getString("channel", "general"))
        inputName.setText(prefs.getString("name", Build.MODEL))
        inputKey.setText(prefs.getString("key", BuildConfig.DEFAULT_KEY))
        chkVolume.isChecked = prefs.getBoolean("volPtt", false)

        btnConnect.setOnClickListener { onConnectClicked() }

        btnPtt.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> service?.startTalking()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> service?.stopTalking()
            }
            true
        }

        render()
    }

    override fun onStart() {
        super.onStart()
        bindService(Intent(this, PttService::class.java), conn, Context.BIND_AUTO_CREATE)
    }

    override fun onStop() {
        service?.listener = null
        try {
            unbindService(conn)
        } catch (e: IllegalArgumentException) {
        }
        service = null
        super.onStop()
    }

    override fun onChanged() = render()

    // --------------------------------------------------------------- Teclas

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (chkVolume.isChecked && keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event?.repeatCount == 0) service?.startTalking()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (chkVolume.isChecked && keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            service?.stopTalking()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    // ------------------------------------------------------------ Conexión

    private fun onConnectClicked() {
        val s = service
        if (s == null) {
            toast("El servicio aún no está listo, intenta de nuevo")
            return
        }
        if (s.state != PttService.DISCONNECTED) {
            s.disconnect()
            return
        }
        if (inputServer.text.isNullOrBlank()) {
            inputServer.error = "Escribe la dirección del servidor"
            return
        }
        val perms = mutableListOf<String>()
        if (!hasMic()) perms += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            perms += Manifest.permission.POST_NOTIFICATIONS
        }
        if (perms.isNotEmpty()) {
            pendingConnect = true
            permLauncher.launch(perms.toTypedArray())
        } else {
            doConnect()
        }
    }

    private fun doConnect() {
        var url = inputServer.text.toString().trim()
        if (!Regex("^(ws|wss|http|https)://", RegexOption.IGNORE_CASE).containsMatchIn(url)) {
            url = "ws://$url"
        }
        val channel = inputChannel.text.toString().trim().ifEmpty { "general" }
        val name = inputName.text.toString().trim().ifEmpty { Build.MODEL }
        val key = inputKey.text.toString()

        prefs.edit()
            .putString("server", inputServer.text.toString().trim())
            .putString("channel", channel)
            .putString("name", name)
            .putString("key", key)
            .putBoolean("volPtt", chkVolume.isChecked)
            .apply()

        ContextCompat.startForegroundService(this, Intent(this, PttService::class.java))
        service?.connect(url, channel, name, key)
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    // ------------------------------------------------------------------ UI

    private fun render() {
        val s = service
        val st = s?.state ?: PttService.DISCONNECTED
        val connected = st == PttService.CONNECTED
        val tx = s?.transmitting == true
        val talker = s?.talker

        statusView.text = s?.statusText ?: "Desconectado"
        settingsBox.visibility = if (st == PttService.DISCONNECTED) View.VISIBLE else View.GONE
        btnConnect.text = if (st == PttService.DISCONNECTED) "Conectar" else "Desconectar"

        val list = s?.users ?: emptyList()
        usersView.text = if (list.isEmpty()) "" else "En el canal (${list.size}): ${list.joinToString(", ")}"

        talkerView.text = when {
            tx -> "🎙️ Transmitiendo…"
            talker != null -> "🔊 $talker está hablando"
            connected -> "Canal libre"
            else -> ""
        }

        btnPtt.setBackgroundResource(
            when {
                tx -> R.drawable.bg_ptt_tx
                connected -> R.drawable.bg_ptt_idle
                else -> R.drawable.bg_ptt_off
            }
        )
        btnPtt.text = when {
            tx -> "HABLANDO…"
            connected -> "MANTENER\nPARA HABLAR"
            else -> "SIN CONEXIÓN"
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
