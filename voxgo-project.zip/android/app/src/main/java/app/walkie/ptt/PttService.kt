package app.walkie.ptt

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Mantiene la conexión WebSocket, captura el micrófono mientras se pulsa PTT
 * y reproduce el audio de los demás. Corre como servicio en primer plano para
 * seguir funcionando con la pantalla apagada.
 *
 * Toda la lógica de estado corre en el hilo principal; los hilos de audio
 * solo leen/escriben buffers.
 */
class PttService : Service() {

    interface Listener {
        fun onChanged()
    }

    companion object {
        const val DISCONNECTED = 0
        const val CONNECTING = 1
        const val CONNECTED = 2

        const val RATE = 16000
        const val CHUNK = 640 // 40 ms a 16 kHz

        private const val CHANNEL_ID = "voxgo"
        private const val NOTIF_ID = 1
    }

    inner class LocalBinder : Binder() {
        val service: PttService get() = this@PttService
    }

    private val binder = LocalBinder()
    private val main = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    // Estado visible para la UI
    var listener: Listener? = null
    var state = DISCONNECTED
        private set
    var statusText = "Desconectado"
        private set
    var users: List<String> = emptyList()
        private set
    var talker: String? = null
        private set
    var transmitting = false
        private set

    private var url = ""
    private var channel = ""
    private var name = ""
    private var key = ""

    @Volatile private var ws: WebSocket? = null
    @Volatile private var gen = 0
    private var wantConnected = false
    private var wantTalk = false

    private var recorder: Recorder? = null
    private var player: Player? = null
    private var tone: ToneGenerator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    private val retry = Runnable { if (wantConnected) openSocket() }

    // ------------------------------------------------------------------ Service

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startFg(statusText)
        } catch (e: Exception) {
            disconnect("No se pudo iniciar el servicio: ${e.message}")
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    // --------------------------------------------------------------- API pública

    fun connect(url: String, channel: String, name: String, key: String) {
        this.url = url
        this.channel = channel
        this.name = name
        this.key = key
        wantConnected = true
        acquireLocks()
        player?.shutdown()
        player = Player().also { it.start() }
        if (tone == null) {
            tone = try {
                ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            } catch (e: Exception) {
                null
            }
        }
        openSocket()
    }

    fun disconnect(reason: String = "Desconectado") {
        teardown()
        talker = null
        users = emptyList()
        transmitting = false
        setState(DISCONNECTED, reason)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** El usuario pulsó el botón: pedimos el turno al servidor. */
    fun startTalking() {
        if (state != CONNECTED || wantTalk) return
        wantTalk = true
        ws?.send("""{"type":"ptt","on":true}""")
    }

    /** El usuario soltó el botón. */
    fun stopTalking() {
        if (!wantTalk && recorder == null) return
        wantTalk = false
        recorder?.running = false
        recorder = null
        ws?.send("""{"type":"ptt","on":false}""")
        if (transmitting) {
            transmitting = false
            listener?.onChanged()
        }
    }

    // ---------------------------------------------------------------- Conexión

    private fun openSocket() {
        gen++
        ws?.cancel()
        setState(CONNECTING, "Conectando…")
        // El canal va también en la URL: así Cloudflare enruta la conexión al canal correcto.
        // El servidor Node.js ignora este parámetro.
        val sep = if (url.contains("?")) "&" else "?"
        val fullUrl = url + sep + "channel=" + Uri.encode(channel)
        val request = try {
            Request.Builder().url(fullUrl).build()
        } catch (e: IllegalArgumentException) {
            disconnect("URL del servidor inválida")
            return
        }
        ws = client.newWebSocket(request, makeListener(gen))
    }

    private fun makeListener(myGen: Int) = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            if (myGen != gen) return
            val j = JSONObject()
                .put("type", "join")
                .put("channel", channel)
                .put("name", name)
                .put("key", key)
            webSocket.send(j.toString())
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            if (myGen != gen) return
            main.post { if (myGen == gen) handleText(text) }
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            if (myGen != gen) return
            player?.enqueue(bytes.toByteArray())
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(1000, null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            main.post { if (myGen == gen) handleDrop("Conexión cerrada") }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            main.post { if (myGen == gen) handleDrop("Sin conexión") }
        }
    }

    private fun handleText(text: String) {
        val j = try {
            JSONObject(text)
        } catch (e: Exception) {
            return
        }
        when (j.optString("type")) {
            "joined" -> {
                users = parseUsers(j)
                setState(CONNECTED, "Conectado · #${j.optString("channel", channel)}")
            }
            "users" -> {
                users = parseUsers(j)
                listener?.onChanged()
            }
            "talking" -> {
                talker = if (j.isNull("name")) null else j.optString("name")
                listener?.onChanged()
            }
            "granted" -> beginRecording()
            "busy" -> {
                wantTalk = false
                try {
                    tone?.startTone(ToneGenerator.TONE_PROP_NACK, 150)
                } catch (e: Exception) {
                }
                listener?.onChanged()
            }
            "released" -> stopTalking() // el servidor cortó el turno por tiempo máximo
            "error" -> disconnect(j.optString("message", "Error del servidor"))
        }
    }

    private fun handleDrop(msg: String) {
        if (!wantConnected) return
        stopTalking()
        talker = null
        users = emptyList()
        ws = null
        setState(CONNECTING, "$msg · reintentando…")
        main.removeCallbacks(retry)
        main.postDelayed(retry, 3000)
    }

    private fun parseUsers(j: JSONObject): List<String> {
        val a = j.optJSONArray("users") ?: return emptyList()
        return List(a.length()) { a.optString(it) }
    }

    private fun setState(s: Int, text: String) {
        state = s
        statusText = text
        if (s != DISCONNECTED) updateNotif(text)
        listener?.onChanged()
    }

    private fun teardown() {
        wantConnected = false
        wantTalk = false
        main.removeCallbacksAndMessages(null)
        recorder?.running = false
        recorder = null
        gen++
        ws?.close(1000, "bye")
        ws = null
        player?.shutdown()
        player = null
        tone?.release()
        tone = null
        releaseLocks()
    }

    // ------------------------------------------------------------------- Audio

    private fun beginRecording() {
        if (!wantTalk || recorder != null) return
        val hasMic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (!hasMic) {
            stopTalking()
            return
        }
        vibrate()
        transmitting = true
        recorder = Recorder().also { it.start() }
        listener?.onChanged()
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        try {
            val v = getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
        }
    }

    private inner class Recorder : Thread("ptt-rec") {
        @Volatile var running = true

        @SuppressLint("MissingPermission")
        override fun run() {
            val minBuf = AudioRecord.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, CHUNK * 2 * 4)
                )
            } catch (e: Exception) {
                null
            }
            if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
                rec?.release()
                main.post { stopTalking() }
                return
            }
            val pcm = ShortArray(CHUNK)
            val out = ByteArray(CHUNK)
            try {
                rec.startRecording()
                while (running) {
                    var off = 0
                    while (running && off < CHUNK) {
                        val n = rec.read(pcm, off, CHUNK - off)
                        if (n <= 0) {
                            running = false
                            break
                        }
                        off += n
                    }
                    if (off == CHUNK) {
                        Ulaw.encode(pcm, out, CHUNK)
                        ws?.send(out.toByteString())
                    }
                }
            } finally {
                try {
                    rec.stop()
                } catch (e: Exception) {
                }
                rec.release()
            }
        }
    }

    private inner class Player : Thread("ptt-play") {
        private val queue = LinkedBlockingQueue<ByteArray>()

        @Volatile private var running = true

        fun enqueue(b: ByteArray) {
            if (queue.size > 150) queue.clear() // ~6 s acumulados: descartamos para no ir con retraso
            queue.offer(b)
        }

        fun shutdown() {
            running = false
            interrupt()
        }

        override fun run() {
            val minBuf = AudioTrack.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, RATE)) // ~0,5 s
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            var pcm = ShortArray(CHUNK)
            var started = false
            var pre = 0
            try {
                while (running) {
                    val chunk = try {
                        queue.poll(250, TimeUnit.MILLISECONDS)
                    } catch (e: InterruptedException) {
                        break
                    }
                    if (chunk == null) {
                        // Silencio: dejamos que termine de sonar lo que quedó en el buffer
                        if (pre > 0 || started) {
                            if (!started) track.play()
                            track.stop()
                            started = false
                            pre = 0
                        }
                        continue
                    }
                    val n = chunk.size
                    if (pcm.size < n) pcm = ShortArray(n)
                    Ulaw.decode(chunk, pcm, n)
                    track.write(pcm, 0, n)
                    pre++
                    // Pequeño prebúfer (3 chunks = 120 ms) para absorber jitter de red
                    if (!started && pre >= 3) {
                        track.play()
                        started = true
                    }
                }
            } finally {
                try {
                    track.stop()
                } catch (e: Exception) {
                }
                track.release()
            }
        }
    }

    // ------------------------------------------------------- Notificación/locks

    private fun buildNotif(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("VoxGo")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun startFg(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "VoxGo", NotificationManager.IMPORTANCE_LOW)
        )
        val n = buildNotif(text)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun updateNotif(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotif(text))
        } catch (e: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        try {
            if (wakeLock == null) {
                val pm = getSystemService(PowerManager::class.java)
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voxgo:ptt").apply {
                    setReferenceCounted(false)
                }
            }
            if (wakeLock?.isHeld != true) wakeLock?.acquire()

            if (wifiLock == null) {
                val wm = applicationContext.getSystemService(WifiManager::class.java)
                val mode = if (Build.VERSION.SDK_INT >= 29) {
                    WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                } else {
                    WifiManager.WIFI_MODE_FULL_HIGH_PERF
                }
                wifiLock = wm?.createWifiLock(mode, "voxgo:wifi")?.apply {
                    setReferenceCounted(false)
                }
            }
            if (wifiLock?.isHeld != true) wifiLock?.acquire()
        } catch (e: Exception) {
        }
    }

    private fun releaseLocks() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (e: Exception) {
        }
    }
}
