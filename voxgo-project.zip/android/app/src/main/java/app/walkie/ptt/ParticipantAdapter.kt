package app.walkie.ptt

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Lista de personas conectadas al canal, con indicador verde y de "hablando". */
class ParticipantAdapter : RecyclerView.Adapter<ParticipantAdapter.VH>() {

    private var names: List<String> = emptyList()
    private var me = ""
    private var talker: String? = null
    private var meTransmitting = false

    private val palette = intArrayOf(
        Color.parseColor("#8B5CF6"),
        Color.parseColor("#EC4899"),
        Color.parseColor("#06B6D4"),
        Color.parseColor("#F59E0B"),
        Color.parseColor("#10B981"),
        Color.parseColor("#6366F1"),
        Color.parseColor("#F43F5E"),
        Color.parseColor("#3B82F6")
    )
    private val lavender = Color.parseColor("#E9D5FF")
    private val muted = Color.parseColor("#A394C7")
    private val pink = Color.parseColor("#F9A8D4")

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val row: View = v
        val avatar: TextView = v.findViewById(R.id.avatar)
        val name: TextView = v.findViewById(R.id.pName)
        val sub: TextView = v.findViewById(R.id.pSub)
        val bars: BarsView = v.findViewById(R.id.pBars)
    }

    fun submit(users: List<String>, me: String, talker: String?, meTransmitting: Boolean) {
        this.names = users
        this.me = me
        this.talker = talker
        this.meTransmitting = meTransmitting
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_participant, parent, false)
        return VH(v)
    }

    override fun getItemCount() = names.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val n = names[position]
        val isMe = n == me
        val talking = if (isMe) meTransmitting else (n == talker)

        h.name.text = if (isMe) "$n (tú)" else n
        h.avatar.text = n.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
        h.avatar.backgroundTintList = ColorStateList.valueOf(palette[(n.hashCode() and 0x7fffffff) % palette.size])
        h.row.setBackgroundResource(if (talking) R.drawable.bg_row_talking else R.drawable.bg_row)

        if (talking) {
            h.sub.text = if (isMe) "Transmitiendo…" else "Hablando…"
            h.sub.setTextColor(if (isMe) pink else lavender)
            h.bars.setColor(if (isMe) pink else lavender)
            h.bars.visibility = View.VISIBLE
            h.bars.start()
        } else {
            h.sub.text = "Conectado"
            h.sub.setTextColor(muted)
            h.bars.stop()
            h.bars.visibility = View.GONE
        }
    }
}
